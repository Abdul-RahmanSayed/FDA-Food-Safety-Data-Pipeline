# Section 3: Memorize first: the code-review survival guide

This is the compact study version. Learn the structure, then explain it naturally. You do not need to recite 977 lines of application code as though humanity has finally outlawed documentation. You do need to know what happens next, what each result means, and where the design stops being sufficient.

For the detailed explanations, use the [Part 1 walkthrough](01-technical-walkthrough.md) and [Part 2 walkthrough](01-technical-walkthrough.md). The answers below describe the implementation and its documented decisions; they do not invent memories of why you personally made a choice.

## Your opening answer: about 60 seconds

**Memory skeleton:** purpose → download → completion → analysis → limitation.

> “This is a two-stage pipeline for FDA food adverse-event reports. The Node.js downloader collects the fixed January 1, 2002 through January 1, 2026 range with a request limit of 100. It splits the range into 24 nonoverlapping windows, processes three windows concurrently by default, and follows each window's cursor sequentially.
>
> “It validates responses and identifiers, applies shared pacing and bounded retries, and preserves the original response data. It publishes a completed manifest only after the files and counts reconcile.
>
> “The Python program validates that snapshot, selects reports by year and optional suspect-product text, and builds one row per report. It produces normalized term rankings, valid-age averages, and a two-panel chart using pandas, NumPy, and Matplotlib.
>
> “The main distinction is that these are report counts and associations. The analysis does not establish product causality or count unique people.”

Then **stop**. Let Alex choose where to go deeper.

For follow-up answers, use **answer → example → result → stop**. Example: “I deduplicate terms after normalization. `Rash` and `RASH!` become the same label. That lets one report contribute once to the rash count.” That is already a complete answer.

## The 12 facts to know without opening the code

1. **The time range is fixed and inclusive.** January 1, 2002 through January 1, 2026. “Present” means the snapshot endpoint. The 2026 bar represents one day. `getWindows` puts that final day into the last window starting in 2025; there are 24 download windows but potentially 25 plotted years.

2. **Some choices were requirements.** Node.js for acquisition, pandas/NumPy/Matplotlib for analysis, 100 as the request limit, and default concurrency three were specified. Cursor handling, a completion manifest, 300 ms pacing, retry policy, and narrow alias rules are implementation details to explain separately. Do not describe a required library as a personal architectural discovery.

3. **The current stored snapshot has 97,652 reports, 987 pages, and 24 windows.** The distinct report-ID count also equals 97,652. The 73,819 usable ages have a smaller denominator because missing/invalid ages are excluded only from age statistics.

4. **Workers' requests can overlap in time; the date ranges do not overlap.** Three asynchronous workers can have requests in flight. Each worker needs the current response's next cursor before requesting the next page. Pages within that chain are requested sequentially. This is concurrent I/O, not three CPU threads. Raising concurrency does not remove the shared pacing gate.

5. **Pagination ends by the cursor chain, followed by reconciliation.** A short page, a full page, reaching the end date, or reaching the expected count is not sufficient alone. The API can supply an extra terminal cursor; only its specific no-matches 404 is recognized as exhaustion, and saved counts must still reconcile.

6. **Retries are bounded and share admission control.** One initial attempt plus three retries means four attempts maximum per page. Retry temporary HTTP 408/429/500/502/503/504 responses, recognized network failures, and timeouts. Ordinary authentication errors, malformed data, invalid pagination, and file-write errors are not repaired by repeatedly asking the same question louder.

7. **Pacing, concurrency, timeout, and backoff solve different problems.** Three workers bound simultaneous work; at least 300 ms separates request starts; 30 seconds bounds each admitted network attempt; 1/2/4-second backoff plus jitter delays retries. A longer valid `Retry-After` wins. HTTP 429 also extends a shared cooldown.

8. **The manifest is the completion boundary.** Start with `complete: false`. Validate/save all pages and reconcile counts/IDs. Write a completed temporary manifest, then rename it into place. Part 2 requires a coherent completed manifest and reads only its listed files. Counts are not content hashes, and this does not promise an immutable upstream snapshot.

9. **Filtering happens before normalization.** Match literal case-insensitive text against original names with exact role `SUSPECT`. Keep a report once if any eligible product matches. With a filter, rank only matching suspect names; outcomes, reactions, total, and ages describe the selected reports. Alex's documented preference established the matching-only ranking.

10. **One table row means one report.** Normalize each nested term list, deduplicate within that report, then `explode` one column for ranking. A term counts reports mentioning it, not raw array entries. Different terms can coexist, so ranking counts may sum beyond total reports.

11. **Age calculations keep valid values, not invented replacements.** Convert years/months/weeks/days/decades to years; retain finite values from 0 through 125. Unknown gender still contributes a valid age to the overall mean. Empty groups show `N/A`, never fabricated zero. A source value of 68 decades is rejected as 680 years, not silently changed to 68 years.

12. **Know the evidence and its limits.** This review freshly verified 98 Node test cases plus one full-dataset disk validator. The notes record 31 Python tests passing historically; the current environment lacks the required Python libraries, so that historical count is not a fresh Python test run. Never blend those claims. The notes' approximately 12-second completed analysis timing is historical as well.

## Two traces to practice aloud

### “Walk me through one downloaded page.”

**Recall:** claim → admit → fetch → validate → reserve → save → advance.

> “A worker claims a window before its first await. The window requests a page through the shared requester. The requester admits the attempt under pacing and cooldown, then starts a fresh timeout and reads the response. The window validates the next link, response structure, date membership, stable total, and duplicate IDs. It reserves IDs in the shared run set before awaiting the exclusive write. Only after the write succeeds does it update saved counters and advance to the next cursor.”

**If challenged on the shared set:** JavaScript's synchronous check-and-reserve block finishes before another callback can interleave at an `await`. This protects workers in the same process. It is not a distributed lock across multiple processes.

**If challenged on failure:** no new windows are assigned after the first recorded failure. Already-active windows finish their own remaining work. The run then fails and retains an incomplete manifest; it does not publish partial success or resume automatically.

### “Walk me through `2024 2026 CARROTS`.”

**Recall:** parse → validate all → select reports → normalize lists → calculate → chart → print.

> “The parser selects 2024 through 2026 and the phrase `CARROTS`. The loader validates every manifest-listed report before filtering. The selector keeps reports in that year range with a matching suspect product and retains only matching names for the product ranking. The DataFrame keeps one report per row, with normalized term lists and a converted age. Ranking explodes one list column at a time. Averages and the histogram share the same valid-age helper. The chart is saved before the success summary is printed.”

**Tiny example:** one selected report contains `Organic Carrots`, `ORGANIC CARROTS!`, and nonmatching suspect `Vitamin D3`, with age 40. Result: one report, one normalized carrot mention, one age observation, and no vitamin entry in the filtered product ranking.

**Zero-match result:** successful empty analysis, three `N/A` averages, empty rankings, zero annual bars, and a chart saying `No valid ages`. No matching records is not a broken dataset.

## Glossary: 54 terms connected to this code

Definitions are deliberately short. The function pointer tells you where to look if Alex asks for implementation detail. **JS** means `part1.js`; **PY** means `part2.py`.

| Term | Definition here | Where |
|---|---|---|
| API endpoint | The specific food-event URL accepting requests. | JS `getPageUrl` |
| HTTP GET | A read request; retrying it does not intentionally modify FDA data. | JS `fetchPage` |
| Query parameter | A named URL input such as search, limit, or sort. | JS `getPageUrl` |
| Response envelope | Metadata plus results retained in each saved JSON document. | JS `downloadWindow` |
| Cursor pagination | Requesting the next slice using the server's continuation token. | JS `getNextUrl` |
| Opaque cursor | A token used without inventing or decoding its ordering semantics. | JS `getNextUrl` |
| Offset pagination | Skipping a numeric number of results; not the advancing mechanism here. | JS `getNextUrl` |
| Link header | HTTP metadata containing relationships such as the next-page URL. | JS `getNextUrl` |
| Partition/window | A date interval assigned independently to a worker. | JS `getWindows` |
| Inclusive bounds | Both boundary dates belong to the requested interval. | JS `checkPage` |
| UTC | Time basis used for JavaScript date validation, avoiding local-zone shifts. | JS `checkDate` |
| Concurrency | Overlapping operations; multiple requests can remain in flight. | JS `downloadAll` |
| Worker pool | A bounded set of asynchronous loops taking pending windows. | JS `downloadAll.worker` |
| Promise | A JavaScript object representing eventual success or failure. | JS `createRequester` |
| Closure | A function retaining access to variables in its defining scope. | JS `createRequester` returns `requestPage` |
| `await` | Pause this async function while allowing other work to proceed. | JS `downloadWindow` |
| Event loop | Scheduling that lets asynchronous I/O overlap in this Node process. | JS `downloadAll` |
| Shared state | Values visible to multiple workers, including IDs and failure status. | JS `downloadAll` |
| Race condition | Incorrect behavior dependent on when operations interleave. | JS ID reservation in `downloadWindow` |
| Request pacing | Minimum spacing between attempt start times, across all workers. | JS `createRequester` |
| Admission queue | Promise chain deciding when attempts may start; does not serialize responses. | JS `waitForStart` |
| Timeout | Maximum network-attempt duration before an abort signal fires. | JS `createRequester` |
| Abort signal | Cancellation signal passed into fetch and response reading. | JS `fetchPage` |
| Transient failure | A failure treated as potentially recoverable through bounded retries. | JS `createRequester` |
| Exponential backoff | Retry waits growing approximately 1, 2, then 4 seconds. | JS `createRequester` |
| Jitter | Added random 0–249 ms to spread retry timing. | JS `createRequester` |
| `Retry-After` | Server-provided delay in seconds or as an HTTP date. | JS `getRetryDelay` |
| Shared cooldown | Earliest permitted start extended across workers after a 429. | JS `createRequester` |
| Exclusive creation | `wx` refuses to replace an existing page or temporary manifest. | JS `downloadWindow` / `downloadAll` |
| Idempotency | Same intended effect on repetition; GET is a read, while repeating this command on its existing output path fails protectively. | JS `fetchPage` / `downloadAll` |
| Completion manifest | Inventory and reconciliation metadata marking an analysis-ready run. | JS `downloadAll`; PY `loadManifest` |
| Publication by rename | Replace the incomplete marker after the completed file is written. | JS `downloadAll` |
| Reconciliation | Cross-checking saved counts, observed totals, and unique IDs. | Both loaders/downloaders |
| Snapshot isolation | Reading one stable logical data version throughout; this API traversal does not provide that guarantee. | Limitation of JS `downloadAll` |
| Checksum | A content-derived digest for detecting file changes; none is currently recorded. | Potential manifest enhancement |
| Invariant | A condition the program requires to stay true, such as report uniqueness. | Both parts |
| Schema validation | Checking expected field shapes and types before using them. | JS `checkPage`; PY `checkReport` |
| Path containment | Rejecting a manifest path that resolves outside the data root. | PY `getPagePath` |
| Provenance | Information connecting derived output to its source snapshot and rules. | Manifest + retained reports |
| Dependency injection | Passing fetch, clock, wait, or paths so tests control external effects. | JS `createRequester`; PY `main` |
| Regression test | A test preserving expected behavior when later changes might break it. | Local `tests/` suites |
| DataFrame grain | What one table row represents: one selected report. | PY `makeDataFrame` |
| Literal substring | Exact character sequence searched within a name, with case folded. | PY `getSuspectProducts` |
| Casefold | Unicode-aware conversion for case-insensitive comparison. | PY `getSuspectProducts` |
| NFKC normalization | Canonicalizing compatible Unicode presentation forms. | PY `normalizeTerm` |
| Alias mapping | Explicit rules grouping selected spelling/reporting variants. | PY `normalizeTerm` |
| Deduplication | Removing repeated normalized term contributions within one report. | PY `normalizeTerms` |
| `explode` | Turning a list-valued Series into one entry per list element. | PY `getTopTerms` |
| Cartesian product | Every combination across lists; sequentially exploding 2 products and 3 reactions can create 6 rows. | Avoided by PY `makeDataFrame` / `getTopTerms` |
| Aggregation | Combining observations into counts or means. | PY `getTopTerms` / `getAgeAverage` |
| Deterministic tie-break | Equal counts ordered by normalized term text before taking 25. | PY `getTopTerms` |
| Denominator | The observations included in an average; only valid selected ages here. | PY `getValidAges` |
| Histogram bin | A one-year interval collecting converted age observations. | PY `buildChart` |
| Headless rendering | Producing a PNG without opening a desktop chart window. | PY `Agg` backend / `saveChart` |

## The traps Alex could put in front of you

| Prompt | Answer you want available |
|---|---|
| “A page has 73 results. Done?” | “Not necessarily. I follow a valid next cursor, then reconcile totals when the chain ends.” |
| “Does three workers mean three requests every 300 ms?” | “No. The shared gate spaces starts across the run; workers bound in-flight work.” |
| “Three retries means three attempts?” | “Four total: the initial request plus three retries.” |
| “Why not fetch all next pages concurrently?” | “Their cursor URLs are discovered sequentially. I parallelize independent windows.” |
| “The JSON files exist, so the run succeeded?” | “Only if completion was published and the manifest and loaded data reconcile.” |
| “A complete manifest proves no data changed?” | “It proves the checks this run performed, not immutable source contents or cryptographic integrity.” |
| “Two identical products double the report count?” | “No. One row per report, and normalization precedes per-report term deduplication.” |
| “Are all products in a matched report ranked?” | “Only the matching suspect names when a product filter is present.” |
| “Vitamin D aliases make search alias-aware?” | “No. Search uses original names; normalization groups the selected names afterward.” |
| “Does one year argument mean only that year?” | “It means that year through 2026. Repeat the year twice for a single-year range.” |
| “Why fewer than 25 outcomes?” | “Only 13 normalized categories exist in this snapshot; the requirement is up to 25.” |
| “Does missing gender mean drop the age?” | “No. A valid age remains in the overall mean.” |
| “Is overall mean the average of the two group means?” | “No. It is calculated directly from all valid ages, including unknown-gender reports.” |
| “Are D2 and D3 the same substance?” | “They are grouped as the required reporting family; this does not assert chemical identity.” |
| “Is the most reported product the most dangerous?” | “That cannot be concluded from report counts without exposure denominators and causal evidence.” |

Two weaknesses to discuss plainly if asked: general punctuation cleanup can merge distinct numeric spellings, and a sufficiently huge integer age can escape the intended invalid-age handling through `OverflowError`. Explain the narrow fix or policy improvement; do not claim it is already implemented. The intended distinction is **current behavior → limitation → next change**.

## A focused 30-minute study route

**Minutes 0–5 — Say the opening, then the 12 facts.** Read the opening once. Close the document and rebuild it from five words: purpose, download, completion, analysis, limitation. Numbers to retain: **100 / 3 / 24 / 987 / 97,652**. Secondary numbers: **300 ms / 30 seconds / four attempts / 73,819 valid ages**.

**Minutes 5–12 — Trace Part 1 with the file open.** Find `downloadAll`, `worker`, `downloadWindow`, and `createRequester`. Point to the first `await` after claiming a window, the shared ID reservation before writing, and the final manifest rename. Explain one success and one failure without reading whole paragraphs.

**Minutes 12–19 — Trace Part 2 with a tiny report.** Find `main`, `selectReports`, `makeDataFrame`, `normalizeTerms`, and `getTopTerms`. Explain what happens when one report has two duplicate carrot names, one nonmatching suspect, repeated reactions, and an invalid age. Keep asking: “What does one row mean now?”

**Minutes 19–25 — Answer the traps aloud.** Give one or two sentences, then stop. If stuck, locate the function; do not compensate by reciting unrelated library vocabulary. Mark only the three answers that need another pass.

**Minutes 25–30 — Run the mock drill below.** Cover the answers. Explain each result before checking. Finish with your evidence statement and two candid improvements. The objective is reliable reasoning under interruption, not perfect recitation.

## Mock drill: predict first, then check

1. **A cursor repeats but returns new-looking records. Continue?** No. Repeated cursors fail validation; apparent record novelty does not override pagination integrity.
2. **A 401 arrives. Retry?** No. It is not in the temporary-response set; repeated requests will not fix authorization.
3. **One worker fails while two windows are active. Immediate process exit?** No. Stop assigning new windows, let active windows finish, then fail the run with incomplete status.
4. **A bad report exists in 2005; the command selects 2024. Ignore it?** No. All manifest-listed reports are validated before selection.
5. **A report has `Rash`, `RASH!`, and `Nausea`. Counts?** One RASH contribution and one NAUSEA contribution; one report total.
6. **Age is six months. Histogram position?** Converted age 0.5 belongs to the 0–1-year bin. It remains 0.5 in the mean.
7. **Age is exactly 125 years. Included?** Yes. The valid-age bound includes 125; edges through 126 give it a final histogram bin.
8. **Ages are 20/Female, 40/Male, and 90/unknown. Overall mean?** 50 years. The two named group means are 20 and 40; their average is not the overall mean.
9. **Chart saving fails after calculation. Successful summary printed?** No. The save precedes `printSummary`; the expected write error becomes a data error and nonzero exit.
10. **What can you honestly say about testing today?** Fresh Node cases and full-dataset disk validation passed. Python's 31-test result and completed-run timing are documented historical evidence, not a new run in the current dependency-limited environment.

If you cannot recall a detail, use: **“I want to check the exact branch rather than guess. The invariant here is …”** Then locate the function and trace it. That is a stronger review habit than inventing certainty while the code sits three inches away.
