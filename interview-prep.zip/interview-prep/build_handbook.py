"""Build the offline study handbook from Markdown and two explicit source files.

Uses Python's standard library and the already installed bundled Node/marked.
Reads only the requested Markdown, part1.js, part2.py, and the README's chart.
No application execution, API requests, directory scans, or credential reads.
"""

from __future__ import annotations

import argparse
import base64
import html
import json
import re
import subprocess
import unicodedata
from html.parser import HTMLParser
from pathlib import Path
from urllib.parse import unquote


HERE = Path(__file__).resolve().parent
PROJECT = HERE.parent
RUNTIME = Path.home() / ".cache/codex-runtimes/codex-primary-runtime/dependencies"
NODE = RUNTIME / "node/bin/node.exe"
MARKED = RUNTIME / "node/node_modules/marked/lib/marked.esm.js"
CHART = PROJECT / "charts/20260904-161132-070140.png"


class TextOnly(HTMLParser):
    def __init__(self):
        super().__init__()
        self.parts = []

    def handle_data(self, value):
        self.parts.append(value)


def plain(value):
    parser = TextOnly()
    parser.feed(value)
    return "".join(parser.parts).strip()


def render_markdown(markdown):
    if not NODE.is_file() or not MARKED.is_file():
        raise RuntimeError("The preinstalled bundled Node/marked renderer was not found.")
    program = """
      import fs from 'node:fs';
      const { marked } = await import(process.argv[1]);
      const input = JSON.parse(fs.readFileSync(0, 'utf8'));
      process.stdout.write(marked.parse(input.markdown, { gfm: true, breaks: false }));
    """
    result = subprocess.run(
        [str(NODE), "--input-type=module", "-e", program, MARKED.as_uri()],
        input=json.dumps({"markdown": markdown}),
        capture_output=True, text=True, encoding="utf-8", check=True,
    )
    return result.stdout


def add_headings(document):
    headings = []
    used = set()

    def replace(match):
        level, attrs, content = match.groups()
        title = plain(content)
        existing = re.search(r'\bid=["\']([^"\']+)', attrs)
        slug = existing.group(1) if existing else re.sub(
            r"[^a-z0-9]+", "-",
            unicodedata.normalize("NFKD", title).encode("ascii", "ignore").decode().lower(),
        ).strip("-") or "section"
        base = slug
        number = 2
        while slug in used:
            slug = f"{base}-{number}"
            number += 1
        used.add(slug)
        attrs = re.sub(r'\s+id=["\'][^"\']+["\']', "", attrs)
        headings.append({"level": int(level), "title": title, "id": slug})
        return f'<h{level}{attrs} id="{html.escape(slug)}">{content}</h{level}>'

    document = re.sub(r"<h([1-6])([^>]*)>(.*?)</h\1>", replace, document, flags=re.S)
    return document, headings


def convert_source_links(document):
    def replace(match):
        before, href, after = match.groups()
        value = unquote(html.unescape(href)).replace("\\", "/")
        source = re.search(r"(?:^|/)(part1\.js|part2\.py)(?::(\d+)|#L?(\d+))?(?:[-–]L?\d+)?$", value)
        if source:
            filename, colon_line, hash_line = source.groups()
            prefix = "part1" if filename == "part1.js" else "part2"
            return f'{before}#{prefix}-L{colon_line or hash_line or "1"}{after}'
        return match.group(0)

    return re.sub(r'(<a\b[^>]*\bhref=")([^"]+)(")', replace, document)


def make_toc(headings):
    # Two levels keep the sidebar useful even in a long, detailed handbook.
    entries = [h for h in headings if h["level"] in (1, 2, 3)]
    parts = []
    for heading in entries:
        depth = "toc-sub" if heading["level"] == 3 else "toc-main"
        parts.append(
            f'<a class="{depth}" href="#{html.escape(heading["id"])}">'
            f'{html.escape(heading["title"])}</a>'
        )
    parts.append('<a class="toc-main" href="#source-code">Source code appendix</a>')
    parts.append('<a class="toc-sub" href="#part1-L1">part1.js · downloader</a>')
    parts.append('<a class="toc-sub" href="#part2-L1">part2.py · analysis</a>')
    return "\n".join(parts)


def section_buttons(headings):
    labels = ["1 · Technical walkthrough", "2 · Review questions", "3 · Memorize first"]
    buttons = []
    for index, label in enumerate(labels, 1):
        heading = next((h for h in headings if re.match(
            rf"^(?:section\s+)?{index}(?:\b|[.:])", h["title"], re.I)), None)
        if heading:
            buttons.append(f'<a href="#{html.escape(heading["id"])}">{label}</a>')
    return "".join(buttons)


def source_panel(filename, prefix, subtitle):
    source = (PROJECT / filename).read_text(encoding="utf-8")
    lines = []
    for number, line in enumerate(source.splitlines(), 1):
        lines.append(
            f'<div class="source-line" id="{prefix}-L{number}">'
            f'<a class="line-no" href="#{prefix}-L{number}" aria-label="Line {number}">{number}</a>'
            f'<code>{html.escape(line) or " "}</code></div>'
        )
    return (
        f'<details class="source-panel"><summary><span>{filename}</span>'
        f'<small>{len(lines)} lines · {subtitle}</small></summary>'
        f'<div class="source-code">{"".join(lines)}</div></details>'
    )


CSS = r"""
:root{--ink:#172b3a;--muted:#586c78;--paper:#fffefa;--canvas:#f2f4f2;--line:#dbe3df;--green:#145947;--accent:#b55730;--code:#eef2f0;--nav:294px}
*{box-sizing:border-box}html{scroll-behavior:smooth;scroll-padding-top:32px}body{margin:0;color:var(--ink);background:var(--canvas);font:16px/1.72 system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif}a{color:var(--green);text-decoration-thickness:1px;text-underline-offset:3px}a:hover{color:var(--accent)}button,input{font:inherit}button{cursor:pointer}a:focus-visible,button:focus-visible,input:focus-visible,summary:focus-visible{outline:3px solid #de9f31;outline-offset:3px}.skip-link{position:absolute;left:12px;top:-60px;background:white;padding:12px;z-index:100}.skip-link:focus{top:12px}
.sidebar{position:fixed;inset:0 auto 0 0;width:var(--nav);background:#102e2c;color:#e8f2ea;display:flex;flex-direction:column;padding:28px 18px 16px;z-index:20;border-right:1px solid #264340}.brand{font-weight:760;font-size:17px;letter-spacing:.025em;padding:0 10px}.brand small{display:block;font-size:11px;text-transform:uppercase;letter-spacing:.13em;color:#a7c1b7;margin-top:4px}.sidebar input{width:100%;margin:24px 0 14px;border:1px solid #42605a;border-radius:7px;background:#1b3e39;color:white;padding:9px 12px;font-size:13px}.sidebar input::placeholder{color:#c0d2cc}.toc{overflow-y:auto;overscroll-behavior:contain;padding-right:6px;scrollbar-width:thin;scrollbar-color:#55766b transparent}.toc a{display:block;color:#d7e7de;text-decoration:none;border-radius:5px;padding:7px 10px;font-size:12px;line-height:1.5;margin:2px 0}.toc a:hover,.toc a.active{background:#284e44;color:white}.toc .toc-main{font-weight:680}.toc .toc-sub{padding-left:22px;color:#b6cdc2;font-size:11.5px}.toc a[hidden]{display:none}.sidebar-footer{font-size:11px;line-height:1.6;color:#adc2b9;padding:16px 10px 0}.reading-area{margin-left:var(--nav);padding:42px 5vw 90px}.document{max-width:1040px;margin:0 auto;background:var(--paper);border:1px solid var(--line);border-radius:12px;box-shadow:0 10px 40px #173d2910;overflow:hidden}.hero{padding:42px 56px 32px;border-bottom:1px solid var(--line);background:linear-gradient(140deg,#f9fbf2,#edf3ed)}.eyebrow{font-size:11px;letter-spacing:.16em;text-transform:uppercase;color:var(--green);font-weight:760}.hero h1{font:750 clamp(30px,3.4vw,43px)/1.16 system-ui,sans-serif;letter-spacing:-.035em;margin:15px 0 12px;max-width:850px}.hero p{font-size:15px;line-height:1.6;color:var(--muted);margin:0}.jump-links{display:flex;flex-wrap:wrap;gap:8px;margin-top:26px}.jump-links a{padding:8px 12px;background:white;border:1px solid #c9d7ca;border-radius:6px;font-size:12px;font-weight:690;text-decoration:none}.toolbar{display:flex;flex-wrap:wrap;gap:12px;align-items:center;padding:14px 56px;border-bottom:1px solid var(--line);background:#fafbf7;font-size:12px}.toolbar button{border:1px solid #cbd7cf;border-radius:5px;padding:6px 10px;background:white;color:var(--green);font-size:12px}.toolbar label{display:flex;align-items:center;gap:6px;color:var(--muted)}.toolbar .hint{margin-left:auto;color:var(--muted)}.content{padding:20px 56px 58px;overflow-wrap:anywhere}.content h1{font-size:30px;line-height:1.3;border-top:3px solid var(--green);padding-top:25px;margin:56px 0 20px;letter-spacing:-.025em}.content h2{font-size:24px;line-height:1.35;margin:44px 0 17px;letter-spacing:-.025em;color:#174b3a;padding-bottom:10px;border-bottom:1px solid #d9e3d8}.content h3{font-size:19px;line-height:1.4;margin:30px 0 12px;letter-spacing:-.01em}.content h4{font-size:16px;line-height:1.45;margin:24px 0 9px}.content p{margin:13px 0 18px}.content strong{font-weight:730}.content li{margin:7px 0}.content ul,.content ol{padding-left:25px;margin:14px 0 20px}.content blockquote{margin:20px 0;padding:5px 21px;border-left:4px solid #7c9f69;background:#f0f5e9;border-radius:0 7px 7px 0;color:#264933}.content blockquote p{margin:11px 0}.content hr{border:0;border-top:1px solid var(--line);margin:36px 0}.content :not(pre)>code{font:.88em/1.6 Consolas,"Courier New",monospace;background:var(--code);padding:2px 5px;border-radius:4px;overflow-wrap:anywhere}.content pre{background:#162d31;color:#edf4ee;padding:20px 22px;border-radius:7px;overflow:auto;line-height:1.58;font:12.5px/1.58 Consolas,"Courier New",monospace;margin:20px 0;tab-size:2}.content pre code{white-space:pre;font:inherit;background:none;padding:0;color:inherit}.table-scroll{overflow-x:auto;margin:22px 0;border:1px solid var(--line);border-radius:6px}.content table{border-collapse:collapse;width:100%;font-size:13px;line-height:1.58}.content th{background:#e9f0e8;color:#274f3e;font-weight:740;text-align:left;vertical-align:top}.content td,.content th{padding:10px 12px;border-bottom:1px solid var(--line);min-width:90px}.content td{vertical-align:top}.content tr:last-child td{border-bottom:0}.content tbody tr:nth-child(even){background:#f8f9f4}.content img{max-width:100%;height:auto}.snapshot-chart{margin:30px 0;padding:18px;border:1px solid var(--line);border-radius:8px;background:white}.snapshot-chart img{display:block;width:100%;height:auto}.snapshot-chart figcaption{font-size:12px;line-height:1.6;color:var(--muted);margin-top:12px}.source-appendix{border-top:3px solid var(--green);margin-top:50px;padding-top:10px}.source-intro{font-size:14px;color:var(--muted)}.source-panel{border:1px solid #cbd8cf;border-radius:7px;margin:16px 0;overflow:hidden;background:#f7faf6}.source-panel summary{cursor:pointer;display:flex;justify-content:space-between;align-items:center;gap:20px;padding:14px 16px;color:var(--green);font-weight:750;background:#edf3e9;list-style:none}.source-panel summary::before{content:'+';font-size:20px;font-weight:500}.source-panel[open] summary::before{content:'−'}.source-panel summary span{margin-right:auto}.source-panel summary small{font-size:11px;color:var(--muted);font-weight:500}.source-code{overflow:auto;padding:10px 0;background:#fffefa;font:12px/1.65 Consolas,"Courier New",monospace;tab-size:2}.source-line{display:grid;grid-template-columns:55px max-content;min-width:100%}.source-line:target{background:#fff0b8}.source-line:hover{background:#f1f5eb}.source-line .line-no{display:block;user-select:none;color:#84938b;text-align:right;padding:0 13px 0 5px;border-right:1px solid #e2e8df;text-decoration:none;font:inherit}.source-line code{display:block;white-space:pre!important;background:none!important;border-radius:0!important;padding:0 15px!important;font:inherit!important;color:#243d36;overflow-wrap:normal!important}.closing{margin-top:38px;padding-top:20px;border-top:1px solid var(--line);font-size:11px;color:var(--muted)}.mobile-nav{display:none}.back-top{position:fixed;right:20px;bottom:20px;background:var(--green);color:white;text-decoration:none;padding:8px 12px;border-radius:20px;font-size:12px;box-shadow:0 4px 15px #12332222}.back-top:hover{color:white;background:#227755}
@media(max-width:1100px){:root{--nav:250px}.reading-area{padding:25px 3vw 70px}.hero{padding:34px 34px 28px}.toolbar{padding:13px 34px}.content{padding:15px 34px 44px}}
@media(max-width:800px){.sidebar{display:none;position:fixed;inset:52px 0 0 0;width:auto;padding-top:20px}.sidebar.visible{display:flex}.mobile-nav{display:flex;align-items:center;justify-content:space-between;position:sticky;top:0;background:#102e2c;color:white;padding:10px 16px;height:52px;z-index:30;font-size:13px}.mobile-nav button{background:none;color:white;border:1px solid #688b7d;padding:3px 10px;border-radius:4px;font-size:12px}.reading-area{margin:0;padding:15px 12px 55px}.hero{padding:28px 23px 25px}.content{padding:10px 23px 32px}.toolbar{padding:12px 23px}.toolbar .hint{display:none}.hero h1{font-size:31px}.content h1{font-size:26px}.content h2{font-size:21px}.content h3{font-size:18px}.content pre{font-size:11px;padding:15px}.content table{font-size:12px}.jump-links a{font-size:11px}.back-top{right:12px;bottom:12px}.source-panel summary{gap:10px}.source-panel summary small{max-width:145px;text-align:right}.source-line{grid-template-columns:43px max-content}html{scroll-padding-top:67px}}
@media print{@page{size:A4;margin:16mm 15mm 17mm}html{scroll-behavior:auto}body{background:white;font-size:10.1pt;line-height:1.53;color:#111}.sidebar,.toolbar,.mobile-nav,.back-top,.jump-links,.skip-link{display:none!important}.reading-area{margin:0;padding:0}.document{border:0;border-radius:0;box-shadow:none;max-width:none;overflow:visible}.hero{padding:0 0 20px;background:none;border-bottom:2px solid #315442}.hero h1{font-size:27pt}.hero p{font-size:10pt}.eyebrow{font-size:8pt}.content{padding:0}.content h1{font-size:21pt;break-before:page;margin-top:0}.content h2{font-size:16pt;margin-top:24px;break-after:avoid}.content h3{font-size:13pt;break-after:avoid}.content h4{break-after:avoid}.content p{orphans:3;widows:3}.content pre{font-size:8pt;line-height:1.42;white-space:pre-wrap;overflow:visible;background:#f4f5f1;color:#111;border:1px solid #d9dfd6;padding:10px;break-inside:auto}.content pre code{white-space:pre-wrap;overflow-wrap:anywhere}.content blockquote{break-inside:avoid}.table-scroll{overflow:visible;border:0;break-inside:auto}.content table{font-size:8.5pt;table-layout:auto}.content th,.content td{padding:6px 7px;min-width:0}.content thead{display:table-header-group}.content tr{break-inside:avoid}a{color:inherit;text-decoration:none}.snapshot-chart{break-inside:avoid;border:0;padding:0}.snapshot-chart img{max-height:210mm;object-fit:contain}.source-appendix{display:none}.print-source .source-appendix{display:block;break-before:page}.source-panel{break-inside:auto;border:0}.source-panel summary{background:none;padding:10px 0}.source-panel summary::before{display:none}.source-code{font-size:7.1pt;overflow:visible}.source-line{grid-template-columns:28px 1fr}.source-line code{white-space:pre-wrap!important;overflow-wrap:anywhere!important;padding-left:8px!important}.source-line .line-no{padding-right:5px}.closing{font-size:8pt}}
"""


JS = r"""
const sidebar = document.querySelector('.sidebar');
const menuButton = document.querySelector('#toggle-nav');
menuButton.addEventListener('click', () => {
  const visible = sidebar.classList.toggle('visible');
  menuButton.setAttribute('aria-expanded', String(visible));
});
document.querySelector('#toc-filter').addEventListener('input', event => {
  const query = event.target.value.trim().toLocaleLowerCase();
  document.querySelectorAll('.toc a').forEach(link => {
    link.hidden = !link.textContent.toLocaleLowerCase().includes(query);
  });
});
document.querySelectorAll('.toc a').forEach(link => link.addEventListener('click', () => {
  sidebar.classList.remove('visible');
  menuButton.setAttribute('aria-expanded', 'false');
}));
function revealSource() {
  if (!location.hash) return;
  let target;
  try { target = document.getElementById(decodeURIComponent(location.hash.slice(1))); } catch { return; }
  if (!target) return;
  const panel = target.closest('details');
  if (panel) { panel.open = true; requestAnimationFrame(() => target.scrollIntoView({block:'center'})); }
}
window.addEventListener('hashchange', revealSource);
revealSource();
document.querySelector('#print-document').addEventListener('click', () => window.print());
document.querySelector('#include-source').addEventListener('change', event => {
  document.body.classList.toggle('print-source', event.target.checked);
});
let formerlyOpen = [];
window.addEventListener('beforeprint', () => {
  formerlyOpen = Array.from(document.querySelectorAll('details')).filter(panel => panel.open);
  document.querySelectorAll('details').forEach(panel => { panel.open = true; });
});
window.addEventListener('afterprint', () => {
  document.querySelectorAll('details').forEach(panel => { panel.open = formerlyOpen.includes(panel); });
});
const navLinks = new Map(Array.from(document.querySelectorAll('.toc a')).map(link => [link.hash.slice(1), link]));
const observer = new IntersectionObserver(entries => {
  entries.filter(entry => entry.isIntersecting).forEach(entry => {
    document.querySelectorAll('.toc a.active').forEach(link => link.classList.remove('active'));
    navLinks.get(entry.target.id)?.classList.add('active');
  });
}, {rootMargin:'0px 0px -75% 0px'});
document.querySelectorAll('.content h1[id],.content h2[id],.content h3[id]').forEach(heading => observer.observe(heading));
"""


def build(input_path, output_path):
    markdown = input_path.read_text(encoding="utf-8")
    document, headings = add_headings(render_markdown(markdown))
    document = convert_source_links(document)
    document = re.sub(r"(<table\b.*?</table>)", r'<div class="table-scroll">\1</div>', document, flags=re.S)
    title = headings[0]["title"] if headings and headings[0]["level"] == 1 else "USAN code review handbook"
    if headings and headings[0]["level"] == 1:
        document = re.sub(r"^\s*<h1\b.*?</h1>\s*", "", document, count=1, flags=re.S)
        headings = headings[1:]

    chart = ""
    if CHART.is_file():
        encoded = base64.b64encode(CHART.read_bytes()).decode("ascii")
        image_src = f"data:image/png;base64,{encoded}"
        # Any existing Markdown reference is embedded in place; otherwise add it to the appendix.
        document, chart_count = re.subn(
            r'(<img\b[^>]*\bsrc=")[^"]*20260904-161132-070140\.png(")',
            lambda match: match.group(1) + image_src + match.group(2), document,
        )
        if not chart_count:
            chart = (
                '<figure class="snapshot-chart"><img src="' + image_src + '" '
                'alt="Saved overall analysis: annual report counts and one-year consumer age bins">'
                '<figcaption>Existing overall chart from the repository. The 2026 bar covers January 1 only. '
                'The histogram counts reports with valid ages, not unique people. This image is embedded '
                'in the document and requires no network connection.</figcaption></figure>'
            )

    appendix = (
        ('<section class="reference-figure"><h2 id="saved-snapshot-chart">Saved snapshot chart</h2>' + chart + '</section>' if chart else '')
        + '<section class="source-appendix" id="source-code"><h2>Source code appendix</h2>'
        '<p class="source-intro">The current application source is included below for direct reference. '
        'Code links in the guide jump to the corresponding numbered line. Expand either file to read it; '
        'source listings are omitted from printing unless “Include source appendix” is checked.</p>'
        + source_panel("part1.js", "part1", "FDA downloader")
        + source_panel("part2.py", "part2", "analysis and charts")
        + '</section>'
    )
    content = f"""<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="color-scheme" content="light"><title>{html.escape(title)}</title>
<style>{CSS}</style></head><body id="top">
<a class="skip-link" href="#handbook">Skip to the handbook</a>
<div class="mobile-nav"><span>USAN · Code review preparation</span><button id="toggle-nav" aria-controls="study-nav" aria-expanded="false">Contents</button></div>
<aside class="sidebar" id="study-nav" aria-label="Study document contents">
<div class="brand">USAN / Code review<small>FDA data pipeline · Study edition</small></div>
<label for="toc-filter" class="sidebar-footer">Jump to a topic</label><input id="toc-filter" type="search" placeholder="Filter the table of contents…">
<nav class="toc" aria-label="Table of contents">{make_toc(headings)}</nav>
<div class="sidebar-footer">Use Ctrl+F or ⌘F to search the handbook.<br>All text, source, styles, and images are available offline.</div></aside>
<main class="reading-area" id="handbook"><article class="document">
<header class="hero"><div class="eyebrow">Technical understanding · Decision rationale · Interview practice</div>
<h1>{html.escape(title)}</h1><p>A reference for understanding the implementation, explaining your decisions, and practicing the follow-up questions.</p>
<div class="jump-links">{section_buttons(headings)}</div></header>
<div class="toolbar"><button id="print-document">Print / Save as PDF</button><label><input type="checkbox" id="include-source"> Include source appendix</label><span class="hint">Search anywhere: Ctrl+F / ⌘F</span></div>
<div class="content">{document}{appendix}<footer class="closing">Offline study document · Source embedded from the current local checkout · Application files are included for reference and are never executed by this document.</footer></div>
</article></main><a class="back-top" href="#top" aria-label="Return to top">↑ Top</a>
<script>{JS}</script></body></html>"""
    output_path.write_text(content, encoding="utf-8")
    print(json.dumps({"output": str(output_path), "bytes": output_path.stat().st_size,
                      "headings": len(headings), "source_lines": sum(len((PROJECT / file).read_text(encoding="utf-8").splitlines()) for file in ("part1.js", "part2.py")),
                      "renderer": "Python standard library + preinstalled Node marked", "network": False}, indent=2))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", type=Path, default=HERE / "USAN_CODE_REVIEW_HANDBOOK.md")
    parser.add_argument("--output", type=Path, default=HERE / "USAN_CODE_REVIEW_HANDBOOK.html")
    args = parser.parse_args()
    build(args.input.resolve(), args.output.resolve())
