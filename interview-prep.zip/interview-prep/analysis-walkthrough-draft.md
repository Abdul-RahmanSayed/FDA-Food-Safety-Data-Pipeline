# Part 2: technical walkthrough and decision rationale

This walkthrough describes the current 512-line `part2.py`, inspected on September 6, 2026. Source ranges refer to that version. It explains the code that exists; proposed improvements are explicitly identified. The historical rationale comes from `REVIEW_NOTES.md`, especially lines 275–309 and 638–967, rather than from invented personal recollections.

## The story to tell before opening the file

> “Part 1 produces the raw snapshot and its completion manifest. Part 2 treats that manifest as the inventory, validates the entire listed dataset, selects reports by year and optional suspect-product text, and creates one row per report. From that common table I calculate report-level term frequencies, valid-age averages, and two plots. I keep filtering separate from normalization so the requested literal search behavior does not silently change. I also preserve the raw report alongside the derived fields so the transformations are traceable.”

This is an offline analysis program. `part2.py` does not import an HTTP client, read an API key, contact FDA, update the snapshot, or derive “present” from today's date. Its default data and chart paths are anchored to the script's directory.

### The central invariant

**One DataFrame row means one selected adverse-event report, not one product, reaction, or unique person.** A report can have several suspect products and reactions. Those nested lists are flattened separately only when counting terms. The report total and age calculations therefore do not multiply a person's recorded age by the number of attached products.

There are two distinct kinds of deduplication:

| Operation | Where | Behavior and reason |
|---|---|---|
| Report identity validation | `loadReports`, lines 239–255 | A repeated `report_number` is a fatal data error, rather than silently discarded. Silent deduplication would conceal an ingestion or snapshot problem. |
| Term deduplication within a report | `normalizeTerms`, lines 337–340 | Equivalent labels collapse to one contribution per term per report, as required by the counting policy. |

Deduplicating report IDs does **not** prove reports describe different people or different real-world incidents. This is a report dataset.

## End-to-end control flow and data shapes

```text
Command line
    ↓
runCli → main
    ↓
parseArgs → {startYear, endYear, productFilter}
    ↓
loadReports
    ├─ loadManifest → validated completion metadata and page inventory
    └─ read listed pages → validate every report → list of raw report dictionaries
    ↓
selectReports → [{report: original dictionary, suspectProducts: eligible raw names}]
    ↓
makeDataFrame → one row per report, normalized lists + year + ageYears + gender
    ↓
saveChart → buildChart → annual counts + valid-age histogram → PNG
    ↓
printSummary → total + Top 25 lists + age means
    ↓
print chart path → return DataFrame → exit 0
```

Saving the image happens **before** printing the success summary. If the required image cannot be written, the command reports an error instead of first printing an apparently complete result.

The shapes are worth recognizing on sight:

```python
# parseArgs output
{"startYear": 2024, "endYear": 2026, "productFilter": "CARROTS"}

# One selected item, before normalization
{
    "report": original_report_dictionary,
    "suspectProducts": ["Organic Baby Carrots", "ORGANIC BABY CARROTS!"]
}

# One DataFrame row, after normalization
{
    "report": original_report_dictionary,
    "suspectProducts": ["ORGANIC BABY CARROTS"],
    "outcomes": ["OTHER OUTCOME"],
    "reactions": ["NAUSEA", "RASH"],
    "year": 2024,
    "ageYears": 40.0,
    "gender": "Female"
}

# getTopTerms output
[("NAUSEA", 3), ("RASH", 2)]
```

The original report is retained by reference, not deep-copied. New lists hold derived, normalized terms. `selectReports` and `makeDataFrame` do not rewrite the original FDA fields or the JSON files.

## Imports, constants, and exceptions: lines 1–55

| Lines | What executes | Why it is present |
|---|---|---|
| 1–6 | Import JSON, regular expressions, CLI access, Unicode normalization, date arithmetic, and filesystem paths. | Standard-library responsibilities do not need extra packages. |
| 8–11 | Import Matplotlib, NumPy, pandas, and `MaxNLocator`. | pandas holds the report table and counts; NumPy validates/calculates ages and defines bins; Matplotlib renders the required image. The historical notes say these libraries were assignment requirements, not arbitrary additions. |
| 14–15 | Select Matplotlib's `Agg` backend **before** importing `pyplot`. | `Agg` renders images without opening a desktop window, so the CLI works in unattended or headless environments. |
| 18–21 | Set exact source dates `20020101` through `20260101`, and selectable years 2002 through 2026. | The endpoint is fixed by the assignment. 2026 contains only January 1, not a full year. |
| 22 | Set `maxAge = 125`. | A project plausibility rule applied after unit conversion; it is not an FDA schema rule. |
| 23–24 | Resolve the directory containing the script and append `data` / `charts`. | Launching from another working directory still finds the same dataset and writes beside the script. |
| 25–26 | Precompile the four-digit year pattern and define CLI usage text. | An exact four-digit token is a year; other tokens form the product phrase. |
| 27–33 | Define unit-to-years factors. | A table avoids repeated branches and puts the supported units in one place. |
| 34–36 | Precompile general punctuation, whitespace, and raw hyphenated vitamin patterns. | Reuse expressions across many terms; preserve the meaningful source hyphen before general cleanup removes it. |
| 37–43 | Define four narrow product alias rules. | Make the aggregation policy visible and deterministic. These are applied only to product names. |
| 46–55 | Define `Part2Error`, `UsageError`, and `DataError`. | Separate bad arguments from unusable input/output, allowing distinct exit codes and readable errors. The base class groups project errors conceptually. |

`Path.is_relative_to`, used later, is one reason the README requires Python 3.9 or newer. `requirements.txt` specifies compatible version ranges, not a fully locked environment. A fresh install can resolve different library versions within those ranges.

## Argument parsing: `parseArgs`, lines 58–81

1. **59–60:** Create separate lists for years and product words.
2. **63–66:** Iterate over argument strings, strip their outer whitespace, and reject an empty argument. Shell quoting matters: an explicitly quoted whitespace-only argument arrives as a value and fails here.
3. **67–70:** If the whole argument matches exactly four digits, convert it to an integer and append it to `years`; otherwise append it to `productWords`.
4. **72–75:** Reject more than two year arguments or any year outside 2002–2026.
5. **77–79:** Sort years. No years means 2002–2026; one year means that year–2026; two years mean the inclusive sorted range.
6. **80–81:** Join non-year arguments with one space, or use `None` if there are none; return a small filter dictionary.

| Arguments | Result |
|---|---|
| No arguments | 2002–2026; no product filter |
| `2024` | 2024–2026; **not just 2024** |
| `2024 2024` | 2024 only |
| `CARROTS 2026 2024` | 2024–2026; product phrase `CARROTS` |
| `2024 baby carrots` | 2024–2026; phrase `baby carrots` |
| `"Vitamin D3 2000 IU"` | Whole quoted phrase is a product filter, because the whole argument is not four digits |
| `Vitamin D3 2000 IU` | `2000` is interpreted as an out-of-range year and fails |
| `2024 2025 2026` | Usage error: more than two years |
| `2027` | Usage error: out-of-range year |

Product word order remains significant. Argument order is flexible around years, but `baby carrots` and `carrots baby` are different phrases. There is no flag parser, regular-expression search, OR between product words, or automatic singular/plural expansion. `--help` is currently just a product-search token, not a help option.

**Defensible rationale:** follow the requested positional interface simply and predictably. **Improvement if the interface grows:** explicit `--start-year`, `--end-year`, and `--product` flags would remove numeric-name ambiguity. Do not claim this exists today.

## Small validation helpers: lines 84–132

### `readJson`, lines 84–96

- **85–87:** Open a supplied `Path` as UTF-8 within a context manager, then parse the entire JSON document. The context manager closes the file on success or failure.
- **88–89:** A missing file becomes a contextual `DataError` naming what was missing and its path.
- **90–92:** Invalid JSON becomes a `DataError` with the parser's line and column.
- **93–94:** Invalid encoding becomes a UTF-8 error.
- **95–96:** Other filesystem errors become a readable read failure.

`raise ... from error` preserves the underlying cause for debugging, although the CLI prints only the friendly message. This does not mean all possible exceptions in Python are swallowed: only the listed exception categories are converted.

### `checkDate`, lines 99–106

- Require a string of eight digits.
- Parse it with `%Y%m%d` to reject impossible calendar dates such as February 30.
- Return the original, validated string.

Once the format is validated, comparing these date strings lexicographically gives chronological order because the components run from most significant to least significant: year, month, day. Format-only regex validation would not catch impossible dates.

### `checkCount`, lines 109–112

Require an actual Python integer and a nonnegative value. `type(value) is int` intentionally rejects booleans: Python treats `bool` as a subclass of `int`, so `isinstance(True, int)` would otherwise accept `True` as a count. Return the validated count.

### `checkTerms`, lines 115–121

Require a list, then require every item to be a nonblank string. Labels use one-based indexes for human-readable errors. An empty list is valid: it means no supplied terms, not a broken field. This helper validates the raw terms without changing their spelling.

### `getPagePath`, lines 124–132

- **125–126:** Reject a missing, nonstring, or empty page path.
- **128–129:** Resolve the data root and the supplied relative path to actual absolute paths.
- **130–131:** Reject the root itself and any result outside the data directory.
- **132:** Return the safe path.

This prevents a manifest entry such as `../some-other-file.json` from directing analysis outside its dataset. Resolving before comparison also handles path normalization and existing symlinks. It is a containment check on a local manifest, not a claim that all filesystem races are eliminated.

## Manifest validation: `loadManifest`, lines 135–203

This is the contract between acquisition and analysis. A `complete: true` boolean alone is insufficient; the loader checks that the manifest is internally coherent.

| Lines | Validation |
|---|---|
| 136–139 | Convert the root to a `Path`, load `manifest.json`, and require a JSON object. |
| 140–143 | Require integer schema version 1 and literal boolean `true` completion. |
| 144–147 | Require the exact assignment date range and page limit 100. |
| 149–153 | Require a nonempty windows array, and reconcile its length with `windowCount`. |
| 155–159 | Initialize the set of listed resolved paths, aggregate report/page counts, expected first date, and last end date. |
| 160–167 | For every window, require an object, validate both dates, and enforce ordered start/end within the fixed assignment bounds. |
| 168–171 | Require the current start to equal the expected next date. Advance that expectation to one calendar day after this window's end. |
| 173–181 | Validate window saved/total counts, require a files list, reconcile its length with `pageCount`, and require saved reports to equal the API-observed total. |
| 183–187 | Resolve each path safely and reject any path listed more than once, including across windows. |
| 189–190 | Add window saved reports and listed pages to the run totals. |
| 192–193 | Require the final window to end on January 1, 2026. |
| 195–202 | Validate run-level saved/total/unique/page counts and reconcile them against the summed windows. |
| 203 | Return the manifest only after all checks pass. |

The central equalities are:

```text
For every window:
    window.savedCount = window.total
    window.pageCount = len(window.files)

For the run:
    sum(window.savedCount) = manifest.savedCount = manifest.total = manifest.uniqueCount
    sum(len(window.files)) = manifest.pageCount
    len(windows) = manifest.windowCount
```

**How date coverage is proved:** the first start must be January 1, 2002; each subsequent start must be exactly the day after the preceding end; every window is internally valid and inside bounds; the last end must be January 1, 2026. That rules out gaps, overlaps, reordering, and truncated coverage. It does **not** require yearly windows or exactly 24 windows. Part 1 currently produces 24, but Part 2 accepts any valid contiguous partition of the fixed range.

**What this does not prove:** that the API provided an immutable point-in-time snapshot, that counts alone detect every later edit, or that the manifest is cryptographically authenticated. The manifest carries filenames and counts, not content hashes. Later record loading supplies additional checks.

The program ignores files absent from the manifest. This is deliberate: the completion inventory decides what belongs to this snapshot, so an unrelated temporary JSON file does not become input just because a directory glob finds it.

## Report and page loading: lines 206–264

### `checkReport`, lines 206–232

1. **207–212:** Require a report object and a nonblank string `report_number`.
2. **214–216:** Validate `date_started` as a calendar date and require it to lie inside the manifest window whose file contains it.
3. **218–227:** Require a products list. Every product must be an object with nonblank string `role` and `name_brand` fields.
4. **228–229:** Require outcomes and reactions to be valid lists of strings via `checkTerms`.
5. **230–232:** Require `consumer` to be an object, then return the report ID.

This is structural validation for the analysis fields. It does not validate every FDA field or reject unknown extra fields. Empty product, outcome, and reaction lists are allowed. A product role must be nonblank, but this function does not enforce an enum; the later filter selects only exact `SUSPECT` roles.

A missing `consumer` object is fatal. An existing consumer object with no age or gender is valid. That distinction separates a broken expected structure from missing optional data.

The ID's whitespace is checked for nonblankness but is not removed from the stored or returned ID. Uniqueness therefore concerns exact source identifier strings, not a newly normalized identifier scheme.

### `loadReports`, lines 235–264

- **236–239:** Validate the manifest, allocate a report list, and allocate a run-wide set of IDs.
- **242–248:** Visit each manifest window and each listed page; resolve/read it; require an object containing a `results` list.
- **250–256:** Validate each report, reject a duplicate ID, then add the ID and append the original report dictionary.
- **257–260:** Sum loaded records in each window and compare that count with the window's saved count.
- **262–264:** Reconcile all loaded reports and unique IDs with the manifest, then return the list.

**Execution order matters:** all listed records are validated before any year or product filter is applied. A malformed report in 2005 fails a 2024-only analysis as well. The output is defined as a query over a valid complete snapshot, rather than a query that can conceal corruption outside its filter.

This loader intentionally does not replay ingestion. It does not follow cursors, validate HTTP responses, demand a maximum of 100 entries per page, or compare each page's metadata to its window. Part 1 and the independent download validator covered those ingestion properties; Part 2 checks the boundary it needs: expected structures, report identity/date membership, inventory, and reconciliation.

It loads all report dictionaries into memory. That is straightforward for the committed snapshot; it is not a streaming implementation for arbitrarily large datasets.

## Report selection: lines 267–287

### `getSuspectProducts`, lines 267–273

- **268–269:** Collect `name_brand` only where `role == "SUSPECT"`. This role comparison is exact and case-sensitive because it uses the FDA's supplied role value.
- **270–271:** Without a product filter, return all such names.
- **272–273:** Casefold the search phrase and each candidate name, then use Python's literal substring operator `in`.

`casefold` is a Unicode-aware form of case-insensitive text comparison. This is **not** a regex, so a search such as `A+B` means the literal three-character phrase. The function does not strip internal spaces, normalize punctuation, apply aliases, or fuzzy-match names during selection.

### `selectReports`, lines 276–287

1. **277–281:** Allocate the result list, derive the year from each validated source date, and skip reports outside the inclusive selected interval.
2. **284:** Get eligible suspect names for that report and optional filter.
3. **285–286:** Without a product filter, keep every report in the selected year range, including a report with no suspect names. With a product filter, keep it only when at least one matching suspect name exists.
4. **286–287:** Append one wrapper containing the unchanged report and eligible names; return the selected list.

The `or` condition short-circuits, but `getSuspectProducts` has already run on the preceding line. Multiple matching products do not create multiple selected rows. Outcomes, reactions, and age remain report-level information from the entire selected report; the code does not attribute an individual reaction causally to the matching product.

**Documented rationale:** Alex explicitly preferred ranking only matching suspect products once a product filter is active (`REVIEW_NOTES.md:285–308`). That superseded an earlier plan to rank all suspect products from selected reports.

## Age and gender hygiene: lines 290–317

### `ageInYears`, lines 290–309

1. **291–297:** Return `None` if the consumer is not an object, age is absent/null, age is a boolean, or unit is not a string. The caller normally already validated the object, but the helper is independently defensive.
2. **299–302:** Convert the age to `float`; malformed strings/types become `None` for the exceptions caught here.
3. **304–306:** Normalize unit text with `strip().casefold()`, look up the factor, and reject unsupported units or non-finite numeric values.
4. **308–309:** Convert to years and return the result only if it falls inside the inclusive interval 0–125; otherwise return `None`.

| Source unit | Factor | Example |
|---|---:|---|
| `year(s)` | 1 | 40 years → 40.0 |
| `month(s)` | 1/12 | 6 months → 0.5 |
| `week(s)` | 7/365.25 | 52 weeks → approximately 0.9966 |
| `day(s)` | 1/365.25 | 365 days → approximately 0.9993 |
| `decade(s)` | 10 | 3 decades → 30.0 |

The bound is applied **after** conversion. A raw age of 365 days is plausible, while 68 decades means 680 years and is rejected. Do not silently “correct” 68 decades to 68 years: that would invent a replacement value unsupported by the source.

Zero is valid, including newborn reports. Fractional values remain fractional for averages and the histogram. Months and years vary in length, so the sub-year conversions are approximate conventions, not exact birth-date calculations.

Returning `None` excludes the age from age calculations, **not the report from other statistics**. The notes document that 125 was chosen to retain an observed 122.75-year value and exclude the observed 680-year error. It is a transparent project rule that would deserve a reviewed data-quality policy in a larger system.

**Review-discovered edge case:** `float(10**400)` raises `OverflowError`, which the `except (TypeError, ValueError)` block does not catch. A focused execution check of this exact function, extracted unchanged from the source's syntax tree, confirmed that failure before the finite-value check. A sufficiently huge integer in an age field can therefore escape the graceful invalid-age path and reach an unhandled CLI exception. No such age occurs in the committed snapshot. This is a candidate small hardening fix; reproducing it independently does not constitute a fresh run of the full Python test suite.

### `getGender`, lines 312–317

Read the optional gender field. Nonstring values return `None`; strings are trimmed and casefolded. Only `female` and `male` map to the output labels `Female` and `Male`. Everything else maps to `None`.

The nested conditional expression returns one value; it does not run two separate calculations. Unknown gender can still have a valid age, which later contributes to the overall mean but neither named group. This is normalization of the source field for the requested grouped calculation, not an inference about the consumer's identity.

## Normalization and aliases: lines 320–340

### `normalizeTerm`, lines 320–334

Order is essential:

1. **321:** Apply Unicode NFKC normalization, then uppercase. NFKC converts compatible presentation forms, such as full-width Latin characters, to a common representation; uppercase handles case differences. It does not perform semantic translation or necessarily remove accents.
2. **322–323:** For products only, replace raw hyphenated Vitamin D2/D3 spellings before punctuation removal destroys the evidence of the hyphen.
3. **324:** Turn ampersands into `AND` and plus signs into `PLUS`, with spaces.
4. **325–326:** Remove several straight/curly apostrophes, a backtick, and the observed `U+0092` apostrophe character. `WOMEN’S` becomes `WOMENS`, rather than `WOMEN S`.
5. **327:** Replace underscores with spaces, then replace sequences outside Unicode word characters and `%` with a space. Percent signs survive to distinguish concentrations.
6. **328:** Collapse repeated whitespace and trim.
7. **330–333:** For products only, apply the ordered alias table, then collapse whitespace again.
8. **334:** Return the normalized string.

The aliases are whole-word-bounded patterns:

| Pattern family | Output / limitation |
|---|---|
| `Vitamin D2`, `Vitamin D3`, `Vit D2`, `Vit D3`, plus recognized source-hyphen forms | `VITAMIN D`; surrounding brand/dosage words remain |
| `Vit D` | `VITAMIN D` |
| `NatureMade` | `NATURE MADE` |
| `Softgel`, `Softgels`, `Soft Gel`, `Soft Gels` | `SOFT GEL` |

Examples:

```text
"  Café_Women’s 50+ & A/B  " → "CAFÉ WOMENS 50 PLUS AND A B"
"2% milk"                  → "2% MILK"
"Vitamin-D-3"              → "VITAMIN D"
"Vitamin D 3 MCG"          → "VITAMIN D 3 MCG"
"Vitamin D 3000 IU"        → "VITAMIN D 3000 IU"
"D3 SPORTS"                → "D3 SPORTS"
"NatureMade D3 Softgels"    → "NATURE MADE D3 SOFT GEL"
```

`D3` alone is not treated as a vitamin. A separate number after D is not automatically consumed as a vitamin version, which protects `Vitamin D 3 MCG`. Product aliases do not apply to reaction or outcome fields. `ABDOMINAL PAIN` and `ABDOMINAL PAIN UPPER` remain different, as do different cancer stages and different product formulations.

**Rationale:** the notes document Alex's acceptance of consistent cleanup plus a small inspected mapping. Explainable mappings avoid the unsupported merges that edit-distance or a language model might introduce. Vitamin D2 and D3 are grouped as an **assignment reporting family**, not declared chemically identical.

**Limitations to acknowledge:** deterministic does not mean semantically perfect. Generic punctuation cleanup can merge distinct strings: for example `2.5` and `2-5` both become `2 5`. The code does not remove all numeric content, but it also does not promise to preserve every dosage distinction. Broader use should audit collisions and introduce field-specific numeric-token preservation or a versioned mapping review process. Do not defend the current heuristic as universal clinical entity resolution.

### `normalizeTerms`, lines 337–340

- Normalize all values into a set.
- Because deduplication occurs **after** normalization, `Rash`, `RASH`, and `rash!` become one `RASH` in that report.
- Remove empty normalized strings; a raw nonempty string of punctuation can normalize to nothing.
- Sort remaining terms for deterministic lists.

Deduplication before normalization alone would leave different source spellings that later collapse to the same term, producing duplicate report contributions when flattened.

`EXEMPTION 4` is retained. The notes explicitly chose to keep this supplied placeholder because removing the most frequent suspect name without an exclusion rule would change the assignment's counts. Its presence does not make it an identifiable product.

## The report table and age calculations: lines 343–381

### `makeDataFrame`, lines 343–357

- **344–345:** Define the seven columns explicitly and create a rows list.
- **346–349:** Iterate over selected report wrappers, retaining the raw report reference.
- **350–352:** Normalize/deduplicate eligible suspect names, outcomes, and reactions into three separate list-valued cells.
- **353–355:** Derive year, converted age, and normalized gender once per report.
- **357:** Build the pandas DataFrame with the specified columns.

Supplying columns explicitly is important for an empty selection: later operations can still access `ageYears`, `year`, and term columns instead of raising missing-column errors. Missing ages generally appear as pandas missing values, and the later helper excludes them.

The lists inside DataFrame cells are intentional. Exploding the whole table early would multiply ages; exploding multiple columns together may also demand matching list lengths, while sequential explosions can create a Cartesian product. This code avoids both by keeping the row grain at report level and exploding one term series on demand.

### `getValidAges`, lines 360–364

Select all `ageYears`, or rows whose normalized gender matches the requested label. Drop pandas missing values, convert to a float NumPy array, then retain only finite numbers. Both averages and the histogram use this exact helper, so they share the same population.

The finite check here is defensive duplication of the earlier age conversion check. It protects the aggregation helper if it receives a separately built DataFrame containing `NaN` or infinity.

### `getAgeAverage`, lines 367–369

Get the valid-age array. If it is nonempty, return `float(np.mean(ages))`; otherwise return `None`. The condition checks array size before calling the mean, avoiding empty-array warnings and a misleading numeric result.

### `getAgeAverages`, lines 372–377

Return a dictionary of overall, Female, and Male means. The overall mean is calculated independently from **all** valid ages, including unknown-gender reports. It is not the unweighted average of Female and Male means.

For example, ages 20/Female, 40/Male, and 90/unknown produce an overall mean of 50; Female = 20 and Male = 40. Averaging the two named subgroup means would incorrectly give 30 and exclude a valid report.

### `formatAge`, lines 380–381

Display `N/A` for no valid values, otherwise format the mean to two decimals followed by `years`. Rounding affects display only; values remain unrounded during calculations. Zero age is displayed as `0.00 years`, not `N/A`.

## Ranking and stdout: lines 384–414

### `getTopTerms`, lines 384–389

1. **385:** Take one list-valued Series, `explode` its lists into individual entries, and remove missing values introduced by empty lists.
2. **386–387:** Return an empty list if there are no terms.
3. **388:** Use `value_counts` and build `(term, int(count))` pairs.
4. **389:** Sort by `(-count, term)`, then take up to the requested limit, default 25.

Negative count means descending frequency; the second tuple element breaks ties alphabetically by normalized string. All distinct terms are ordered before slicing, so ties at position 25 resolve consistently instead of depending on file or input order. The actual ordering is Unicode string order, not locale-specific dictionary collation.

Because each report's list was deduplicated, each term's count equals the number of selected reports mentioning that normalized term. A report can mention multiple different terms, so totals across the ranking can exceed total reports. The output is not a probability distribution.

### `printTopTerms`, lines 392–398

Print the heading, a no-values message if empty, or one-based numbered entries with comma-formatted counts. The heading is fixed as `Top 25` because the main program uses the default limit. Fewer than 25 distinct terms correctly yields fewer than 25 lines.

### `printSummary`, lines 401–414

Compute the age means; print total DataFrame rows; then outcomes, reactions, suspect products, and age means, with blank lines between groups. Counts use thousands separators. This is the assignment's required output order.

Age averages are computed before the first printed line, but rankings are computed as their print calls occur. There is no cached summary object: the summary helpers derive results from the same already-built table.

## Annual counts and charts: lines 417–482

### `getYearCounts`, lines 417–419

Build `range(startYear, endYear + 1)`. The `+1` makes Python's exclusive range endpoint include the selected final year. Count table rows by year, reindex across the full requested range with zeros, and sort ascending by year.

An empty 2024–2026 selection produces `{2024: 0, 2025: 0, 2026: 0}`. Omitting absent years would make the x-axis conceal gaps. These are raw counts by the source `date_started` year, not rates adjusted for population, reporting propensity, or number of products used.

### `buildChart`, lines 422–463

| Lines | Behavior and purpose |
|---|---|
| 423–425 | Get annual counts and valid ages; create one 12×10-inch figure containing two vertically stacked axes. |
| 427–435 | Plot blue annual bars; label title and axes; display all years with rotated labels; use integer y-axis ticks; place horizontal grid lines behind bars. |
| 436–437 | For all-zero counts, force a usable y-axis of 0–1. |
| 439–441 | Draw a histogram with integer edges from 0 through 126 and narrow white separators. |
| 442–449 | Label the age histogram and axes; set the visible range; use selected age ticks and integer count ticks; add restrained grid lines. |
| 450–453 | If no valid ages exist, use a visible empty scale and show `No valid ages` in axes-relative coordinates. |
| 455–457 | Build the selected-year scope and append the January 1, 2026 coverage note whenever the range reaches 2026. |
| 458–459 | Add the user product filter to the title when present, collapsing whitespace for display only. |
| 460–462 | Add a figure-level title, disable math interpretation of filter text, and lay out axes leaving room for the title. |
| 463 | Return the figure for saving and structural testing. |

Histogram edge arithmetic is a useful interview detail:

```text
np.arange(0, maxAge + 2)
= np.arange(0, 127)
= edges 0, 1, 2, ..., 125, 126
= 127 edges defining 126 bins
```

Most bins have the usual left-inclusive/right-exclusive form `[k, k+1)`; NumPy's final bin includes its right edge. The earlier validator has already excluded ages above 125, so the accepted boundary age 125 lies in the last 125–126 bin. A six-month-old report is age 0.5 and belongs to the first 0–1 bin. No rounding to the nearest birthday occurs.

The histogram's y-axis explicitly says `Reports with Valid Age`. The annual plot retains the assignment's `Total Cases by Year` / `Cases` labels, but the underlying calculation still counts reports, not independently verified unique cases. If asked, use “report counts” when describing the statistical meaning.

### `saveChart`, lines 466–482

1. **467–469:** Choose a supplied execution timestamp or the current local time; create a filename `YYYYMMDD-HHMMSS-microseconds.png` under the output root. The name is Windows-safe.
2. **470–473:** Create parent directories as necessary; convert filesystem failure into `DataError`.
3. **475:** Build the figure.
4. **476–479:** Save a PNG at 150 DPI with a tight bounding box and white background; turn write `OSError` into `DataError`.
5. **480–482:** Always close the successfully built figure after the save attempt, then return the path on success.

The `finally` block prevents saved or failed-save figures from accumulating in Matplotlib's global state. The function's injectable path and timestamp allow deterministic tests in a temporary directory. It does not use exclusive output creation or a content-addressed filename: reusing an identical timestamp/path can overwrite an existing image. Microseconds make ordinary accidental collisions unlikely, not mathematically impossible.

The `try/finally` covers saving after `buildChart` returns. It is not a universal guarantee that a figure created inside a failing `buildChart` is closed, or that arbitrary plotting/dependency exceptions become friendly data errors.

## Entrypoint and exit codes: lines 485–512

### `main`, lines 485–495

- **486:** Capture the execution timestamp at the start, unless one was supplied by a test.
- **487:** Parse supplied argument values, or real process arguments excluding the script name.
- **488:** Load and validate all listed reports.
- **489:** Select the report population.
- **490:** Build the normalized report-level table.
- **491:** Save the required chart.
- **492–494:** Print summary and chart location.
- **495:** Return the DataFrame for programmatic use and testing.

Defaults such as `root=dataDir` are bound when the function is defined; changing the global later does not retroactively change that default. Tests correctly inject a root instead. The pipeline stages are separated enough that each can be examined with a small fixture without running the entire CLI.

### `runCli`, lines 498–508, and main guard, lines 511–512

| Path | Output | Exit code |
|---|---|---:|
| `main` succeeds, including zero matches | Required summary and chart path on stdout | 0 |
| `UsageError` | Error plus usage on stderr | 2 |
| `DataError` | Error on stderr | 1 |
| Unexpected exception | Normal Python traceback; not transformed by these handlers | Nonzero |

When the file is run directly, `__name__ == "__main__"`; Python calls `runCli` and passes its return value to `sys.exit`. When imported by tests, functions/constants are defined and imports execute, including backend configuration, but the command is not automatically run. Missing Python dependencies fail during import before `runCli` is reached.

## Worked example: filtering, deduplication, flattening, and age denominators

This is a **hypothetical fixture**, not a claim about an individual FDA report. Assume four structurally valid reports within a valid test dataset:

| Report | Date | Products and roles | Reactions | Age / gender |
|---|---|---|---|---|
| A | 2024-06-01 | `SUSPECT Organic Baby Carrots`; `SUSPECT ORGANIC BABY CARROTS!`; `SUSPECT Vitamin D3`; `CONCOMITANT Carrots Snack` | `Nausea`, `NAUSEA!`, `Rash` | 40 years / Female |
| B | 2025-02-01 | `SUSPECT Frozen Peas & Carrots` | `nausea` | 24 months / unknown |
| C | 2025-04-01 | `SUSPECT Vitamin D`; `CONCOMITANT Carrots` | `Rash` | 60 years / Male |
| D | 2023-08-01 | `SUSPECT Organic Baby Carrots` | `Rash` | 30 years / Female |

Run `python part2.py 2024 2026 CARROTS`.

1. **Parse:** years 2024–2026, raw product filter `CARROTS`.
2. **Validate:** all four reports are checked before selection, including D outside the requested year interval.
3. **Year filter:** exclude D because 2023 is outside 2024–2026.
4. **Role and name filter:** A and B match. C does not: its carrot name is `CONCOMITANT`, not `SUSPECT`.
5. **Keep one row each:** total selected reports = 2. A has two matching raw products but still creates one selected row.
6. **Restrict eligible product names:** A's `Vitamin D3` and concomitant product do not enter the filtered ranking. A's two carrot spellings do.
7. **Normalize then deduplicate:** A's eligible names become `["ORGANIC BABY CARROTS"]`; B's becomes `["FROZEN PEAS AND CARROTS"]`. A's reactions become `["NAUSEA", "RASH"]`; B's `["NAUSEA"]`.
8. **Explode reactions alone:** the temporary Series contains `NAUSEA`, `RASH`, `NAUSEA`. Counts are NAUSEA = 2 reports; RASH = 1 report. Sum = 3, which can exceed the 2 selected reports because terms are not mutually exclusive.
9. **Explode products alone:** both product labels have count 1. Alphabetical tie-breaking puts `FROZEN PEAS AND CARROTS` before `ORGANIC BABY CARROTS`.
10. **Ages:** A → 40; B → 2 years. Overall mean = `(40 + 2) / 2 = 21.00`. Female mean = 40.00; Male = `N/A`. B's unknown gender does not erase its valid age from the overall calculation.
11. **Annual bars:** 2024 = 1, 2025 = 1, 2026 = 0, with the snapshot-end note visible.
12. **Histogram:** one age in the 2–3 bin, one in the 40–41 bin. There are two age observations, not three product-derived observations.

Now change A's age to 68 decades. A remains selected, NAUSEA remains count 2, both product counts remain 1, and the report total remains 2. A's converted age of 680 is invalid, so the overall mean becomes 2.00; Female and Male means are both `N/A`; the histogram contains only B's age.

One more trap: `VIT D3` and `Vitamin D3` normalize to the same reporting family, but a raw filter `Vitamin D` will match only the latter spelling. Search and grouping deliberately have different jobs. If asked for alias-aware searching later, it should be a documented interface change with tests, not an accidental side effect of moving normalization earlier.

## Complexity: explain the work, not just a label

Let **B** be total input bytes; **R** be report count; **T** be the number of term entries processed across nested lists; **C** be their total text length; **U** be distinct normalized terms in a ranking; **Y** be selected years, at most 25 here.

| Stage | Practical work |
|---|---|
| Load and structural validation | Approximately O(B + R + T), plus date parsing and path operations. ID and path sets have expected constant-time membership checks. Every listed page is read even for a narrow filter. |
| Selection | One pass over reports and eligible product names; substring searching additionally depends on source-name and filter lengths. Avoid promising literal O(R) independent of string length. |
| Normalization | Work broadly proportional to input text length for this fixed set of expressions; per-report set construction plus sorting each report's unique terms. |
| Ranking | Flatten/count terms, then sort all U distinct terms: approximately O(T + U log U), with string comparisons adding their own costs. It is **not** O(25) simply because 25 results are returned. |
| Age means | Several linear scans of the selected report rows; bounded age values and no sorting. |
| Annual counts / histogram | One pass over selected rows/valid ages plus the fixed small year/bin ranges; image rendering has additional fixed and plotting overhead. |

The program retains the full raw report list, ID set during loading, selected wrappers, DataFrame rows, and derived term lists. Some structures hold references to existing dictionaries rather than copies, but strings/lists and pandas object storage still add memory overhead. Peak memory is O(input + derived terms), with an extra temporary flattened Series per ranking.

For much larger data, reasonable next steps are page-wise validation plus streaming counters and age sums/counts, or an explicitly modeled columnar/relational store. A bounded heap can reduce top-k sorting from O(U log U) toward O(U log 25), but preserving deterministic ties and measuring the actual bottleneck matter. For this fixed snapshot, readability and observed runtime supported the simpler full sort. Treat historical timing as historical until the current review remeasures it.

## Decision history: what can be said with evidence

| Decision | Documented source | Grounded explanation |
|---|---|---|
| Fixed January 1, 2026 endpoint | `REVIEW_NOTES.md:275–278`, `642–643` | The task's “present” was clarified to mean the completed snapshot. |
| Matching-only suspect ranking | `REVIEW_NOTES.md:285–308` | Alex expressed this preference; it replaced an earlier all-suspects interpretation. |
| Small deterministic alias mapping | `REVIEW_NOTES.md:279–282`, `300–305`, `772–788` | Required consolidation was met with inspected transformations while protecting meaningful distinctions. |
| One row per report | `REVIEW_NOTES.md:649–651`, `714–717`, `729–733` | Keep totals/ages at report grain and prevent nested lists from multiplying observations. |
| Manifest inventory and full validation | `REVIEW_NOTES.md:652–667` | Refuse incomplete/corrupt inputs before presenting an analysis. |
| Age conversion and ceiling | `REVIEW_NOTES.md:706–717`, `739–743` | All observed units were supported; transparent plausibility rule handles the observed extreme age. |
| Stable top-25 ties | `REVIEW_NOTES.md:789–802` | Produce repeatable ranking output independent of input ordering. |
| One-year histogram and partial-year note | `REVIEW_NOTES.md:853–871` | Represent fractional ages accurately and avoid implying 2026 is a full year. |
| Save before printing success | `REVIEW_NOTES.md:882–889` | Required chart failure makes the command fail coherently. |
| Exact contiguous coverage checks | `REVIEW_NOTES.md:923–929` | Final audit closed a path where a superficially valid partial manifest could pass. |

The beginning of `REVIEW_NOTES.md` still calls the first-page slice “current.” It is an accumulated history, and that opening paragraph is obsolete. The later completed slices and final audit describe the finished code. Historical “14/20/27/30 tests pass” and runtime figures are checkpoints, not contradictory final results. The final notes record 31 Part 2 tests; the present review should report its own actual verification separately.

Do not claim an undocumented thought process as memory. A safe phrasing is: “The review notes record this decision as … The technical reason it makes sense is …” Once comfortable with the rationale, use direct first-person explanations for the design without pretending to remember a conversation you do not actually recall.

## Honest limitations to volunteer when relevant

- This measures reports and associations. It does not establish product causality, incidence rates, or unique people.
- A completion manifest and duplicate-ID checks protect structural completeness; they do not create an immutable API snapshot or authenticate later content edits.
- Literal product selection differs from normalized grouping; punctuation, internal whitespace, and aliases can produce surprising search misses.
- The age average is an available-age mean. Missing-age reports do not enter its denominator, so it is not automatically representative of all consumers.
- The 125-year bound and Vitamin D reporting family are explicit analytic choices, not universal domain truths.
- The normalization policy is narrow and can still collide on punctuation-sensitive names; it is not complete entity resolution.
- The positional CLI cannot unambiguously represent a standalone four-digit product name; it has no dedicated help option.
- The implementation reads the full dataset into memory and validates all data for each analysis. It is appropriate for this snapshot, not an unlimited streaming service.
- Dependencies are ranged, chart names are timestamped, and images are not published atomically. Stronger environment locking and artifact provenance would be reasonable for repeated production use.
- A huge integer age has a freshly reproduced uncaught `OverflowError` path. The narrow fix is to include that conversion failure in the existing guard; no application code was changed during this review.

## Fast Part 2 recall prompts

1. **What is one row?** One selected report.
2. **What is being counted in a ranking?** Reports mentioning a normalized term, at most once per report per term.
3. **Why can counts sum beyond total records?** A report can mention multiple distinct terms.
4. **When does normalization happen?** After raw suspect-product filtering, before within-report term deduplication.
5. **What does `explode` do?** Turn each list element in one Series into a separate temporary row for counting.
6. **Why not explode everything first?** It can duplicate report-level ages and create unwanted cross-products of nested fields.
7. **What is the age denominator?** Selected reports with a finite converted age between 0 and 125, further restricted by gender for group means.
8. **Why `N/A`?** No valid observations, not an average of zero.
9. **Why 2026 looks small?** The fixed snapshot includes only January 1, 2026.
10. **Why all pages even for one year?** Validate the complete snapshot before answering a filtered query.
11. **How are ties resolved?** Count descending, normalized term ascending, then take up to 25.
12. **What does success require?** Valid snapshot, completed analysis, and successfully saved chart; an empty selection is still valid success.
