# Section 2: Questions Alex could ask, follow-ups, and answers

These are likely review directions based on the assignment and the actual implementation, not predictions about Alex's private preferences. Start with the short answer. Use the follow-up material when asked. The goal is to understand the answer well enough to rephrase it naturally.

For a decision: **requirement → chosen approach → tradeoff → evidence**. For a limitation: **current behavior → consequence → concrete improvement**. Do not turn every answer into a list of everything wrong with software since 1968.

## A. Scope, architecture, and your decisions

### Q01. Walk me through the project.

**What this probes:** whether you can explain the system before explaining syntax.

**Say:** “There are two stages connected by saved JSON and a completion manifest. Node retrieves the fixed date range with concurrent date windows and sequential cursor paging inside each window. Python validates that saved snapshot, applies the user's filters, and computes report-level summaries and charts. Keeping the stages separate means I can rerun analysis without spending more API requests.”

**Follow-up: Why two languages?** “The assignment required Node for ingestion and Python with pandas, NumPy, and Matplotlib for analysis. Within that constraint, the file boundary keeps the programs independently testable.”

**Follow-up: Why no database or framework?** “For a fixed roughly 98,000-report dataset and two command-line programs, JSON plus a manifest was sufficient. A recurring, query-heavy service would make a database or columnar storage more useful.”

**Remember:** two stages; saved snapshot; clear handoff.

### Q02. Which choices were yours, and which were requirements?

**Say:** “Node, Python, the three Python libraries, the exact date bounds, limit 100, configurable concurrency defaulting to three, the statistics, and the chart were specified. Yearly windows, the shared pacing policy, bounded retries, the manifest, and the no-resume behavior were implementation choices. I also clarified term counting and filtered product rankings with you before finalizing those semantics.”

**Follow-up: What changed after clarification?** “An early assumption would have ranked all suspects from a matching report. Your preference was to rank only matching suspects, so I retained only those names for the filtered product ranking.”

**Follow-up: What did you question yourself?** Explain the one-day final window, uneven workloads, and the investigation into only 13 outcome categories. These are documented conversations, not invented anecdotes.

### Q03. Why build this in slices?

**Say:** “I wanted each new layer to depend on a behavior I could already inspect and test. I started with one valid saved page, then a complete window, then concurrent windows, then shared failure handling and completion publication. Analysis followed the same pattern: selection, ages, rankings, and plotting.”

**Follow-up: Did that slow you down?** “It added checkpoints, but reduced the number of moving parts when something failed. The flaky concurrency test is an example: I could isolate its synchronization assumption without rewriting the downloader.”

**Follow-up: What would you simplify?** “I would keep the correctness boundaries, but could consolidate repeated validation helpers or split requester logic into a module if the two-script deliverable constraint changed. I would avoid refactoring merely to add abstraction.”

### Q04. Why preserve the raw responses?

**Say:** “They retain the original report fields and response metadata so I can inspect what the source provided and rerun different analysis rules. Ingestion validates retrieval correctness but does not discard records just because an analysis field such as age is missing.”

**Follow-up: Are they byte-for-byte originals?** “No. I parse JSON and serialize it with indentation, so the values and envelope are preserved, but whitespace and original wire bytes are not.”

**Follow-up: Why commit data to Git?** “The downloaded JSON was a deliverable for this assessment. For frequent snapshots or larger datasets, I would use versioned object storage and commit the manifest or retrieval reference.”

## B. Pagination, date coverage, and completeness

### Q05. How does pagination work, and why not increment skip?

**Say:** “I build the first request for one date window, then follow the API's next Link URL. That URL carries an opaque search_after cursor. I validate the destination and required query parameters, but I do not try to calculate the cursor myself. That avoids ordinary offset-pagination depth limits.”

**Follow-up: Why not increment the last event date?** “Several reports can share a date. Advancing to the next day could skip reports; requesting the same last date could repeat them. The server's cursor handles traversal position beyond the visible date.”

**Follow-up: What does opaque mean?** “The API owns the cursor's representation and semantics. My client follows it and checks for repeats instead of depending on its internal encoding.”

FDA documents ordinary skip/limit traversal up to 26,000 hits and its search-after Link workflow. The initial query omits skip; FDA's own cursor example includes `skip=0`, which this implementation permits. [Official paging documentation](https://open.fda.gov/apis/paging/).

### Q06. Why do you have 24 windows rather than 25?

**Say:** “I wanted independent pagination chains without a separate one-day window at the end. The windows cover full years 2002 through 2024, then one final window from January 1, 2025 through January 1, 2026 inclusive. Every requested day belongs to exactly one window.”

**Follow-up: Why not January 1 to next January 1 for every year?** “Because inclusive endpoints would put each shared January 1 in two windows. Only the final window extends into the next year.”

**Follow-up: Is getWindows reusable for any dates?** “No. It's intentionally tied to this fixed assignment range. Generalizing the constants alone would be unsafe; a reusable date partitioner would need explicit clipping and boundary tests.”

**Remember:** independent chains, exact coverage, final boundary included once.

### Q07. How do you know the dataset is complete?

**Say:** “I use several checks together: exact disjoint date coverage, exhausted cursor chains, a stable total inside each window, dates inside each window, and unique report IDs. Saved counts and unique counts must equal the observed totals. Only then do I publish a complete manifest. Python independently checks its inventory, coverage, counts, and report IDs again.”

**Follow-up: Is matching the count alone enough?** “No. A duplicate could replace a missing record and leave the count unchanged. That's why IDs and traversal completion matter too.”

**Follow-up: Can you prove the upstream database stayed unchanged?** “No. A changing source could replace a record while preserving totals. These checks reconcile what the traversal returned; they do not provide snapshot isolation. Source version information, if available, would strengthen that guarantee.”

**Remember:** coverage + cursor + totals + IDs. Neither total count nor a green flag is magic.

### Q08. Why continue after a short page or the final date?

**Say:** “Neither proves the server has finished. A short page can still carry a next cursor, and many reports can occur on the final date. I follow the pagination chain to its terminal state and reconcile the counts afterward.”

**Follow-up: What if savedCount already equals total but there is another link?** “I still follow it. If it returns extra reports or a changed total, I fail. If it returns the recognized terminal no-match response and the counts agree, the window succeeds.”

**Follow-up: What test covers this?** “A synthetic short page at the upper date boundary with another cursor must lead to another request. There's also a 26,001-report fixture to exercise long traversal.”

### Q09. When is an HTTP 404 successful?

**Say:** “Only for the FDA's specific no-match error shape: code `NOT_FOUND` and exact message `No matches found!`, with no next link. An arbitrary 404 is still an error. On the first request, that response can represent an empty window. After pages have been saved, it is terminal only if the final counts reconcile.”

**Follow-up: Give an example.** “If the expected total is 200 and I save two full 100-report pages, an extra cursor can return the recognized no-match response. That is complete. If I had saved only 100 of the expected 200, the same terminal response still leads to an incomplete-window error.”

**Follow-up: Can an empty success page have a next link?** “The code rejects that combination, and also rejects a no-match response carrying a next link.”

**Code:** `fetchPage`, `downloadWindow`.

### Q10. Why validate next-page URLs?

**Say:** “Following a server-provided URL is still a trust boundary. I require the same FDA origin and food-event path, unchanged search, page limit, and sort, and one nonempty cursor. I reject URL username/password fields, fragments, nonzero skip, count queries, multiple next links, and repeated cursors. Fetch also rejects redirects.”

**Follow-up: Does the key propagate?** “After validating the URL, I set the configured key on it. I don't log request URLs or put the key in the manifest.”

**Follow-up: Is this a complete generic Link parser or query allowlist?** “No. It handles the API's expected format and protects specific invariants. It does not reject every unknown extra query parameter, so I wouldn't describe it as a universal URL sanitizer.”

### Q11. Why use sets for report IDs? Why throw instead of silently deduplicating?

**Say:** “A set gives expected constant-time membership checks. Here, duplicate IDs are evidence that retrieval or the snapshot may be inconsistent. Silently removing them could conceal a missing record or broken cursor chain. I fail the run so the inconsistency is visible.”

**Follow-up: Why both per-window and global sets?** “The local set reconciles that window, while the shared set prevents the same report ID from being accepted in different windows. A page-level set catches duplicates inside a single response first.”

**Follow-up: Are duplicate dates invalid?** “No. Many reports can have the same date. Identity is report_number, not date_started.”

**Follow-up: Does this deduplicate people?** “No. It deduplicates report identifiers only.”

## C. JavaScript execution, concurrency, and failure handling

### Q12. How can three workers run if JavaScript executes on one thread?

**Say:** “The JavaScript callbacks execute one at a time, but network and filesystem operations can be pending together. When one worker awaits a request, its continuation pauses and other workers can progress. That gives overlapping I/O without worker threads.”

**Follow-up: Does await block the entire program?** “It suspends that async function until its promise settles. It doesn't block all workers. Synchronous parsing and validation still occupy the JavaScript thread while they execute.”

**Follow-up: What is actually concurrent?** “Separate windows' requests and some I/O. The dependent pages within one cursor chain remain sequential.”

**Follow-up: Does Promise.all create concurrency?** “No. Calling worker() starts each async function. Promise.all observes the resulting promises and waits for them together.”

### Q13. Why must nextIndex change before await?

**Say:** “Claiming the index and incrementing it happen synchronously before that worker yields. No other worker continuation runs between those statements, so each gets a different window. If I read the index, awaited, and only then incremented it, another worker could read the same old value.”

**Follow-up: Why reserve report IDs before writing?** “For the same reason. I check and reserve the IDs in shared state before yielding to the asynchronous write, so another window cannot accept them while the write is pending.”

**Follow-up: What if that write fails?** “Reserved IDs remain, but the whole run fails and never publishes completeness. There's no resume contract requiring rollback of in-memory reservations.”

**Remember:** synchronous claim/check/reserve, then await. That reasoning depends on this single JavaScript execution context.

### Q14. What's the difference between concurrency and rate limiting?

**Say:** “Concurrency limits how much work is in flight at once. Pacing limits how frequently new requests start. Three very fast requests could generate a high request rate, so every attempt passes through one shared gate with 300 milliseconds between admissions.”

**Follow-up: How fast is that?** “Approximately 200 request starts per minute at most in this process under the gate. Network latency, validation, writes, backoff, and the remaining work can make it slower.”

**Follow-up: What does the API key change?** “The published standard limits list 240 requests per minute with or without a key, but daily allowances of 1,000 without and 120,000 with one. A roughly 987-page run leaves little anonymous daily margin for retries or other requests.” [FDA authentication and limits](https://open.fda.gov/apis/authentication/).

**Follow-up: Is this a global quota guarantee?** “No. Other processes or users can share the same key or IP. My in-memory gate only coordinates this run.”

### Q15. Doesn't a promise queue serialize all the downloads?

**Say:** “It serializes permission to start a request, not the request itself. The queued callback waits for nextStart and cooldown, updates nextStart, and returns. The HTTP fetch happens after that outside the queue. So request A can still be waiting for a response when B and C start.”

**Follow-up: Give me a timeline.** “With slow enough responses, A starts near 0 milliseconds, B near 300, and C near 600. Each can remain in flight. These are illustrative admissions, not promised completion times.”

**Follow-up: Why catch on the queue?** “queue = turn.catch(...) keeps one rejected admission from poisoning the queue forever. The original turn is still returned to its caller, so that caller sees its own failure.”

**Code:** `createRequester`, especially `waitForStart`.

### Q16. Why createRequester instead of putting fetch in the loop?

**Say:** “The requester centralizes timing and retry policy. It returns a function that retains shared queue, pacing, and cooldown state through a closure. downloadAll creates one requester and passes that same function to each window, so all workers coordinate.”

**Follow-up: What is a closure?** “A function that retains access to the lexical variables from where it was created, even after the outer call returns.”

**Follow-up: Why inject fetch, time, waits, randomness, and logging?** “The defaults run normally, but tests replace the environment to drive deterministic failures and time without real API calls or long sleeps. I'm injecting external behavior, not reimplementing the algorithm in the test.”

**Follow-up: Would separate requesters work?** “They would have separate pacing and cooldown state. That would undermine the shared limit across a full run.”

### Q17. What happens on a 429?

**Say:** “The requester classifies it as retryable, calculates exponential backoff with jitter, and honors a longer valid Retry-After. It immediately extends the shared cooldown, then releases the unused error body. Waiting workers recheck that cooldown before starting. The failed worker retries the same page within its existing worker slot.”

**Follow-up: Why publish cooldown before body cancellation?** “Cancellation can take time. Other workers should learn immediately that the server has rate-limited requests, rather than sending requests while cleanup is pending.”

**Follow-up: What about the fourth failed attempt?** “It still publishes a 429 cooldown for other active windows, then throws because there are no retries left.”

**Follow-up: Does it cancel requests already in flight?** “No. It delays upcoming starts.”

### Q18. Explain the retry policy precisely.

**Say:** “There is one initial attempt plus three retries: four attempts maximum per page. Retry waits are roughly one, two, and four seconds plus zero to 249 milliseconds of jitter, or longer if Retry-After requires it. Each retry uses the same URL and returns through the shared gate.”

**Follow-up: What is retryable?** “HTTP 408, 429, 500, 502, 503, and 504; recognized transport failures; and request/body timeouts. Ordinary permanent HTTP errors, malformed JSON, invalid data, invalid pagination, and disk errors are not blindly retried.”

**Follow-up: Why not all TypeErrors?** “Because TypeError can also be a programming bug. The code looks for known network error codes, including nested causes, instead of assuming the type means network failure.”

**Follow-up: Why jitter?** “It reduces synchronized retries when multiple requests or clients fail together.”

### Q19. Is there a maximum total download duration?

**Say:** “No run-wide deadline. Each network attempt gets a fresh 30-second timeout after admission, and attempts are bounded, but queueing, backoff, and a long Retry-After can extend wall time. Other workers also finish their already-started windows after a failure.”

**Follow-up: Why not create the timeout before waiting?** “A worker could consume its network budget while merely waiting for quota admission. Creating it afterward gives the actual HTTP attempt its intended budget.”

**Follow-up: Why the large-timer guard?** “Node timers cannot accept arbitrary huge delays safely. waitUntil sleeps in bounded chunks and rechecks the deadline so a large server delay doesn't overflow into an immediate retry.”

**Follow-up: What would production need?** “An explicit overall deadline, cancellation signal, and policy for excessive server-directed waits.”

### Q20. What happens when one worker fails?

**Say:** “The first failure is recorded, and the pool stops assigning new windows after it observes that failure. Other workers already processing windows continue those entire windows. The outer function waits for them, then throws the recorded failure. The manifest remains incomplete.”

**Follow-up: Why not just let Promise.all reject?** “Promise.all rejection does not cancel work already started. Catching within workers makes the draining policy explicit, so the caller doesn't appear finished while those workers are still writing.”

**Follow-up: Is this fail-fast?** “It fails the run and stops new assignments, but it is not immediate cancellation. 'Drain active windows' is the precise description.”

**Follow-up: Tradeoff?** “Coherent shutdown and retained diagnostics versus extra requests and delayed failure reporting. An abort policy could change that deliberately.”

### Q21. Are yearly windows the most efficient choice?

**Say:** “They're a simple partition with easily checked boundaries, not a claim of optimal scheduling. Free workers take the next window, which handles differences better than fixed assignments. But near the end, one large remaining window can still leave other workers idle.”

**Follow-up: Why not monthly windows?** “More partitions can improve balancing but can add partially filled or empty-window requests. I raised the workload-imbalance concern during development and deferred finer splitting. I would measure those costs before changing it.”

**Follow-up: Would concurrency 30 be ten times faster?** “No. There are only 24 windows, the global pacing still applies, and each chain is sequential. More workers help mainly when latency otherwise leaves the gate underused.”

**Follow-up: What would you measure?** “Per-window report/page counts, active-worker utilization, request latency, time spent waiting, and total elapsed time.”

## D. Storage, validation, and operational review

### Q22. Why have a completion manifest?

**Say:** “A directory containing JSON doesn't tell the analyzer whether the download finished. I write an incomplete marker before requests begin, then publish completion only after every window succeeds and counts reconcile. The final manifest records scope, counts, the unique-ID count, and the exact files that belong to the run. It does not store the individual report IDs.”

**Follow-up: Why write a temporary final file and rename it?** “It separates writing the final document from publishing it. If that write fails, the original incomplete marker remains instead of becoming a partially overwritten success manifest.”

**Follow-up: Is the whole dataset atomic?** “No. Page files are written individually. An interrupted page write can be partial; the run stays incomplete. The rename is a publication boundary, not a database transaction or an fsync-based durability guarantee.”

### Q23. What does the analyzer validate independently?

**Say:** “It checks manifest version and completion, exact outer dates, contiguous ordered windows, coherent counts, and unique contained file paths. It then reads only listed pages, validates each report's required structure and window date, rejects repeated report IDs, and reconciles loaded counts.”

**Follow-up: Is complete=true sufficient?** “No. A manually changed flag cannot bypass those structural and count checks.”

**Follow-up: Why resolve paths?** “A manifest filename such as ../outside.json must not escape the data root. Resolving then checking containment also handles existing symlink resolution. This is a local integrity guard, not a defense against an attacker changing the filesystem between check and use.”

**Follow-up: Does it verify every original page metadata field?** “No. It checks report shape and manifest reconciliation, not each page's `meta.results.total` or page-size cap again. It also lacks checksums, so count-preserving edits can pass.”

### Q24. Why validate everything before filtering?

**Say:** “I want an analysis to mean it came from a valid complete snapshot, even if the user selects a tiny subset. Validating only the selected years could hide corruption elsewhere. The implementation does a full validation pass and then filters.”

**Follow-up: Isn't that inefficient?** “It does unnecessary work for repeated narrow queries, but kept the contract simple at this size. The original full run was measured below the assignment limit. At larger scale I'd validate a versioned snapshot once, then query indexed or partitioned data without redoing the whole scan.”

**Follow-up: Does a filter reduce memory during loading?** “No. All raw reports are loaded first. The filtered selection is a later step.”

### Q25. Why refuse an existing data directory? Is this idempotent?

**Say:** “A fresh root prevents mixing runs or silently overwriting the delivered snapshot. Even an empty existing root is refused before network work. The page writes also use exclusive creation.”

**Follow-up: Is this resumable?** “No. Saved pages remain for inspection, but the next run doesn't reuse them.”

**Follow-up: Is it idempotent?** “The repeated GET is safe to retry as a read, but the complete file-producing command is not a successful rerunnable operation on the same path. Its repeat behavior is a protective failure. I wouldn't label the whole downloader idempotent without qualification.”

**Follow-up: What would resume require?** “Durable checkpoints, verification of existing pages and IDs, safe publication, and a policy for stale cursors or source changes. It is more than skipping filenames that already exist.”

### Q26. How are credentials handled?

**Say:** “The script reads OPENFDA_API_KEY from the environment and includes it only in FDA requests. It doesn't log request URLs or store the key in the completion manifest. Continuation URLs are validated before applying it, and redirects are disabled.”

**Follow-up: Any repository issue today?** “The current checkout has an untracked file named openfda-key, while the ignore rule protects .openfda-key with a leading dot. That filename mismatch needs correcting before staging. The review did not read its contents and did not establish that any credential was committed.”

**Follow-up: Production approach?** “Use the deployment platform's secret injection, keep credentials out of logs and repositories, and verify ignored names match actual files. The code doesn't automatically read the local key file; the environment is its interface.”

This is a concrete current checkout issue, not an invitation to display that file during a screen share.

## E. Filtering, counting, normalization, and numeric reasoning

### Q27. Explain the flexible command-line arguments.

**Say:** “Exact four-digit tokens are years. Other nonblank tokens are joined into one product phrase. No years means 2002 through 2026; one means that year through 2026; two are sorted into an inclusive range. More than two years or years outside the supported range are usage errors.”

**Follow-up: What does python part2.py CARROTS 2026 2024 do?** “It validates the whole snapshot, selects 2024 through January 1, 2026, and searches raw suspect names for CARROTS ignoring case. This snapshot contains 149 matching reports.”

**Follow-up: Does 2024 mean only 2024?** “No. Use 2024 2024 to select only that year.”

**Follow-up: Main ambiguity?** “A standalone four-digit product name looks like a year. Explicit flags would remove that ambiguity in a future interface.”

### Q28. What exactly does a product filter match?

**Say:** “It matches a case-insensitive literal substring of the original name_brand on the same product entry whose role is exactly SUSPECT. It doesn't use regex, fuzzy similarity, ingredient understanding, or the later alias map.”

**Follow-up: Does CARROTS match CARROT?** “No. The plural text is not a substring of the singular. It can match a cosmetic with CARROTS in its name, because this endpoint and interface are not restricted to vegetable products.”

**Follow-up: Does Vitamin D match VIT D after normalization?** “Not during selection. Aliases change ranking groups afterward; they don't expand raw search.”

**Follow-up: What if CARROTS is concomitant and another product is suspect?** “That report doesn't qualify through the concomitant product. Name and role must belong to the same entry.”

### Q29. If a matching report also contains CELERY, do you count it?

**Say:** “The report contributes once to record totals and eligible age statistics, and its outcomes and reactions contribute to those rankings. But in a CARROTS-filtered product ranking, only the matching suspect names contribute. CELERY is excluded from that ranking, following your clarification.”

**Follow-up: Why carry suspectProducts beside the original report?** “That stores the exact eligible names from selection so makeDataFrame doesn't accidentally reintroduce all the other suspects. The original report stays available for its other fields.”

**Follow-up: If there is no product filter?** “All reports in the selected year range qualify, even if they have no suspect products. Their empty suspect list contributes nothing to the product ranking.”

### Q30. What does a count in a Top 25 list mean?

**Say:** “It is the number of selected reports mentioning that normalized term, at most once per report. normalizeTerms normalizes first, then deduplicates with a set. getTopTerms explodes that one list column and counts the resulting values.”

**Follow-up: Why deduplicate after normalization?** “A report might contain both Vitamin D3 and VIT D. They become one label only after the alias rules, so deduplicating the raw names first would still allow two contributions later.”

**Follow-up: Can the sum of counts exceed Total Records?** “Yes. One report can mention several different terms. Each individual term is counted once per report, but the categories aren't mutually exclusive.”

**Follow-up: Why alphabetical tie-breaking?** “Count descending and label ascending makes equally frequent terms deterministic across runs.”

### Q31. Why keep one DataFrame row per report?

**Say:** “Record totals, year counts, and ages are report-level statistics. If I sequentially exploded products and then reactions into the same base table, a report with two products and three reactions could turn into six rows. That would inflate the total and repeat the same age six times.”

**Follow-up: How do you avoid that?** “I keep normalized lists inside the report row and explode only one chosen list when calculating its ranking. The base DataFrame remains unchanged.”

**Follow-up: Is storing the original report a deep copy?** “No. It's a reference to the original dictionary, while the derived fields and normalized lists are new values. The raw JSON files aren't modified.”

**Remember:** one row, one report; explode only for the metric that needs it.

### Q32. Explain the normalization rules and why you didn't use fuzzy matching.

**Say:** “I use deterministic Unicode, case, whitespace, punctuation, and apostrophe cleanup for all term types, then a small product-specific alias list based on inspected variations. That includes Vitamin D forms, NatureMade spacing, and soft-gel variants. The rules are easy to inspect and test. Fuzzy similarity could merge different dosages, formulations, or clinical qualifiers.”

**Follow-up: Are D2 and D3 identical?** “No. They're intentionally grouped as a Vitamin D reporting family for this assignment. That's an aggregation policy, not a chemistry claim.”

**Follow-up: Is the policy perfect?** “No. Generic punctuation removal can also lose meaning. For example, 1.5 MG, 1/5 MG, and 1-5 MG collapse to the same text under the current rule. Those are synthetic counterexamples; this review did not establish those exact incorrect merges in the snapshot.”

**Follow-up: First improvement?** “Preserve numeric notation, inspect many-to-one collisions, and version the mapping.”

### Q33. What would an AI approach to normalization add?

**Say:** “An embedding model or LLM could suggest semantic matches beyond spelling cleanup, but that creates a new decision system to evaluate. For this assignment, an explainable rule set met the clarified scope and avoided heavy NLP dependencies.”

**Follow-up: How would you evaluate a broader matcher?** “Build a reviewed set of pairs that should merge and pairs that must remain separate, including dosage, brand, formulation, and clinical qualifiers. Measure false merges and missed merges, inspect the impact on rankings, and keep raw-to-canonical provenance.”

**Follow-up: Precision or recall?** “Here I'd initially prioritize precision of merges because a false merge changes the meaning of the analysis. A missed merge makes a ranking fragmented but remains inspectable. The right balance still depends on the reporting goal.”

**Follow-up: Human review?** “Use uncertain model suggestions as candidates for review, not silent changes to the authoritative mapping.”

### Q34. Why are there only 13 outcomes? Why keep EXEMPTION 4?

**Say:** “The complete snapshot contains 13 outcome categories, so Top 25 means up to 25 real categories. Ingestion retained the full report fields, and independent inspection reproduced that count. Padding the list would misrepresent the data.”

**Follow-up: What about EXEMPTION 4?** “It's the most common supplied suspect label, appearing in 26,791 reports, but it's a placeholder rather than a useful commercial identity. I retained it because silently excluding the label would omit a supplied category from the requested ranking. A separate analysis could show identified products and placeholders explicitly.”

**Follow-up: Why can DEATH differ between outcomes and reactions?** “They're separate source fields. This snapshot has 12,194 outcome mentions and 12,192 reaction mentions. The code doesn't assume the fields are interchangeable.”

### Q35. How do you calculate ages correctly?

**Say:** “I parse the value, look up the unit factor, convert to years, and accept only finite ages from zero through 125. Years use factor one; months one-twelfth; days one over 365.25; weeks seven over 365.25; decades ten. Missing or rejected ages are excluded only from age calculations.”

**Follow-up: Why not replace missing with zero?** “Zero is a real valid age. Using it for missing data would bias the mean and histogram.”

**Follow-up: Why 125?** “It's a documented plausibility threshold after inspection. It excludes the 68-decades value without discarding the 122.75-year observation. It doesn't certify that every retained age is correct.”

**Follow-up: Why not repair 68 decades to 68 years?** “That would invent a source correction without evidence.”

**Follow-up: Any edge gap?** “An enormous JSON integer can raise OverflowError during float conversion, which the current conversion guard doesn't catch. No such value appears in this snapshot; it's a small robustness fix to make.”

### Q36. Why doesn't the total age mean equal the average of male and female means?

**Say:** “The groups have different sizes, and valid ages with unknown gender also contribute to the total. Averaging the two means would give equal weight to unequal groups and omit unknown-gender observations. The code calculates each mean directly from its valid age values.”

**Follow-up: What are the actual denominators?** “There are 73,819 valid ages overall, including 54,500 female, 17,853 male, and 1,466 without a recognized Female or Male value. The means are 48.29, 50.58, and 42.47 years for total, female, and male.”

**Follow-up: Do missing ages remove a report from the ranking?** “No. The report remains in counts and term rankings if it otherwise matches.”

**Follow-up: Empty group?** “Return None and print N/A, not zero or a misleading mean.”

### Q37. Explain the two plots, especially the age bins.

**Say:** “The yearly bar chart counts selected reports by date_started year and fills absent years with zero. The histogram uses the same valid converted ages as the mean. Edges zero through 126 create 126 one-year bins and include an exact age of 125.”

**Follow-up: Where does age 0.5 go?** “The zero-to-one bin. Age 1 goes in one-to-two. Fractional ages are preserved for the average.”

**Follow-up: Why not bins=125?** “That asks for a number of automatically placed bins, which doesn't necessarily create integer edges or one-year width over the intended domain.”

**Follow-up: Why is 2026 small?** “It contains only January 1. The chart labels the cutoff. Comparing it directly with complete years as a trend would be misleading.”

**Follow-up: Why Agg and close?** “Agg writes without a display. Closing in finally releases the figure after either a successful or failed save.”

### Q38. What happens when the query returns nothing or the chart cannot save?

**Say:** “Zero matches is a valid result: zero records, empty term lists, N/A means, and a two-panel chart with zero yearly counts and no valid ages. The DataFrame still has explicit columns, so empty input doesn't break later operations.”

**Follow-up: What if chart writing fails?** “The command treats the required chart as part of success. main saves it before printing the statistics. A wrapped data error leads to exit code one, and the figure is closed.”

**Follow-up: What are the exit codes?** “Zero on success, two for invalid arguments, one for expected data or output errors. Unexpected exceptions and missing dependencies aren't handled by those specific error classes.”

**Follow-up: Can timestamped files collide?** “Microseconds make ordinary collisions unlikely, but savefig doesn't use exclusive creation. It's not a uniqueness guarantee.”

## F. Testing, performance, AI ownership, and production judgment

### Q39. How did you test without spending API requests?

**Say:** “The Node tests inject responses and controllable timing while still exercising real temporary file writes. They cover cursor chains, boundaries, duplicates, changing totals, retries, shared cooldowns, and worker behavior. A separate opt-in live check verified two real pages before the full download. The saved-data validator then checked every delivered page without calling FDA.”

**Follow-up: What passes today?** “All 98 current ingestion tests and the complete-download validator pass. An independent scan reproduces the dataset's summary figures. The notes record 31 passing Python tests at completion, but this machine currently needs its Python dependencies installed before I can claim a fresh full Python pass.”

**Follow-up: Why aren't tests in the repo?** “I kept them local temporarily. You allowed them but said they wouldn't be reviewed. For a shared team repository, I'd commit the tests and run them in CI.”

### Q40. Tell me about the flaky concurrency test.

**Say:** “The test assumed a single event-loop yield would be enough for three requests to overlap, but filesystem timing could leave only two active at that instant. The fix held the first requests behind a barrier until three had actually started, then released them. That tested overlap deliberately instead of hoping the scheduler produced it.”

**Follow-up: Did production code change?** “No. The history records a test-only synchronization correction. The affected test was run repeatedly afterward, and the current complete ingestion suite passes again.”

**Follow-up: What principle does that illustrate?** “Test the condition you care about using controlled synchronization. Wall-clock sleeps or incidental event-loop timing make concurrency tests fragile.”

**Ownership note:** This correction came from the pair-programming process. Don't rewrite it as “I personally authored the entire fix unassisted” unless that is true.

### Q41. What's the runtime and space complexity?

**Say:** “Ingestion processes each report and page, so CPU work is roughly linear in response size, with ID sets growing with the number of reports. It doesn't retain every full response in memory, but it isn't constant-space because of those sets. Analysis loads all reports and scans their nested text. Ranking then sorts the distinct normalized terms.”

**Follow-up: More precise?** “Let N be reports, P pages, B total input/text size, T selected normalized term mentions, and U distinct terms. Ingestion is roughly O(B + P) expected CPU work plus I/O. Analysis includes O(B), per-report dedup sorting, and roughly O(T + U log U) for each ranking. Storage is O(B); working memory grows with raw records, selected derived data, IDs, and exploded terms.”

**Follow-up: Is pandas automatically faster?** “No. There are Python loops before the DataFrame. Measure the actual pipeline rather than inferring speed from a library name.”

### Q42. How do you prove the under-one-minute requirement?

**Say:** “Time the whole process, including imports, reading and validating the JSON, filtering, rankings, and PNG writing. The final development notes record about 11.9 seconds for the full dataset. Today I independently reproduced the data figures, but I haven't rerun the complete Python CLI because this environment lacks all dependencies.”

**Follow-up: Does the full case cover every argument?** “It's a useful large workload, but doesn't prove every possible input on every laptop. I'd also measure a narrow year range, a common filter, no matches, and supported worst-case input sizes.”

**Follow-up: Would the downloader also need one minute?** “No. That performance requirement is for Part 2. The delivered download took about five minutes seven seconds according to its manifest.”

**Follow-up: First optimization?** “Profile before changing architecture: parsing, validation, normalization, sorting, or plotting. Repeated CLI runs could benefit from a validated derived cache.”

### Q43. What would you change before using this in production?

**Say:** “First I'd make the verification reproducible: commit tests, add CI, pin a tested dependency environment, and correct the credential filename ignore mismatch. Then I'd strengthen transformation provenance and normalization, and add the operational controls the actual deployment needs—such as structured logs, cancellation, overall deadlines, and checkpointing if restart cost justifies it.”

**Follow-up: What about data integrity?** “Add page checksums and record the source version if available. Checksums help detect later file changes; they don't retroactively make the source traversal an immutable snapshot.”

**Follow-up: What about scale?** “Stream incremental counts and age sums or store validated records in a queryable database/columnar format. Pick based on repeated query needs and volume.”

**Follow-up: Is this production-ready now?** “It has deliberate reliability checks for the assessment. It's still a local batch pipeline with explicit limitations, not a deployed production service.”

### Q44. What did AI do, and how do I know you understand the code?

**Say:** “I used an LLM as a pair programmer and review coach, which the assignment allowed. I used it to break the requirements into testable slices, propose implementations and tests, and challenge assumptions. I asked about boundaries, workload balance, output categories, and clarified semantics with you. I'm responsible for understanding and evaluating the final behavior, including the limitations we're discussing.”

**Follow-up: Did you write every line yourself?** Answer honestly about your actual involvement. “It was AI-assisted; I wouldn't claim every line was manually authored. The useful test is whether I can trace it, explain the decisions, recognize weaknesses, and modify it correctly.”

**Follow-up: Show me you understand it.** Choose one concrete trace: shared 429 cooldown, terminal 404 count reconciliation, or the CARROTS report with nonmatching CELERY. Walk through actual function calls and state changes.

**Remember:** transparent assistance; real ownership; demonstrated understanding. Confidence does not require fictional authorship.

### Q45. What can and can't you conclude from the results?

**Say:** “I can describe frequencies and recorded demographics among reports in this saved scope. I can't infer that a product caused a reaction, rank exposure-adjusted product risk, or claim these are unique people. One report can mention multiple products and reactions, and reporting and missingness affect the results.”

**Follow-up: Is SUSPECT proof?** “No. It's the source role used by our filter, not a causal finding.”

**Follow-up: If a product has more reports, is it more dangerous?** “Not from these counts alone. We don't have an exposure denominator, and popularity and reporting practices affect report volume.”

**Follow-up: Why does this matter to an AI team?** “The same distinction applies to AI outputs: a polished output isn't enough. The system has to preserve what the data supports and avoid silently strengthening the claim.” [FDA's explanation of report interpretation](https://open.fda.gov/apis/food/event/).

### Q46. What would you do if I asked you to change the code live?

**Say:** “First I'd restate the behavior change and identify the function that owns it, then trace what else depends on that contract. I'd make a small change and verify a representative example plus the boundary case.”

**Possible task: change default concurrency.** Point to `runDownload`, `getConcurrency`, and `downloadAll`; note the assignment currently requires three, so distinguish a hypothetical new requirement from a cleanup.

**Possible task: add a product alias.** Inspect raw variants, add a narrow rule, test an intended merge and a nearby value that must remain distinct, and verify per-report dedup after the merge.

**Possible task: add a gender count.** Work from the one-row-per-report DataFrame; define whether the count needs valid age or merely a recognized gender before computing it.

**Possible task: fix huge integer ages.** Catch OverflowError in the conversion guard and test that it returns None while the report remains eligible for other statistics.

**Possible task: stream analysis.** Explain that this changes loading, validation timing, and output accumulation. It is a design change, not a one-line pandas trick.

## G. Questions you can ask Alex

Choose one or two that fit the discussion. Do not mechanically ask the entire list.

- “For a production version, which would matter most in your environment: recurring updates, recovery from an interrupted run, or repeated analysis queries?”
- “For term consolidation, would you want a stable reporting taxonomy, or would the grouping depend on the analyst's question?”
- “When your team evaluates an AI-assisted implementation, what evidence gives you the most confidence that the engineer owns the behavior?”
- “Is there a design choice here you would simplify or handle differently on your team?”

## H. If you blank during the review

Use a precise pause instead of guessing: “Let me trace the order here so I answer accurately.” Open the owning function. Identify inputs, state, the next await or return, and the success/failure condition.

If it is a choice you didn't originally consider: “That wasn't a tradeoff I explicitly evaluated at the time. Looking at the current behavior, the consequence is ____. I'd verify ____ before changing it.”

If Alex identifies a valid weakness: “Yes, that's a real limitation. The current code guarantees ____, but not ____. I'd address it by ____ and verify ____.”

If a number escapes you: explain the invariant first and look up the result. Forgetting 73,819 is recoverable. Claiming missing ages count as zero is a different category of problem.
