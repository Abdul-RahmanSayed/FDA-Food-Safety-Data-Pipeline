# USAN FDA Pipeline — Code Review Handbook

Prepared for Abdul-Rahman Sayed, September 6, 2026. Reviewed source: commit `dc44199`, with 465 lines in `part1.js` and 512 lines in `part2.py`. The application source and saved dataset were not changed for this preparation.

This handbook has three sections: **understand the code**, **practice the review**, and **memorize the essentials**. The HTML edition includes navigation and the full numbered source so you can move from an explanation to the relevant code. Use the shorter answers aloud; use the deeper explanations to recover the reasoning when Alex follows up.

You do not need to perform a dramatic recital of 977 lines of code. You do need to know what each layer promises, how the program enforces that promise, and where the promise stops.

The speaking pattern comes from your **Career Handoff and Resume Review** conversation: answer the question, provide one useful example or result, then stop. The answers below are suggested wording, not a script or a claim that Alex will ask these exact questions. A VP reviewing this project could reasonably probe requirements, reliability, data meaning, tradeoffs, testing, and ownership of AI-assisted work.

## How the evidence is used

- **Actual history:** the [shared project conversation](https://chatgpt.com/s/cx_6a9b429a2c508191a790f06634f40b71), including the original assignment, your questions, and Alex's reported replies; the local `REVIEW_NOTES.md`; and Git commits.
- **Current behavior:** direct inspection of the two scripts, README, dependency file, ignore rules, saved manifest, and local tests.
- **Fresh verification:** 98 ingestion tests passed; the separate complete-download validator passed; an independent scan reproduced the report, filtering, normalization, and age figures. No live FDA ingestion was run during this review.
- **Historical verification:** the final build notes record 31 passing Python tests and an approximately 11.9-second full analysis with plotting. Those results belong to the original development environment. This checkout currently lacks a ready Python environment with all three required libraries, so the Python suite and full plotting runtime were not freshly verified.
- **Suggested reasoning:** when the code supports a tradeoff but the conversation does not establish that it was your original motivation, treat the explanation as something you can understand and defend now. Do not invent a story about having personally discovered every issue before implementation.

The old heading “Current implementation: one-page ingestion slice” at the top of `REVIEW_NOTES.md` is historical. It is not the current program. Its final-audit statement that changes await a commit is also superseded: Git now contains the final implementation in `dc44199`. Current manifest timestamps are 2026-09-04 18:24:34.942 UTC through 18:29:41.824 UTC, about 306.9 seconds. The notes contain different clock timestamps; use the manifest if you need exact times, or simply say “about five minutes seven seconds.”

## Start here: your one-minute project explanation

“The project has two stages. The Node script downloads FDA adverse-event reports for the exact assignment date range, and the Python script analyzes the saved snapshot.

For ingestion, I use independent date windows so requests can overlap across windows, while following each window's cursor sequentially. I validate the response data and pagination, pace all requests through a shared requester, and retry selected temporary failures. The download is only published as complete after counts and unique IDs reconcile across all planned windows.

For analysis, I validate the saved dataset, select reports by year and suspect-product text, and keep one row per report. That prevents products and reactions from multiplying record counts or age observations. Then I normalize and deduplicate terms within each report, calculate rankings and valid-age averages, and save the two required plots.

The saved result contains 97,652 reports. The main design priority was being able to explain why those results are complete and what the statistics actually mean.”

Stop there. You have given Alex several useful places to go deeper.

# Section 1: Understand the code and the decisions

## 1.1 What was required, clarified, or chosen

| Topic | Status | What to say accurately |
|---|---|---|
| Node.js ingestion, Python analysis | Explicit assignment | The language split was required. JSON is the file-based handoff. |
| `pandas`, `numpy`, `matplotlib` | Explicit assignment | All three were required; pandas and Matplotlib were not alternatives. |
| `date_started` from 2002-01-01 through 2026-01-01 inclusive | Explicit assignment | Both endpoints count. The API is not being queried by download date or `date_created`. |
| `limit=100` on every report request | Explicit assignment | Request at most 100; do not increase it to 1,000 for speed. Responses can be shorter. |
| Configurable concurrency, default 3 | Explicit assignment | Three is required as the default. Actual requests overlap when latency/work permit, up to that cap. |
| 24 yearly windows | Chosen design, refined with you | Independent cursor chains provide concurrency; only the final window extends to next January 1. |
| Fixed meaning of “Present” | Your explicit clarification | Analyze the saved Part 1 range; do not fetch through today's date. |
| Count each normalized term once per report | Alex's reply in the shared conversation | This is report frequency, not the number of repeated array entries. |
| Filtered product ranking includes matching suspects only | Alex's expressed preference, adopted | Nonmatching suspects in a selected report do not enter the product ranking. |
| Normalization plus a small documented alias map | Alex accepted the minimum approach | Generic cleanup applies to all terms; narrow product aliases address inspected spelling families. |
| Offline tests kept local | Your temporary repository choice | Alex allowed tests but said they would not be reviewed. He did not forbid committing them. |
| JSON data committed under `data/` | Required deliverable and your clarification | This is intentional for the assessment; large recurring datasets would usually live elsewhere. |
| Two-panel timestamped PNG, Top 25 lists, three age means, flexible arguments | Explicit assignment | Empty results and fewer than 25 categories still need truthful output. |
| Complete Part 2 run under one minute | Explicit assignment | Measure file reads, validation, analysis, and chart writing, not just one calculation. |
| 300 ms pacing; 30-second attempt timeout; three retries | Chosen robustness policy | These enforce predictable behavior under temporary network problems. |
| Completion manifest, fresh output root, no resume | Chosen correctness/scope policy | Detect incomplete or mixed runs without building a checkpoint/resume system. |
| Age range 0–125 after conversion | Documented project plausibility policy | Data inspection found 680 years after conversion and a retained 122.75-year value. |

The optional year and product arguments are **optional for the caller**. Implementing their support was required. There was no separate bonus-features list to complete.

## 1.2 Your actual decision story

**You began by connecting Part 2 to your earlier D3 work.** That is a useful connection: input data, representation, filtering, aggregation, and visualization. The new challenge in Part 1 was proving that a multi-request download did not silently omit anything.

**You asked for acceptance criteria before implementation.** The initial conversation explicitly asked the pair programmer to separate requirements from assumptions, identify risk, use small reviewable slices, and explain the code. You were allowed to use LLMs and stated that you owned the decisions and would have to explain them.

**You challenged the year split.** You asked whether yearly windows were an efficiency choice or a requirement. They were a design choice. You then wanted to avoid a final window consisting of only January 1, 2026. Making every window January 1 to next January 1 inclusive would overlap boundaries, so the adopted design extends only the final 2025 window. That is a concrete requirements-and-correctness discussion you can describe honestly.

**You asked about uneven workloads.** Smaller windows could improve distribution across workers, but increase empty/partial-page overhead. You explicitly deferred changing the split. Measuring those costs would inform a later decision. The current dynamic queue lets each free worker take another year; it cannot split the final large in-progress window between idle workers.

**You clarified counting with Alex before finalizing analysis.** His preference changed an earlier assumption that all suspects in selected reports would be ranked. The implemented version selects a report using matching suspects and carries only those matching names into the product ranking. Its other report fields still contribute.

**You made the generic behavior explicit.** CARROTS is an example of any product phrase; Vitamin D is an example of consolidation. The CLI does not contain a CARROTS special case. Generic text cleanup applies broadly; the alias list is deliberately finite, not an automatic solution to every synonym.

**You questioned whether 13 outcomes meant extraction had lost data.** The complete snapshot contains only 13 distinct outcome labels. The correct response was to inspect all data and preserve the real categories, not manufacture twelve extras to appease a heading.

**The age policy followed data inspection.** Raw age units include years, months, weeks, days, and decades. A value of 68 decades becomes 680 years. Excluding that value from age statistics while keeping its report avoids guessing that the source meant 68 years. Missing age never becomes zero.

**A concurrency test exposed a timing assumption.** The history records a test observing two simultaneous requests when it expected three. The fix was an explicit barrier that held requests until three had started, then released them. Production code did not change. Describe this as a test synchronization problem fixed with controlled promises, rather than claiming retries had broken production concurrency.

## 1.3 Why the build order mattered

| Checkpoint | What became trustworthy | Why the next step depended on it |
|---|---|---|
| `93d4545`: first page | Request shape, data validation, exclusive save | Needed a known-good page before traversal. |
| `5bc501b`: one full window | Cursor progression and final count reconciliation | Needed a complete sequential unit before parallelizing. |
| `ee093ce`: concurrent full-range workers | Disjoint coverage, dynamic work assignment, actual overlap | Needed bounded parallel work before shared retry/pacing. |
| Retry/pacing slice | Shared starts, backoff, cooldown, timeout classification | Needed predictable API behavior before a large live download. |
| Manifest/global IDs slice | Persisted incomplete marker and run-level uniqueness | Needed a trustworthy handoff to analysis. |
| Small live check | Two-page compatibility with deployed FDA cursor behavior | Offline fixtures alone could not verify that contract. |
| `e24ce99`: resilient ingestion and dataset | Completed raw snapshot with independent disk audit | Analysis rules could now be based on observed data. |
| Analysis slices | Loading/filtering → ages → normalized rankings → chart | Each derived result had its own verification boundary. |
| `dc44199`: final analysis/audit | HTTP 408 handling, full manifest adjacency, docs and chart | Closed remaining contract/documentation gaps. |

Not every slice corresponds to a separate commit. The development discussion and review notes contain finer checkpoints than the six-commit history.

## 1.4 The big picture and the important boundaries

```text
FDA HTTPS API
    |
    | validated pages from 24 non-overlapping date windows
    v
part1.js: 3 workers -> shared pacing/retries -> exclusive JSON saves
    |
    | exhausted cursor chains + reconciled totals and IDs
    v
data/manifest.json: complete=true + exact page inventory
    |
    | validate manifest, every listed page, every report, global IDs
    v
part2.py: select report rows -> derive normalized lists and valid ages
    |                                      |
    v                                      v
stdout: totals/rankings/means       charts/<timestamp>.png
```

**Ingestion boundary:** it checks retrieval identity, dates, total shape, and cursors; it preserves analysis fields rather than requiring age or product semantics at download time.

**Analysis boundary:** it validates the fields it will actually use. A malformed required report structure is an error; a missing or unusable age generally excludes that age only. A valid empty selection is success.

**Storage boundary:** the manifest is an inventory and completion record. The reader does not recursively analyze every JSON file it happens to find. A temporary sample file or manifest itself cannot accidentally become report data.

**Statistical boundary:** a row is a report. Several reports could concern the same person or incident. A report can list several products and reactions without assigning a particular reaction to a particular product. These frequencies cannot establish causation or exposure-adjusted risk. [FDA explains these dataset limitations](https://open.fda.gov/apis/food/event/).

## 1.5 Six numbers to recognize, not obsess over

| Number | Meaning |
|---|---|
| 97,652 | Saved reports and unique report numbers. |
| 987 | Saved response-page files, plus one separate manifest. |
| 24 | Independent date windows; also, coincidentally, reports on January 1, 2026. These are unrelated counts. |
| 73,819 | Valid age observations; the overall mean is based on these, not all 97,652 reports. |
| 13 | Available outcome categories in this snapshot. |
| 3 / 100 / 300 / 30 / 4 | Default workers / request limit / milliseconds between starts / seconds per attempt / attempts maximum. |

## 1.6 How to read the detailed walkthroughs

Read execution order first, then the code blocks. Function definitions appear before the entry point but do not execute their bodies until called. The line ranges in the next two parts cover every function and meaningful statement group; blank lines and closing braces are grouped with the behavior they belong to.


## 1.7 Part 1: the downloader, almost line by line

Prepared from the current `part1.js` (465 lines), `README.md`, `REVIEW_NOTES.md`, `data/manifest.json`, the commit history at `dc44199`, and the [shared project conversation](https://chatgpt.com/s/cx_6a9b429a2c508191a790f06634f40b71). Application code was not changed. References to notes describe recorded decisions or historical verification, not a new test run. Where checkpoint notes conflict with the exact assignment or current artifacts, the assignment and current artifacts take precedence.

### The explanation to give before opening the code

> “I split the project into an ingestion stage and an analysis stage. The Node script downloads the fixed FDA date range and saves the original response data. The Python script then analyzes that local snapshot, so changing an analysis filter does not require another API download. For ingestion, I process independent date windows concurrently, but I follow the cursor within each window sequentially. Every page is validated before saving, and I only publish a completed manifest after the page counts, reported totals, and unique report IDs reconcile.”

The fixed search is `date_started` from January 1, 2002 through January 1, 2026 **inclusive**. The final date is one day of 2026, not the entire year and not today's date. The downloader searches by the report's `date_started` field; do not describe it as a download-date or report-received-date filter.

The raw API responses are the handoff between languages. Keeping ingestion and analysis separate makes the analysis reproducible against a committed snapshot and avoids consuming API requests every time someone runs a different report. The current code writes parsed JSON back with two-space indentation, so it preserves the JSON values and response envelope, not the original bytes or whitespace of the HTTP body.

### How execution actually starts

The source is organized as helpers followed by orchestration. The runtime does **not** execute every function body from top to bottom when the file loads.

1. Lines 1–16 import built-in modules and initialize configuration and retry sets.
2. Function declarations make their functions available. Their bodies wait to be called.
3. Lines 458–463 detect a direct CLI invocation and call `runDownload()`.
4. `runDownload()` validates the environment configuration, then calls `downloadAll()`.
5. `downloadAll()` creates one shared requester, claims the output directory, writes an incomplete manifest, and starts the worker pool.
6. Each worker claims one window and calls `downloadWindow()`.
7. Each window repeats: obtain request admission → fetch/read a page, with retries when eligible → validate the next link and report data → reserve identifiers → write the page → follow the next cursor.
8. Each window reconciles its final counts before returning success.
9. The pool waits for all active workers. On overall success, it reconciles the run, writes the complete manifest to a temporary file, and replaces the incomplete manifest.
10. `runDownload()` prints the successful summary. On failure, the CLI catch prints a contextual error and sets exit code 1.

When a test uses `require('./part1.js')`, the `require.main === module` condition is false. Tests can use the exported helpers without initiating a download. The exported public helpers are listed at line 465; internal helpers are exercised indirectly through them.

```text
CLI/environment
      |
      v
runDownload -> downloadAll -> incomplete manifest
                    |
                    +--> worker A -> one window -> sequential cursor pages
                    +--> worker B -> one window -> sequential cursor pages
                    +--> worker C -> one window -> sequential cursor pages
                              |          |
                              +----------+--> shared requester/pacing/cooldown
                    |
                    v
       reconcile all windows and unique IDs
                    |
                    v
       write temporary completed manifest -> rename
                    |
                    v
              Python analysis
```

### A map of every function

| Function / code | Current lines | Responsibility |
|---|---:|---|
| Imports and constants | 1–16 | Built-in I/O, date bounds, request/retry policy |
| `checkDate` | 18–29 | Validate one real `YYYYMMDD` calendar date |
| `checkDates` | 31–38 | Validate both bounds and their order |
| `getWindows` | 40–52 | Build the 24 fixed assignment windows |
| `getConcurrency` | 54–60 | Parse and validate a positive safe integer |
| `getPageName` | 62–64 | Keep saved names and manifest names consistent |
| `getPageUrl` | 66–76 | Build the initial FDA query |
| `checkPage` | 78–109 | Validate one response's envelope and report identities/dates |
| `getNextUrl` | 111–168 | Extract and validate the server-provided cursor URL |
| `getRetryDelay` | 170–178 | Interpret a usable `Retry-After` delay |
| `isNetworkError` | 180–186 | Recognize known transport errors, including nested errors |
| `createRequester` | 188–243 | Create one shared pacing/retry closure |
| `waitUntil` (nested) | 193–198 | Wait until a deadline with timer-size protection |
| `waitForStart` (nested) | 200–210 | Serialize request admission, not HTTP fetching |
| `requestPage` (returned closure) | 212–242 | Retry one page under shared request policy |
| `fetchPage` | 245–280 | Perform and decode one HTTP attempt |
| `downloadWindow` | 282–357 | Exhaust one cursor chain and save validated pages |
| `downloadAll` | 359–448 | Run the pool and publish the completed manifest |
| `worker` (nested) | 391–412 | Claim windows, store results, and record the first failure |
| `runDownload` | 450–456 | Connect environment configuration to the downloader |
| CLI guard and exports | 458–465 | Keep imports safe and CLI failures visible |

### Walkthrough: configuration and small validation helpers

#### Lines 1–16: what is configured and why

[View part1.js at line 1](<C:/Users/abdul/OneDrive/Documents/GitHub/FDA-Food-Safety-Data-Pipeline/part1.js:1>)

- **Line 1:** destructures promise-based `mkdir`, `writeFile`, and `rename` from Node's filesystem API. They can be awaited, so asynchronous filesystem I/O fits the same control flow as HTTP requests.
- **Line 2:** aliases the promise version of `setTimeout` to `sleep`. Unlike callback-style `setTimeout`, `sleep(milliseconds)` returns a promise suitable for `await`.
- **Line 3:** imports `path` so default filesystem paths work across operating systems.
- **Line 5:** fixes the food adverse-event endpoint. Pagination links must return to this same origin and pathname.
- **Lines 6–7:** hold the assignment bounds as fixed-width strings. These dates are a scope choice documented in the notes, not a “current year” calculation.
- **Line 8:** sets the requested page limit to 100. The request parameter is always 100; an actual page can contain fewer than 100 reports. Saying “every response contains exactly 100 records” would be incorrect.
- **Line 9:** makes each network attempt subject to a 30,000 ms timeout. This does not cap the entire download or include time waiting for admission/backoff.
- **Line 10:** requires at least 300 ms between request admissions in this process.
- **Line 11:** permits three retries after the original attempt: four attempts total.
- **Line 12:** lists HTTP statuses treated as temporary: 408, 429, 500, 502, 503, 504. The `Set` provides direct membership checks and communicates that status order is irrelevant.
- **Lines 13–16:** enumerate recognized DNS, connection, socket, and Undici transport codes. Node's built-in fetch can wrap a useful error code inside another error; `isNetworkError` handles that later.

**Decision basis:** the exact assignment in the shared conversation requires **Node.js**, **`limit=100`**, and a configurable **`CONCURRENCY_LIMIT` defaulting to 3**. The yearly partitioning, standard-library-only implementation, 300 ms pacing, and retry defaults are implementation choices. UTC validation, preserving JSON values, optional environment key, and no key-containing URL logging are recorded in `REVIEW_NOTES.md:77–100`; pacing/retry reasons appear at `315–334`. HTTP 408 was added in the final audit and is present in the current code (`REVIEW_NOTES.md:923–925`; commit `dc44199`).

#### `checkDate`, lines 18–29

[View part1.js at line 18](<C:/Users/abdul/OneDrive/Documents/GitHub/FDA-Food-Safety-Data-Pipeline/part1.js:18>)

1. **Lines 19–21:** require a string of exactly eight digits. This rejects numbers, separators, trailing text, and malformed widths before date parsing.
2. **Lines 23–24:** turn `20240229` into `2024-02-29T00:00:00Z`. The `Z` specifies UTC, keeping local timezones out of validation.
3. **Lines 25–27:** check for an invalid date and compare the parsed date back to the original calendar text. Some impossible inputs normalize into a later day. Merely obtaining a `Date` object would therefore be insufficient. February 30 must fail rather than silently becoming a March date.
4. Successful validation returns implicitly with `undefined`; this is a guard function, not a conversion function. The caller continues to use the original string.

**What to say:** “I check syntax first, then real calendar validity. Once a date is a valid, fixed-width `YYYYMMDD` string, lexicographic comparisons have chronological meaning.”

#### `checkDates`, lines 31–38

[View part1.js at line 31](<C:/Users/abdul/OneDrive/Documents/GitHub/FDA-Food-Safety-Data-Pipeline/part1.js:31>)

- **Lines 32–33:** validate the start and end individually.
- **Lines 34–37:** reject a start later than the end. Equality is allowed, so a one-day window is valid.
- A range such as `20240230` through `20240301` cannot slip through merely because its strings are in order: `checkDate` rejects the first bound before comparison.

#### `getWindows`, lines 40–52

[View part1.js at line 40](<C:/Users/abdul/OneDrive/Documents/GitHub/FDA-Food-Safety-Data-Pipeline/part1.js:40>)

- **Line 41:** starts the array.
- **Line 42:** reads 2002 from `defaultStart`.
- **Line 43:** reads 2026 from `defaultEnd`, then subtracts one to make 2025 the last loop year.
- **Lines 44–49:** create one entry per year from 2002 through 2025, inclusive. Ordinary entries run January 1 through December 31. The last entry runs `20250101` through `20260101`, retaining the exact inclusive upper bound.
- **Line 51:** returns 24 windows: 23 ordinary full calendar years for 2002–2024, plus the final extended 2025 window.

Adjacent windows do not overlap. The 2024 window ends `20241231`; the next starts `20250101`. January 1, 2026 occurs only in the final window. The documented date-coverage test counted 8,767 included days (`REVIEW_NOTES.md:247–250`).

**Why yearly windows?** Each window starts an independent cursor chain. That supplies useful parallel work without trying to guess the next cursor inside one chain. Yearly boundaries are also easy to inspect. They are not equally sized by report count, so this is simple partitioning rather than optimal load balancing.

**The workload-imbalance discussion actually happened:** in the shared project conversation, Abdul asked whether more or fewer date windows would be more efficient. The discussion identified the possibility of one worker remaining busy with a large window after the others finish. The shared next-window index improves utilization compared with permanently assigning each worker a static set of years: whichever worker finishes first claims the next unstarted window. However, it cannot split a window that is already being processed, so the last large window can still become a straggler. Monthly partitions and targeted splitting were considered, and Abdul chose to “put a pin on that for now.” This is a documented deferred optimization. The assigned default of three workers and the chosen year-based task granularity are separate decisions.

**A grounded answer to Alex:** “I noticed the possible last-window bottleneck. A shared queue avoids leaving a worker idle while unstarted windows remain, but it does not eliminate an unusually large final window. I kept the yearly partitioning for this version and deferred finer splitting. I would first measure whether the bottleneck is uneven window work, API latency, or the shared pacing limit; splitting further would not remove the 300 ms request-start limit.”

**Precise limitation:** this helper is tailored to the hardcoded bounds. It is not a general date-partitioning utility. Changing only the constants to arbitrary midyear dates would require redesigning and testing this function; its initial start always uses January 1 and its last loop year assumes the current upper-bound arrangement.

#### `getConcurrency`, lines 54–60

[View part1.js at line 54](<C:/Users/abdul/OneDrive/Documents/GitHub/FDA-Food-Safety-Data-Pipeline/part1.js:54>)

- **Line 54:** the default parameter supplies `3` only when the argument is `undefined` or absent. `null` does not trigger a JavaScript default parameter.
- **Line 55:** converts a string only if its trimmed form contains digits exclusively. `" 3 "` and `"003"` become 3. `"3abc"`, `"3.5"`, `"+3"`, and `"1e3"` are rejected rather than partially parsed.
- **Lines 56–58:** require a safe integer greater than zero. `0`, negative numbers, fractions, `NaN`, and extremely large unsafe integers fail.
- **Line 59:** returns the validated number. Later, actual workers are capped at the number of windows. Setting 30 does not create 30 workers for 24 windows.

**Why not `parseInt`?** `parseInt('3abc', 10)` accepts an invalid configuration as 3. Configuration errors should be obvious before filesystem or network activity begins.

#### `getPageName`, lines 62–64

[View part1.js at line 62](<C:/Users/abdul/OneDrive/Documents/GitHub/FDA-Food-Safety-Data-Pipeline/part1.js:62>)

`String(pageNumber).padStart(6, '0')` produces names such as `page-000001.json`. Padding keeps ordinary filename sorting in page order for this dataset. The same helper builds actual page filenames and final manifest entries, preventing two separate naming rules from drifting. Six digits are a minimum width, not a maximum number of pages.

#### `getPageUrl`, lines 66–76

[View part1.js at line 66](<C:/Users/abdul/OneDrive/Documents/GitHub/FDA-Food-Safety-Data-Pipeline/part1.js:66>)

- **Line 67:** validates bounds before constructing a query.
- **Line 68:** creates a `URL` object for the fixed endpoint.
- **Line 69:** uses an inclusive FDA range query: `date_started:[20020101 TO 20021231]`, for example.
- **Line 70:** sets `limit=100`.
- **Line 71:** requests ascending `date_started` order.
- **Lines 72–74:** include an API key only if a truthy value was supplied.
- **Line 75:** returns a URL object. `URLSearchParams` handles encoding of spaces, brackets, and other special characters; string concatenation would make encoding and validation easier to get wrong.

The code does not invent a tie-breaking cursor from dates. Multiple reports may share the same date, so jumping to a later date risks losing reports. The server supplies continuation state through its cursor.

### Walkthrough: validating the API contract

#### `checkPage`, lines 78–109

[View part1.js at line 78](<C:/Users/abdul/OneDrive/Documents/GitHub/FDA-Food-Safety-Data-Pipeline/part1.js:78>)

This function validates the minimum ingestion contract. It does not validate every clinical or analytical field.

1. **Line 79:** validate the requested bounds again so this exported validator is safe to call directly.
2. **Lines 80–82:** require a non-null response with a `results` array. Successful HTTP status alone does not make the response usable.
3. **Lines 83–85:** reject an oversized page. An empty array is structurally allowed here.
4. **Lines 87–90:** extract `meta.results.total` with optional chaining and require a safe integer at least as large as the current page length. Since page length is nonnegative, this also rejects negative totals.
5. **Lines 92–93:** create a temporary set for identities on this page.
6. **Lines 94–99:** iterate over reports and require each `report_number` to be a nonempty string. The whitespace check establishes nonemptiness; IDs are still stored and compared in their original string form.
7. **Line 100:** validate the report's actual calendar date.
8. **Lines 101–103:** reject reports outside either inclusive window boundary.
9. **Lines 104–107:** reject repeated report numbers within the same page, then record each accepted ID.

**What it intentionally leaves for other layers:** cross-page/run duplicates, stable window totals, and completeness belong to `downloadWindow`/`downloadAll`. Consumer age, outcomes, reactions, and products belong to the analysis validation/hygiene layer. Downloading raw data should not silently throw away a report because its age is missing.

**Do not overclaim:** this validator does not verify that results are actually sorted ascending, nor does it validate every metadata field. It requests the sort and checks the dates, identifiers, page size, and total it needs for ingestion.

#### `getNextUrl`, lines 111–168

[View part1.js at line 111](<C:/Users/abdul/OneDrive/Documents/GitHub/FDA-Food-Safety-Data-Pipeline/part1.js:111>)

The key idea: a server-provided URL is input that still needs validation. The code follows the FDA's opaque cursor while checking that the continuation remains part of the original query.

- **Lines 112–114:** no Link header means no continuation URL.
- **Lines 116–120:** split the header into entries at comma boundaries before `<`, extract each `<URL>` and its parameters, and find its `rel` parameter. The regular expression accepts quoted or unquoted relations and case-insensitive `rel` spelling.
- **Lines 121–123:** malformed entries fail explicitly, even if the malformed entry is not the next relation. This is intentionally strict parsing, not a universal Link-header library.
- **Line 124:** lowercase relation tokens and split their whitespace. A relation field may contain multiple tokens.
- **Lines 125–127:** skip valid entries that do not have the `next` relation.
- **Lines 128–130:** reject two different `next` entries rather than arbitrarily choose one.
- **Lines 131–135:** require a parseable absolute URL, reporting a clear next-page error otherwise.
- **Lines 137–139:** a valid header with only non-next relations means pagination has ended.
- **Line 141:** reconstruct the expected initial query for comparison.
- **Lines 142–145:** require the same origin and pathname, with no username, password, or fragment. This stops continuation from changing the endpoint or introducing URL credentials.
- **Lines 146–151:** require exactly one `search`, one `limit`, and one `sort`, each equal to the original decoded value. Checking `getAll(...).length` rejects repeated/ambiguous parameters. Query-parameter order may change without failing because comparisons use parsed parameters.
- **Lines 152–155:** require exactly one nonempty `search_after` value. Its internal format is not interpreted.
- **Lines 156–160:** accept an optional single `skip=0` because the FDA's cursor links can contain it. Reject nonzero skip and repeated skip values. The code is not using offset pagination.
- **Lines 161–163:** reject a `count` parameter because aggregate counts are not report pages.
- **Lines 164–166:** overwrite the key parameter with the configured key when present, preserving authentication across pages.
- **Line 167:** return the validated URL.

**Boundary of protection:** this checks required parameters and certain prohibited ones; it is not a blanket allowlist rejecting every possible extra query parameter. The same-endpoint check and `redirect: 'error'` in `fetchPage` work together: validation cannot be bypassed by automatically following an HTTP redirect to another destination.

**What to say:** “I let the server define the continuation cursor, but I verify that its URL still represents the exact search and page size I started. I track previously used cursor values to detect loops. I don't assume a short page or the last date means the chain is finished.”

### Walkthrough: request scheduling, timeouts, and retries

#### `getRetryDelay`, lines 170–178

[View part1.js at line 170](<C:/Users/abdul/OneDrive/Documents/GitHub/FDA-Food-Safety-Data-Pipeline/part1.js:170>)

- **Line 171:** trim the header or use an empty string when it is absent.
- **Lines 172–174:** handle date-form values as GMT, including older HTTP-date forms without an explicit timezone suffix.
- **Lines 175–176:** all-digit values become whole seconds converted to milliseconds. A value beginning like an HTTP date is parsed and converted into a delay relative to the supplied `now`. Other input yields zero.
- **Line 177:** return only a positive safe-integer delay. Invalid, past, zero, fractional numeric, non-finite, or out-of-range values fall back to zero. The requester will still use its local exponential backoff.

Examples: `Retry-After: 5` supplies 5,000 ms; `Retry-After: 0.5` supplies no usable server delay under this parser. A future HTTP date supplies the remaining time until that date. This uses the machine's clock, so production-grade clock handling and a total job deadline would be possible improvements.

#### `isNetworkError`, lines 180–186

[View part1.js at line 180](<C:/Users/abdul/OneDrive/Documents/GitHub/FDA-Food-Safety-Data-Pipeline/part1.js:180>)

- **Lines 181–183:** a missing error is not a network error.
- **Lines 184–185:** accept a recognized `error.code`, recursively inspect its `cause`, or inspect the members of an `AggregateError`.
- JavaScript's `||` short-circuits from left to right: once any branch proves a recognized network error, later branches need not execute.

**Why inspect causes?** A top-level fetch `TypeError` may wrap a meaningful transport error. Retrying every `TypeError` would also hide programming mistakes. The explicit code set makes the retry policy narrower and explainable.

#### `createRequester`, lines 188–243: the closure

[View part1.js at line 188](<C:/Users/abdul/OneDrive/Documents/GitHub/FDA-Food-Safety-Data-Pipeline/part1.js:188>)

**Line 188** accepts injectable dependencies with real defaults:

| Dependency | Default | Why injection helps |
|---|---|---|
| `fetchData` | `globalThis.fetch` | Supply deterministic offline responses/errors |
| `now` | `Date.now` | Advance a fake clock without waiting minutes |
| `wait` | Promise-based `sleep` | Record/simulate waits |
| `random` | `Math.random` | Make jitter deterministic in tests |
| `log` | `console.warn` | Assert messages or avoid noisy tests |

**Lines 189–191** create the shared state captured by the returned function:

- `queue` starts as a resolved promise. It chains admission turns in order.
- `nextStart` is the earliest time the next request may start under ordinary pacing.
- `cooldown` is the earliest time any subsequent request may start after a 429.

Calling `createRequester()` once returns a function that continues to reference those same variables. Calling it separately for every worker would create separate gates and lose global pacing. `downloadAll` passes **one shared instance** into all windows.

#### Nested `waitUntil`, lines 193–198

[View part1.js at line 193](<C:/Users/abdul/OneDrive/Documents/GitHub/FDA-Food-Safety-Data-Pipeline/part1.js:193>)

The loop keeps waiting until the clock reaches the deadline. A single wait is capped at 2,147,483,647 ms because Node's timer representation cannot safely accept arbitrary huge intervals. Long valid server waits are split into chunks instead of overflowing into an immediate timer. Rechecking the clock also handles early timer wakes.

There is no configured overall job deadline. Four attempts are bounded; total elapsed time is not strictly bounded when a valid server delay can be very long.

#### Nested `waitForStart`, lines 200–210

[View part1.js at line 200](<C:/Users/abdul/OneDrive/Documents/GitHub/FDA-Food-Safety-Data-Pipeline/part1.js:200>)

1. **Line 201:** append an async admission turn to the previous queue promise.
2. **Lines 203–205:** wait until both ordinary spacing and shared cooldown permit a start. `Math.max(nextStart, cooldown)` chooses the stricter deadline.
3. The outer `while` matters: another worker can extend `cooldown` while this turn sleeps. Waking for the old deadline does not automatically grant admission.
4. **Line 206:** after admission, set the next start to `now() + 300`, based on the actual current time. A delayed event-loop wake does not release several missed slots as a burst.
5. **Line 208:** store a caught version of the turn as the next queue anchor, so one rejected admission does not permanently poison all later queue turns.
6. **Line 209:** return the original turn to this caller so its own admission error is still visible.

**Most important detail:** the queue contains the waiting/admission work, **not the fetch**. Once admitted, the worker fetches outside the queue while another admission turn can wait for its next slot. Wrapping the entire fetch inside the chained turn would accidentally serialize network requests.

At 300 ms spacing, the theoretical sustained admission ceiling is about 3.33 starts/second, or 200/minute, before HTTP latency and worker availability make it slower. This is a process-local pacing policy; it neither tracks a daily budget nor accounts for other processes or other users sharing a key/IP.

#### Returned `requestPage`, lines 212–242

[View part1.js at line 212](<C:/Users/abdul/OneDrive/Documents/GitHub/FDA-Food-Safety-Data-Pipeline/part1.js:212>)

1. **Line 213:** use attempts 0, 1, 2, 3. The `<= maxRetries` condition means four attempts, not three.
2. **Line 214:** each attempt, including retries, must pass the shared gate.
3. **Lines 215–216:** only after admission, create a fresh timeout signal for this attempt. Time spent queued is not deducted from its 30-second request budget.
4. **Lines 217–218:** await `fetchPage`. A successful return immediately exits the retry loop with decoded data and Link information. The response body is read within this operation; the signal is not discarded as soon as response headers arrive.
5. **Line 220:** recognize `TimeoutError`, or an `AbortError` when this attempt's signal has aborted.
6. **Line 221:** if an HTTP status is available, classify it using the status allowlist. Otherwise use timeout/transport classification. A known permanent status does not become retryable just because its signal later expires during cleanup.
7. **Lines 222–225:** cancel an unused error-response body if present, swallow cleanup rejection, then rethrow permanent failures.
8. **Line 226:** choose the larger of local exponential backoff plus jitter and a valid server `Retry-After` delay. With default randomness, backoff begins at 1,000–1,249 ms, then 2,000–2,249 ms, then 4,000–4,249 ms.
9. **Line 227:** record an absolute retry deadline.
10. **Lines 228–230:** for 429 specifically, extend the shared cooldown immediately. Other temporary failures back off only their own worker.
11. **Line 232:** cancel the unused HTTP error body after publishing that cooldown. Body cleanup can be asynchronous, so publishing first prevents queued workers from ignoring a known rate-limit signal while cancellation waits.
12. **Line 233:** select a safe description for logging: status, timeout, or network failure. The URL and API key are not logged.
13. **Lines 234–236:** on attempt 3, throw a contextual exhaustion error with the original error as its `cause`. There is no fifth request and no fourth retry. The delay/cooldown was still calculated first so an exhausted 429 can protect the other workers that are draining.
14. **Line 237:** log the upcoming retry number and minimum wait.
15. **Line 239:** wait outside the admission queue. After this wait, the loop returns to line 214, so the retry must also satisfy current global pacing/cooldown.

**Why retries don't duplicate disk pages:** this loop encloses one network response operation only. Validation and writing happen in `downloadWindow` after the requester returns successfully. A failed attempt does not increment the page number or write a partial API response as a successful page.

**Why safe to retry GET?** Reading the same cursor URL is an idempotent retrieval operation with respect to intentional server-side mutations. This does not mean the live dataset is immutable or that every response is guaranteed byte-for-byte identical.

#### `fetchPage`, lines 245–280

[View part1.js at line 245](<C:/Users/abdul/OneDrive/Documents/GitHub/FDA-Food-Safety-Data-Pipeline/part1.js:245>)

- **Lines 246–250:** call the injected fetch with `Accept: application/json`, the timeout signal, and automatic redirects disabled. This makes exactly one HTTP attempt.
- **Lines 251–257:** most unsuccessful HTTP statuses become an error carrying status, `Retry-After`, and the original response. The requester uses those properties for classification and cleanup. 404 is handled separately because the FDA uses a specific 404 payload for no matches.
- **Lines 259–270:** parse the body as JSON. An actual `SyntaxError` gets an explicit invalid-JSON message. A body timeout or network interruption is rethrown with its own type, so it remains eligible for the right retry policy. Malformed JSON is not treated as a temporary transport error.
- **Line 272:** extract the Link header after reading the body.
- **Lines 273–277:** for the remaining unsuccessful response (404), require exactly `error.code === 'NOT_FOUND'` and `error.message === 'No matches found!'`. Only that recognized payload becomes `noMatches: true`. An arbitrary 404, invalid JSON 404, or unrelated error is not accepted as an empty window.
- **Line 279:** ordinary successful responses return `noMatches: false`, even if their JSON is `null`. A null successful payload later fails `checkPage`; it cannot masquerade as an empty result.

The separation is deliberate: `fetchPage` handles one HTTP/JSON attempt; `requestPage` handles timing and retry policy; `downloadWindow` handles report validity, pagination, and persistence.

### Walkthrough: one complete window

#### `downloadWindow`, setup, lines 282–300

[View part1.js at line 282](<C:/Users/abdul/OneDrive/Documents/GitHub/FDA-Food-Safety-Data-Pipeline/part1.js:282>)

- **Lines 282–290:** accept an options object. The defaults use the fixed bounds, a matching folder beside the script, the built-in fetch, a requester around that fetch, and a private ID set when no shared set is supplied.
- With `downloadAll`, the caller supplies the date window, output folder, **shared** requester, and **shared** run-wide IDs, so the standalone requester/set defaults are not used.
- **Line 291:** validate/build the first URL before creating directories or making a request.
- **Line 293:** ensure the parent folder exists. Recursive creation is appropriate for parents that may legitimately exist.
- **Line 294:** create the actual window folder without recursive mode. If it already exists, fail immediately. This claims fresh output before network access rather than mixing this run with old pages.
- **Lines 296–300:** initialize the set of successfully saved window IDs, the set of already used cursors, unknown total (`null`), saved-report count, and successful-page count.

`null` for unknown total is different from zero reports. Zero is a valid established total for an empty window.

#### `downloadWindow`, iteration, lines 302–350

[View part1.js at line 302](<C:/Users/abdul/OneDrive/Documents/GitHub/FDA-Food-Safety-Data-Pipeline/part1.js:302>)

1. **Line 302:** continue while a URL remains. Continuation is controlled by validated cursor links, not page length or the last record's date.
2. **Line 303:** remember the current decoded `search_after` parameter. The first URL has no cursor, so the set initially contains `null`.
3. **Line 304:** request this page, with a label based on the window and the next successful page number. Retries happen inside this await and retain the same URL/page label.
4. **Line 305:** validate/parse the next Link before saving anything from this response.
5. **Lines 306–308:** if the returned next cursor has already been used, fail rather than loop forever. Comparing parsed parameter values makes URL parameter reordering or equivalent encoding irrelevant to the cursor check.
6. **Lines 310–318:** handle the explicit no-match response. A next link would contradict no matches and is rejected. If no total was ever established, set it to 0. Otherwise retain the previous expected total. End the chain and continue to final reconciliation without writing this error payload as a report page.
7. **Line 320:** validate the successful page's basic contract.
8. **Lines 321–325:** establish the window total on the first page and require it to remain unchanged on later pages. Detectable changes mean this run cannot be confidently reconciled.
9. **Lines 326–328:** reject a page that would push the saved count beyond that total.
10. **Lines 329–331:** reject an empty successful page that claims a continuation. A nonempty short page can still have a next link and must be followed.
11. **Lines 332–339:** check every report against the successfully saved window set and the run-wide reserved set. A repeated ID is an error to investigate, not silently discarded. The local check provides a more specific cross-page error before the global check.
12. **Lines 340–341:** reserve all this page's IDs in the shared set **before awaiting a write**. There is no await between checking and reserving, so another JavaScript worker cannot interleave a conflicting acceptance.
13. **Line 343:** choose the next sequential filename.
14. **Lines 344–345:** stringify the entire response envelope and exclusively create the file using `flag: 'wx'`. The `w` writes; the `x` requires that the file not already exist. This catches a surprise collision even after the fresh-folder check.
15. **Lines 346–348:** only after the write succeeds, mark the IDs as saved within this window and increment report/page counts. Reserved and saved are intentionally distinct states.
16. **Line 350:** move to the validated next URL, including when the page is short or already contains reports at the ending date.

**If a write fails:** global reservations remain, but local saved counts do not advance. The whole run is failing and does not support resume, so removing reservations would add complexity without restoring a valid run. A filesystem error can leave a partial file; the completion marker prevents that output from being analyzed as a successful snapshot.

#### `downloadWindow`, completion, lines 353–357

[View part1.js at line 353](<C:/Users/abdul/OneDrive/Documents/GitHub/FDA-Food-Safety-Data-Pipeline/part1.js:353>)

Require both the number saved and the local unique-ID count to equal the established API total. Then return `{ outputDir, savedCount, total, pageCount, complete: true }`.

These are two complementary kinds of evidence: the cursor chain is exhausted, and observed identities/counts reconcile. Neither substitutes for the other. A missing next link can leave 100 saved out of 250 expected; a full count can still be followed by a contradictory or looping cursor.

A standalone call to `downloadWindow()` returns a completed **window** summary and does not publish a whole-run manifest. `downloadAll()` owns that responsibility.

### Walkthrough: the worker pool and completed manifest

#### `downloadAll`, setup, lines 359–389

[View part1.js at line 359](<C:/Users/abdul/OneDrive/Documents/GitHub/FDA-Food-Safety-Data-Pipeline/part1.js:359>)

- **Lines 359–365:** the default output root is `data` beside `part1.js`; concurrency defaults to three. The requester default is evaluated once for this call and shared with all workers.
- **Line 366:** validate the worker limit before writes.
- **Line 367:** construct the fixed windows.
- **Lines 368–369:** create the parent path if needed, then exclusively claim a fresh root directory. Even an existing empty `data` directory is refused.
- **Lines 371–382:** build the initial manifest: schema version, incomplete status, date bounds, start time, requested page size, configured concurrency, count of windows, and planned windows.
- **Lines 383–384:** write that incomplete manifest before starting workers. Ordinary failure/interruption afterward leaves a clear `complete: false` marker. If even this initial write fails, a missing/malformed manifest still cannot authorize analysis.
- **Line 386:** create the run-wide ID reservation set.
- **Line 387:** allocate one result slot per original window.
- **Line 388:** initialize the shared next-window index.
- **Line 389:** initialize the first-failure marker.

The manifest is a small inventory/contract between stages. It does not embed the report IDs, raw reports, credentials, or absolute local paths. Successful final paths are portable relative filenames.

#### Nested `worker`, lines 391–412

[View part1.js at line 391](<C:/Users/abdul/OneDrive/Documents/GitHub/FDA-Food-Safety-Data-Pipeline/part1.js:391>)

1. **Line 392:** continue only while no failure has been observed and unclaimed windows remain.
2. **Lines 394–395:** claim the current index and increment it synchronously, before the first await. In one JavaScript event loop, another worker cannot interrupt halfway through this synchronous claim.
3. **Line 396:** find the assigned window.
4. **Lines 398–404:** await its entire download and save its summary at the original index. Object spread copies its date fields; subsequent properties provide its output folder, key, shared requester, and shared IDs.
5. **Lines 405–409:** on failure, retain the first failing window/error and stop this worker. Other failures do not overwrite the initial diagnostic.
6. After a successful window, the loop checks `failure` again before claiming another. Already active windows are allowed to finish all their pages; they do not check this flag inside `downloadWindow`.

**This is asynchronous concurrency, not three JavaScript threads.** Network and filesystem waits overlap. Synchronous JavaScript steps such as claiming an index and reserving IDs run without another worker's JavaScript interleaving until an await/yield.

**Why catch inside workers?** The chosen behavior is to let active windows drain and then fail. Worker promises therefore settle normally after recording errors, allowing `Promise.all` to wait for all of them. If those rejections escaped immediately, `Promise.all` would reject on the first one without automatically cancelling the other operations.

#### Pool startup and failure, lines 414–420

[View part1.js at line 414](<C:/Users/abdul/OneDrive/Documents/GitHub/FDA-Food-Safety-Data-Pipeline/part1.js:414>)

- **Line 415:** create `min(limit, windows.length)` worker promises. Calling `worker()` starts each worker immediately up to its first await; constructing the array does not make them run one after another to completion.
- **Line 416:** wait for all workers to finish/drain.
- **Lines 417–420:** if any failed, throw an error that names the failing date window and preserves the original error as a cause. The final success path is skipped, leaving the manifest incomplete.

The statement “stop assigning new windows after failure” means after the shared flag is set/observed. A window already claimed before that moment is active work and can finish. This is not immediate cancellation, and a slow active window or long `Retry-After` can delay the final error report.

#### Final reconciliation and manifest publication, lines 422–448

[View part1.js at line 422](<C:/Users/abdul/OneDrive/Documents/GitHub/FDA-Food-Safety-Data-Pipeline/part1.js:422>)

1. **Lines 422–424:** sum the saved records, expected API totals, and saved page counts from all successful windows. Three separate `reduce` passes are clear and inexpensive over just 24 entries.
2. **Lines 425–427:** require summed saved reports and run-wide unique IDs to equal the expected total.
3. **Line 428:** build the successful run summary.
4. **Lines 429–441:** construct the completed manifest. Later object-spread fields overwrite earlier values, so the summary's `complete: true` replaces the initial `false`. Add completion time, unique count, and per-window counts plus exact page paths generated from each successful page count.
5. **Lines 443–445:** exclusively write `manifest.json.tmp`. An unexpected existing temp file is preserved and causes failure rather than being overwritten.
6. **Line 446:** rename the fully written temporary file over the incomplete manifest. A reader observes the published manifest file rather than an in-place, half-written completed manifest under normal filesystem behavior.
7. **Line 447:** return success only after publication succeeds.

**Precise meaning of completion:** all observed cursor chains ended, every saved page passed the implemented validation, saved totals/IDs reconciled, and the final inventory was published. It does not establish an immutable upstream snapshot, cryptographic file integrity, or full power-loss durability. There are no page checksums, explicit disk flushes, or transaction spanning every page file. The notes explicitly distinguish these limitations (`REVIEW_NOTES.md:477–484`, `615–619`).

If the process stops after writing the temp manifest but before rename, the real `manifest.json` remains incomplete; the temp file alone must not authorize analysis. If publication itself fails, all pages may exist but the run still fails. That is intentional: success includes a reliable handoff to the next stage.

### Walkthrough: the CLI boundary, lines 450–465

[View part1.js at line 450](<C:/Users/abdul/OneDrive/Documents/GitHub/FDA-Food-Safety-Data-Pipeline/part1.js:450>)

- **Line 451:** parse `CONCURRENCY_LIMIT` from the environment. An absent variable arrives as `undefined` and uses the helper's default of three.
- **Line 452:** announce the fixed range and configured maximum requests. If the configured limit exceeds 24, actual worker count is still capped at 24; “up to” does not guarantee exactly the requested number of active requests.
- **Line 453:** call the full downloader with the optional environment API key. The script does not read a credential file itself.
- **Lines 454–455:** print counts and the saved directory only after successful completion/publication.
- **Lines 458–462:** run only when invoked directly, print a clear incomplete-output warning on failure, and set `process.exitCode = 1`. Setting the code allows the event loop to drain naturally rather than immediately killing the process with `process.exit(1)`.
- **Line 465:** export the intended testable helpers and orchestration functions. No `package.json` is required for this CommonJS script because it depends only on Node built-ins and directly runs with Node.

### Concrete traces worth practicing aloud

#### Trace A: ordinary two-page window

Assume the API reports total 150.

1. First request has no cursor and `limit=100`. The script remembers `null` as its initial cursor marker.
2. Page 1 contains IDs 1–100 and a validated cursor `A`. Its total is 150.
3. Validate the page, reserve its IDs globally, save `page-000001.json`, then set saved count to 100.
4. Request cursor `A`. Page 2 contains IDs 101–150, still reports total 150, and has no next link.
5. Save page 2, set saved count to 150, and set `url = null`.
6. The loop ends. Saved count 150 and local unique count 150 both equal total 150, so the window succeeds.

#### Trace B: a full final page followed by the FDA no-match response

Assume total 200 and a server-supplied cursor after page 2.

1. Save two full pages: saved count 200, unique count 200.
2. Follow the supplied next cursor even though the expected total has been reached.
3. Receive the exact FDA no-match 404 without a next link.
4. Preserve total 200, end the chain, and reconcile successfully. Only two report-page files are saved; the error payload is not a third page file.

If the same terminal response appeared after only 100 of 200 expected reports, it would end the chain but **fail** final reconciliation. If it were the first response of a genuinely empty window, the established total becomes zero and the window succeeds with zero page files.

#### Trace C: short page at the upper date

Assume a page contains 40 records dated on the final day and has a valid next cursor. The code saves those 40 and follows the cursor. It does not jump dates, stop because the page is short, or assume there cannot be more reports on the same day. If the next page repeats an ID or the cursor loops, explicit checks fail the window.

#### Trace D: three workers with normal request pacing

Assume each HTTP request takes 800 ms and all three workers are ready.

| Approximate time | What happens |
|---:|---|
| 0 ms | A passes admission and starts fetching |
| 300 ms | B passes admission while A remains in flight |
| 600 ms | C passes admission while A and B remain in flight |
| 800 ms | A receives its page, validates it, and begins saving |
| At least 900 ms | A can begin its next request if saving is complete and no cooldown applies |

This shows why there are two controls. The worker count limits overlap; spacing limits how rapidly requests start. If every response took 10 ms, three workers alone could send requests much faster than this API should receive. If responses are slower, overlapping waits helps use the allowed request rate.

#### Trace E: temporary failure and the same cursor retry

Worker B's first request for cursor `Q` gets HTTP 503. With jitter mocked to zero and no useful `Retry-After`, it waits at least 1,000 ms. A and C can continue through the gate. B then re-enters admission and retries **cursor Q**, with a fresh timeout. If its second attempt succeeds, the caller validates and saves that page exactly once. Attempts 3 and 4 would be preceded by at least 2,000 and 4,000 ms of local backoff respectively. A fourth failure ends B's window.

#### Trace F: global 429 cooldown

At time 1,000 ms, worker A receives `429` with `Retry-After: 5`. Its exponential delay would be roughly one second, but the server's five seconds wins. A immediately publishes cooldown 6,000 ms before error-body cancellation. A worker already asleep waiting for ordinary pacing wakes, rechecks the shared deadline, and waits until at least 6,000 ms. Requests already in flight are not retroactively cancelled. New admissions resume spaced by 300 ms, not all at once.

#### Trace G: why IDs are reserved before `await`

Unsafe design: A checks ID `X` → A awaits disk → B checks `X` before A records it → both write `X`.

Current design: A checks the entire page and adds `X` to shared `runIds` without yielding → A awaits disk → B checks `X`, finds it reserved, and fails. If A's disk write then fails, the run is already incomplete. The reservation is not proof of a successful disk write; the local saved set/count is.

#### Trace H: failure with other windows active

A permanently fails. Its worker sets the shared failure flag. B and C are already inside their windows; they continue their cursor chains and can still retry. When they complete, their worker loops see the failure flag and claim no further windows. `Promise.all` finishes only after they drain, then `downloadAll` throws A's contextual error. No completed manifest is published.

### Complexity and performance without hand-waving

Use `N` for reports, `P` for successfully retrieved report pages, `W` for windows (24 here), `C` for active workers, and `B` for total JSON bytes processed.

- **Date validation and fixed-size settings:** effectively constant time for each fixed-width date/configuration value.
- **Per-page validation:** O(number of reports on the page), with expected constant-time `Set` membership. It is bounded by 100 reports per valid response, plus parsing/serialization proportional to page bytes.
- **Run CPU work:** expected O(N + B + P + W). Parsing and writing full records are unavoidable because every report must be retained. Claims of O(1) overall are incorrect merely because pages are small.
- **Network requests:** approximately the sum of `ceil(windowReports / 100)` across nonempty windows, plus empty/terminal no-match requests and retries. Window partitioning can add partially filled pages compared with one large query. The completed snapshot records 987 saved page files; that count alone is not proof of exactly 987 HTTP attempts.
- **Memory:** O(N) identifiers for the global set, plus saved-ID sets for currently active windows, cursor history for active windows, and approximately C page payloads/in-flight operations. The entire raw dataset is not retained in memory at once, but the global identity audit means the downloader is **not constant-memory streaming**.
- **Manifest size:** O(P + W) filenames/count metadata, rather than O(N) report contents.
- **Disk:** O(B) for retained raw JSON, plus the comparatively small manifest.
- **Elapsed time:** constrained by both HTTP latency/concurrency and shared admission spacing. Even infinitely many workers cannot defeat the 300 ms spacing. More workers eventually stop helping and can increase pressure on the source.

For roughly 987 requests with no extra attempts, spacing alone implies about `(987 - 1) × 0.3 = 295.8` seconds between the first and last request starts. The current manifest records a start of **2026-09-04T18:24:34.942Z** and completion of **2026-09-04T18:29:41.824Z**, an elapsed **306.882 seconds**, consistent with pacing being a major factor. Treat the spacing comparison as an explanatory approximation: page files are not an exact request log, and filesystem/latency work adds time. The review notes contain conflicting 22:24/22:29 UTC timestamps; use the current manifest's timestamps when describing this committed snapshot.

For the last-window case, one remaining worker has approximate steady-state throughput bounded by `1 / max(0.3 seconds, per-page network/validation/write time)` when there are no retries. With multiple active workers, overlapping I/O can raise aggregate throughput toward the shared cap of about 3.33 starts/second. A lone worker cannot overlap its own cursor requests; however, if each page finishes in less than 300 ms, the pacing cap already dominates and extra workers or smaller windows have little room to improve throughput. This distinction makes the deferred load-balancing decision measurable rather than speculative.

### What was required, chosen, and inferred

| Item | Evidence category | Defensible explanation |
|---|---|---|
| Node.js for Part 1 | Exact assignment requirement in shared conversation | Use the required runtime; built-in APIs keep the implementation dependency-free |
| Inclusive fixed range and `limit=100` | Recorded scope/requirements | Honor the supplied retrieval bounds and page-size requirement |
| Raw JSON committed under `data` | Confirmed scope in notes | Deliver a local reusable snapshot for review and analysis |
| 24 year-based partitions | Explicit implementation choice | Supply independent cursor chains and easy-to-audit boundaries |
| Configurable `CONCURRENCY_LIMIT`, default 3 | Exact assignment requirement in shared conversation | Respect the required default and expose the required configuration; the worker-pool design implements that contract |
| Shared queue, with finer splitting deferred | Documented discussion and deferral in shared conversation | Let free workers claim unstarted years while acknowledging that the last large window can still dominate |
| 300 ms start spacing | Explicit implementation choice | Control request frequency independently from concurrency |
| Three retries, 30-second per-attempt timeout | Documented implementation policy | Recover from recognized temporary failures while preventing endless attempts |
| Strict IDs/date/count validation | Documented decision | Detect contradictory or incomplete data instead of silently suppressing it |
| Retain full JSON response envelopes | Documented decision | Keep raw source values for later analysis and inspection |
| Manifest with initial incomplete marker | Documented implementation choice | Give the analysis stage an explicit completion contract |
| No resume or overwrite | Documented scope decision | Prevent mixed runs while keeping the implementation understandable |
| Standard-library-only JavaScript | Documented decision | The required HTTP, timing, filesystem, and testability capabilities already exist in Node |
| Why not a queue service/database/framework | Inference, not a recorded rejected proposal | For a one-off fixed-range local exercise, those would add deployment/state complexity beyond the demonstrated needs |

Do not claim a personal thought process that the notes never recorded. A good phrasing for the final row is: “Looking at the scope, I would defend the simpler local approach because ...” rather than “I evaluated and rejected three queue products” if that did not happen.

### How the implementation evolved, backed by commits and notes

| Step | What changed | Why this sequence is defensible |
|---|---|---|
| `93d4545` — first-page ingestion | Valid query, basic envelope/report checks, timeout, exclusive JSON save, importable functions | Establish a small end-to-end path before combining paging and concurrency |
| `5bc501b` — complete one window | Follow validated cursors, recognize terminal no-match response, detect duplicates/changed totals, reconcile completion | Prove one sequential chain before adding parallel chains |
| `ee093ce` — concurrent ingestion | 24 windows, configurable worker pool, ordered summaries, first-failure/drain behavior | Add concurrency around the already defined window operation |
| `e24ce99` — resilient ingestion and snapshot | Retry/pacing behavior, shared identity audit, completion manifest, downloaded dataset | Add failure-handling/completion evidence before expensive ingestion |
| `dc44199` — analysis/visualization and final audit | Add final analysis deliverables; Part 1 also adds HTTP 408 retry handling | Close the full pipeline and fix an identified retry-policy omission |

`REVIEW_NOTES.md` records finer-grained slices than the commit history, so a slice and a commit are not always one-to-one. Its beginning is explicitly an older first-page checkpoint. Historical phrases such as “no retries yet,” “no live request yet,” “README unchanged,” and the last audit's “working-tree changes” must not be read as current status: the final code includes those features and HEAD commits the finished implementation.

The notes also record a useful debugging story: a concurrency test asserted exactly three overlapping requests after only one event-loop yield, sometimes observing two instead. The fix was a shared promise barrier that held the first three mock requests until all arrived. That fixed an uncontrolled timing assumption in the test, not a production scheduling bug (`REVIEW_NOTES.md:400–415`).

### Material limitations to own in a review

1. **No immutable source snapshot:** totals and unique IDs detect several failure modes, but a live upstream update that preserves counts and avoids duplicates may escape detection. The committed output is a fixed local snapshot from its recorded run, not a guarantee about FDA data today.
2. **No resume:** output directories must be fresh. A failed run preserves artifacts for inspection and requires a new clean destination for another run. Adding resume requires defining how to verify prior files, recover cursors, restore ID state, and handle source changes.
3. **No post-download hashes or durable transaction:** final manifest replacement publishes completion cleanly, but later same-count edits may not be detected and there is no explicit power-loss durability guarantee.
4. **Global O(N) identifier memory:** acceptable for about 98,000 reports; a much larger dataset may justify a disk-backed uniqueness index or database constraint.
5. **Process-local request policy:** pacing does not coordinate with multiple processes or enforce daily quotas. A server rate-limit response remains possible.
6. **No global run deadline or immediate cancellation:** attempts are bounded, but server delays and drain-on-failure can make elapsed time long.
7. **Fixed partitioner and strict API assumptions:** the dates, page policy, endpoint, no-match payload, and next-link rules intentionally match the documented contract. Generalizing requires tests and explicit decisions.
8. **Validation is scoped:** ingestion checks identity/date/envelope/completeness, while Python checks analysis structure and cleans ages/terms. Neither stage proves reports are medically accurate or establishes causal relationships.

Reasonable production follow-ups would be checkpoint/resume design, persisted uniqueness constraints, file hashes, structured request/progress metrics, an overall deadline/cancellation policy, quota coordination across instances, and immutable/versioned dataset handling where the source supports it. Present these as prioritized future work, not features already implemented.

### Oral questions this walkthrough should make answerable

- “What happens from `node part1.js` to the first network call?” — Explain the CLI guard, configuration validation, fresh root, incomplete marker, worker claim, fresh window folder, and shared request gate in that order.
- “Are three workers the same as three requests per second?” — No. Concurrency limits simultaneous work; 300 ms pacing limits request-start frequency.
- “Why not fetch all pages in `Promise.all`?” — The next cursor is only known after receiving the prior response. Parallelism comes from independent date windows, not guessed continuation positions.
- “What if one worker has the largest remaining year?” — The shared queue prevents idle workers while unstarted windows remain, but it cannot split the last active cursor chain. Finer partitions were discussed and deferred; measure against the shared pacing cap before increasing complexity.
- “Why isn't the fetch inside the promise queue?” — That queue serializes admission only; including fetch would serialize HTTP work and defeat overlap.
- “What happens if a retry fails four times?” — Four attempts total, no fifth. The worker records failure, active windows drain, and the completed manifest is never published.
- “Why does a 404 sometimes mean success?” — Only the exact FDA no-match payload without a continuation can terminate a chain, and final saved/unique counts must still match the established total.
- “Could a short page have another page?” — The code allows that and follows the supplied cursor. Page length is not its termination condition.
- “Why reserve IDs before the write?” — Checking before await but recording after await lets another worker accept the same ID during disk I/O. Synchronous reservation closes that gap within this process.
- “Why keep both window and global ID sets?” — Window sets represent successful saves and support per-window reconciliation/context; the global set prevents duplicates across active windows before writes yield.
- “What does `complete: true` really prove?” — Completion of the observed chain/validation/count contract and successful publication, not immutable upstream truth, checksummed storage, or crash-proof transactions.
- “Why can every JSON page exist but the run still fail?” — Publishing the final manifest is part of the success contract. If it fails, Python must not assume the directory is ready.
- “What is the memory complexity?” — O(N) because of run-wide identifiers, even though raw report data is processed one page per active worker.
- “How would you prove concurrency in a test?” — Hold the first C mocked requests behind a barrier until all arrive; check the overlap/cap at each start; then release them under a bounded test timeout.
- “What would you change first for a recurring production pipeline?” — Start with explicit resume/checkpoint and source-version semantics, then persisted identity/hash verification and operational metrics; choose priorities from failure cost, scale, and freshness requirements.


## 1.8 Part 2: the analyzer, almost line by line

This walkthrough describes the current 512-line `part2.py`, inspected on September 6, 2026. Source ranges refer to that version. It explains the code that exists; proposed improvements are explicitly identified. The historical rationale comes from `REVIEW_NOTES.md`, especially lines 275–309 and 638–967, rather than from invented personal recollections.

### The story to tell before opening the file

> “Part 1 produces the raw snapshot and its completion manifest. Part 2 treats that manifest as the inventory, validates the entire listed dataset, selects reports by year and optional suspect-product text, and creates one row per report. From that common table I calculate report-level term frequencies, valid-age averages, and two plots. I keep filtering separate from normalization so the requested literal search behavior does not silently change. I also preserve the raw report alongside the derived fields so the transformations are traceable.”

This is an offline analysis program. `part2.py` does not import an HTTP client, read an API key, contact FDA, update the snapshot, or derive “present” from today's date. Its default data and chart paths are anchored to the script's directory.

#### The central invariant

**One DataFrame row means one selected adverse-event report, not one product, reaction, or unique person.** A report can have several suspect products and reactions. Those nested lists are flattened separately only when counting terms. The report total and age calculations therefore do not multiply a person's recorded age by the number of attached products.

There are two distinct kinds of deduplication:

| Operation | Where | Behavior and reason |
|---|---|---|
| Report identity validation | `loadReports`, lines 239–255 | A repeated `report_number` is a fatal data error, rather than silently discarded. Silent deduplication would conceal an ingestion or snapshot problem. |
| Term deduplication within a report | `normalizeTerms`, lines 337–340 | Equivalent labels collapse to one contribution per term per report, as required by the counting policy. |

Deduplicating report IDs does **not** prove reports describe different people or different real-world incidents. This is a report dataset.

### End-to-end control flow and data shapes

```text
Command line
    ↓
runCli → main
    ↓
parseArgs → {startYear, endYear, productFilter}
    ↓
loadReports
    ├─ loadManifest → validated completion metadata and page inventory
    └─ read listed pages → validate every report → list of raw report dictionaries
    ↓
selectReports → [{report: original dictionary, suspectProducts: eligible raw names}]
    ↓
makeDataFrame → one row per report, normalized lists + year + ageYears + gender
    ↓
saveChart → buildChart → annual counts + valid-age histogram → PNG
    ↓
printSummary → total + Top 25 lists + age means
    ↓
print chart path → return DataFrame → exit 0
```

Saving the image happens **before** printing the success summary. If the required image cannot be written, the command reports an error instead of first printing an apparently complete result.

The shapes are worth recognizing on sight:

```python
# parseArgs output
{"startYear": 2024, "endYear": 2026, "productFilter": "CARROTS"}

# One selected item, before normalization
{
    "report": original_report_dictionary,
    "suspectProducts": ["Organic Baby Carrots", "ORGANIC BABY CARROTS!"]
}

# One DataFrame row, after normalization
{
    "report": original_report_dictionary,
    "suspectProducts": ["ORGANIC BABY CARROTS"],
    "outcomes": ["OTHER OUTCOME"],
    "reactions": ["NAUSEA", "RASH"],
    "year": 2024,
    "ageYears": 40.0,
    "gender": "Female"
}

# getTopTerms output
[("NAUSEA", 3), ("RASH", 2)]
```

The original report is retained by reference, not deep-copied. New lists hold derived, normalized terms. `selectReports` and `makeDataFrame` do not rewrite the original FDA fields or the JSON files.

### Imports, constants, and exceptions: lines 1–55

[View part2.py at line 1](<C:/Users/abdul/OneDrive/Documents/GitHub/FDA-Food-Safety-Data-Pipeline/part2.py:1>)

| Lines | What executes | Why it is present |
|---|---|---|
| 1–6 | Import JSON, regular expressions, CLI access, Unicode normalization, date arithmetic, and filesystem paths. | Standard-library responsibilities do not need extra packages. |
| 8–11 | Import Matplotlib, NumPy, pandas, and `MaxNLocator`. | pandas holds the report table and counts; NumPy validates/calculates ages and defines bins; Matplotlib renders the required image. The historical notes say these libraries were assignment requirements, not arbitrary additions. |
| 14–15 | Select Matplotlib's `Agg` backend **before** importing `pyplot`. | `Agg` renders images without opening a desktop window, so the CLI works in unattended or headless environments. |
| 18–21 | Set exact source dates `20020101` through `20260101`, and selectable years 2002 through 2026. | The endpoint is fixed by the assignment. 2026 contains only January 1, not a full year. |
| 22 | Set `maxAge = 125`. | A project plausibility rule applied after unit conversion; it is not an FDA schema rule. |
| 23–24 | Resolve the directory containing the script and append `data` / `charts`. | Launching from another working directory still finds the same dataset and writes beside the script. |
| 25–26 | Precompile the four-digit year pattern and define CLI usage text. | An exact four-digit token is a year; other tokens form the product phrase. |
| 27–33 | Define unit-to-years factors. | A table avoids repeated branches and puts the supported units in one place. |
| 34–36 | Precompile general punctuation, whitespace, and raw hyphenated vitamin patterns. | Reuse expressions across many terms; preserve the meaningful source hyphen before general cleanup removes it. |
| 37–43 | Define four narrow product alias rules. | Make the aggregation policy visible and deterministic. These are applied only to product names. |
| 46–55 | Define `Part2Error`, `UsageError`, and `DataError`. | Separate bad arguments from unusable input/output, allowing distinct exit codes and readable errors. The base class groups project errors conceptually. |

`Path.is_relative_to`, used later, is one reason the README requires Python 3.9 or newer. `requirements.txt` specifies compatible version ranges, not a fully locked environment. A fresh install can resolve different library versions within those ranges.

### Argument parsing: `parseArgs`, lines 58–81

[View part2.py at line 58](<C:/Users/abdul/OneDrive/Documents/GitHub/FDA-Food-Safety-Data-Pipeline/part2.py:58>)

1. **59–60:** Create separate lists for years and product words.
2. **63–66:** Iterate over argument strings, strip their outer whitespace, and reject an empty argument. Shell quoting matters: an explicitly quoted whitespace-only argument arrives as a value and fails here.
3. **67–70:** If the whole argument matches exactly four digits, convert it to an integer and append it to `years`; otherwise append it to `productWords`.
4. **72–75:** Reject more than two year arguments or any year outside 2002–2026.
5. **77–79:** Sort years. No years means 2002–2026; one year means that year–2026; two years mean the inclusive sorted range.
6. **80–81:** Join non-year arguments with one space, or use `None` if there are none; return a small filter dictionary.

| Arguments | Result |
|---|---|
| No arguments | 2002–2026; no product filter |
| `2024` | 2024–2026; **not just 2024** |
| `2024 2024` | 2024 only |
| `CARROTS 2026 2024` | 2024–2026; product phrase `CARROTS` |
| `2024 baby carrots` | 2024–2026; phrase `baby carrots` |
| `"Vitamin D3 2000 IU"` | Whole quoted phrase is a product filter, because the whole argument is not four digits |
| `Vitamin D3 2000 IU` | `2000` is interpreted as an out-of-range year and fails |
| `2024 2025 2026` | Usage error: more than two years |
| `2027` | Usage error: out-of-range year |

Product word order remains significant. Argument order is flexible around years, but `baby carrots` and `carrots baby` are different phrases. There is no flag parser, regular-expression search, OR between product words, or automatic singular/plural expansion. `--help` is currently just a product-search token, not a help option.

**Defensible rationale:** follow the requested positional interface simply and predictably. **Improvement if the interface grows:** explicit `--start-year`, `--end-year`, and `--product` flags would remove numeric-name ambiguity. Do not claim this exists today.

### Small validation helpers: lines 84–132

[View part2.py at line 84](<C:/Users/abdul/OneDrive/Documents/GitHub/FDA-Food-Safety-Data-Pipeline/part2.py:84>)

#### `readJson`, lines 84–96

[View part2.py at line 84](<C:/Users/abdul/OneDrive/Documents/GitHub/FDA-Food-Safety-Data-Pipeline/part2.py:84>)

- **85–87:** Open a supplied `Path` as UTF-8 within a context manager, then parse the entire JSON document. The context manager closes the file on success or failure.
- **88–89:** A missing file becomes a contextual `DataError` naming what was missing and its path.
- **90–92:** Invalid JSON becomes a `DataError` with the parser's line and column.
- **93–94:** Invalid encoding becomes a UTF-8 error.
- **95–96:** Other filesystem errors become a readable read failure.

`raise ... from error` preserves the underlying cause for debugging, although the CLI prints only the friendly message. This does not mean all possible exceptions in Python are swallowed: only the listed exception categories are converted.

#### `checkDate`, lines 99–106

[View part2.py at line 99](<C:/Users/abdul/OneDrive/Documents/GitHub/FDA-Food-Safety-Data-Pipeline/part2.py:99>)

- Require a string of eight digits.
- Parse it with `%Y%m%d` to reject impossible calendar dates such as February 30.
- Return the original, validated string.

Once the format is validated, comparing these date strings lexicographically gives chronological order because the components run from most significant to least significant: year, month, day. Format-only regex validation would not catch impossible dates.

#### `checkCount`, lines 109–112

[View part2.py at line 109](<C:/Users/abdul/OneDrive/Documents/GitHub/FDA-Food-Safety-Data-Pipeline/part2.py:109>)

Require an actual Python integer and a nonnegative value. `type(value) is int` intentionally rejects booleans: Python treats `bool` as a subclass of `int`, so `isinstance(True, int)` would otherwise accept `True` as a count. Return the validated count.

#### `checkTerms`, lines 115–121

[View part2.py at line 115](<C:/Users/abdul/OneDrive/Documents/GitHub/FDA-Food-Safety-Data-Pipeline/part2.py:115>)

Require a list, then require every item to be a nonblank string. Labels use one-based indexes for human-readable errors. An empty list is valid: it means no supplied terms, not a broken field. This helper validates the raw terms without changing their spelling.

#### `getPagePath`, lines 124–132

[View part2.py at line 124](<C:/Users/abdul/OneDrive/Documents/GitHub/FDA-Food-Safety-Data-Pipeline/part2.py:124>)

- **125–126:** Reject a missing, nonstring, or empty page path.
- **128–129:** Resolve the data root and the supplied relative path to actual absolute paths.
- **130–131:** Reject the root itself and any result outside the data directory.
- **132:** Return the safe path.

This prevents a manifest entry such as `../some-other-file.json` from directing analysis outside its dataset. Resolving before comparison also handles path normalization and existing symlinks. It is a containment check on a local manifest, not a claim that all filesystem races are eliminated.

### Manifest validation: `loadManifest`, lines 135–203

[View part2.py at line 135](<C:/Users/abdul/OneDrive/Documents/GitHub/FDA-Food-Safety-Data-Pipeline/part2.py:135>)

This is the contract between acquisition and analysis. A `complete: true` boolean alone is insufficient; the loader checks that the manifest is internally coherent.

| Lines | Validation |
|---|---|
| 136–139 | Convert the root to a `Path`, load `manifest.json`, and require a JSON object. |
| 140–143 | Require integer schema version 1 and literal boolean `true` completion. |
| 144–147 | Require the exact assignment date range and page limit 100. |
| 149–153 | Require a nonempty windows array, and reconcile its length with `windowCount`. |
| 155–159 | Initialize the set of listed resolved paths, aggregate report/page counts, expected first date, and last end date. |
| 160–167 | For every window, require an object, validate both dates, and enforce ordered start/end within the fixed assignment bounds. |
| 168–171 | Require the current start to equal the expected next date. Advance that expectation to one calendar day after this window's end. |
| 173–181 | Validate window saved/total counts, require a files list, reconcile its length with `pageCount`, and require saved reports to equal the API-observed total. |
| 183–187 | Resolve each path safely and reject any path listed more than once, including across windows. |
| 189–190 | Add window saved reports and listed pages to the run totals. |
| 192–193 | Require the final window to end on January 1, 2026. |
| 195–202 | Validate run-level saved/total/unique/page counts and reconcile them against the summed windows. |
| 203 | Return the manifest only after all checks pass. |

The central equalities are:

```text
For every window:
    window.savedCount = window.total
    window.pageCount = len(window.files)

For the run:
    sum(window.savedCount) = manifest.savedCount = manifest.total = manifest.uniqueCount
    sum(len(window.files)) = manifest.pageCount
    len(windows) = manifest.windowCount
```

**How date coverage is proved:** the first start must be January 1, 2002; each subsequent start must be exactly the day after the preceding end; every window is internally valid and inside bounds; the last end must be January 1, 2026. That rules out gaps, overlaps, reordering, and truncated coverage. It does **not** require yearly windows or exactly 24 windows. Part 1 currently produces 24, but Part 2 accepts any valid contiguous partition of the fixed range.

**What this does not prove:** that the API provided an immutable point-in-time snapshot, that counts alone detect every later edit, or that the manifest is cryptographically authenticated. The manifest carries filenames and counts, not content hashes. Later record loading supplies additional checks.

The program ignores files absent from the manifest. This is deliberate: the completion inventory decides what belongs to this snapshot, so an unrelated temporary JSON file does not become input just because a directory glob finds it.

### Report and page loading: lines 206–264

[View part2.py at line 206](<C:/Users/abdul/OneDrive/Documents/GitHub/FDA-Food-Safety-Data-Pipeline/part2.py:206>)

#### `checkReport`, lines 206–232

[View part2.py at line 206](<C:/Users/abdul/OneDrive/Documents/GitHub/FDA-Food-Safety-Data-Pipeline/part2.py:206>)

1. **207–212:** Require a report object and a nonblank string `report_number`.
2. **214–216:** Validate `date_started` as a calendar date and require it to lie inside the manifest window whose file contains it.
3. **218–227:** Require a products list. Every product must be an object with nonblank string `role` and `name_brand` fields.
4. **228–229:** Require outcomes and reactions to be valid lists of strings via `checkTerms`.
5. **230–232:** Require `consumer` to be an object, then return the report ID.

This is structural validation for the analysis fields. It does not validate every FDA field or reject unknown extra fields. Empty product, outcome, and reaction lists are allowed. A product role must be nonblank, but this function does not enforce an enum; the later filter selects only exact `SUSPECT` roles.

A missing `consumer` object is fatal. An existing consumer object with no age or gender is valid. That distinction separates a broken expected structure from missing optional data.

The ID's whitespace is checked for nonblankness but is not removed from the stored or returned ID. Uniqueness therefore concerns exact source identifier strings, not a newly normalized identifier scheme.

#### `loadReports`, lines 235–264

[View part2.py at line 235](<C:/Users/abdul/OneDrive/Documents/GitHub/FDA-Food-Safety-Data-Pipeline/part2.py:235>)

- **236–239:** Validate the manifest, allocate a report list, and allocate a run-wide set of IDs.
- **242–248:** Visit each manifest window and each listed page; resolve/read it; require an object containing a `results` list.
- **250–256:** Validate each report, reject a duplicate ID, then add the ID and append the original report dictionary.
- **257–260:** Sum loaded records in each window and compare that count with the window's saved count.
- **262–264:** Reconcile all loaded reports and unique IDs with the manifest, then return the list.

**Execution order matters:** all listed records are validated before any year or product filter is applied. A malformed report in 2005 fails a 2024-only analysis as well. The output is defined as a query over a valid complete snapshot, rather than a query that can conceal corruption outside its filter.

This loader intentionally does not replay ingestion. It does not follow cursors, validate HTTP responses, demand a maximum of 100 entries per page, or compare each page's metadata to its window. Part 1 and the independent download validator covered those ingestion properties; Part 2 checks the boundary it needs: expected structures, report identity/date membership, inventory, and reconciliation.

It loads all report dictionaries into memory. That is straightforward for the committed snapshot; it is not a streaming implementation for arbitrarily large datasets.

### Report selection: lines 267–287

[View part2.py at line 267](<C:/Users/abdul/OneDrive/Documents/GitHub/FDA-Food-Safety-Data-Pipeline/part2.py:267>)

#### `getSuspectProducts`, lines 267–273

[View part2.py at line 267](<C:/Users/abdul/OneDrive/Documents/GitHub/FDA-Food-Safety-Data-Pipeline/part2.py:267>)

- **268–269:** Collect `name_brand` only where `role == "SUSPECT"`. This role comparison is exact and case-sensitive because it uses the FDA's supplied role value.
- **270–271:** Without a product filter, return all such names.
- **272–273:** Casefold the search phrase and each candidate name, then use Python's literal substring operator `in`.

`casefold` is a Unicode-aware form of case-insensitive text comparison. This is **not** a regex, so a search such as `A+B` means the literal three-character phrase. The function does not strip internal spaces, normalize punctuation, apply aliases, or fuzzy-match names during selection.

#### `selectReports`, lines 276–287

[View part2.py at line 276](<C:/Users/abdul/OneDrive/Documents/GitHub/FDA-Food-Safety-Data-Pipeline/part2.py:276>)

1. **277–281:** Allocate the result list, derive the year from each validated source date, and skip reports outside the inclusive selected interval.
2. **284:** Get eligible suspect names for that report and optional filter.
3. **285–286:** Without a product filter, keep every report in the selected year range, including a report with no suspect names. With a product filter, keep it only when at least one matching suspect name exists.
4. **286–287:** Append one wrapper containing the unchanged report and eligible names; return the selected list.

The `or` condition short-circuits, but `getSuspectProducts` has already run on the preceding line. Multiple matching products do not create multiple selected rows. Outcomes, reactions, and age remain report-level information from the entire selected report; the code does not attribute an individual reaction causally to the matching product.

**Documented rationale:** Alex explicitly preferred ranking only matching suspect products once a product filter is active (`REVIEW_NOTES.md:285–308`). That superseded an earlier plan to rank all suspect products from selected reports.

### Age and gender hygiene: lines 290–317

[View part2.py at line 290](<C:/Users/abdul/OneDrive/Documents/GitHub/FDA-Food-Safety-Data-Pipeline/part2.py:290>)

#### `ageInYears`, lines 290–309

[View part2.py at line 290](<C:/Users/abdul/OneDrive/Documents/GitHub/FDA-Food-Safety-Data-Pipeline/part2.py:290>)

1. **291–297:** Return `None` if the consumer is not an object, age is absent/null, age is a boolean, or unit is not a string. The caller normally already validated the object, but the helper is independently defensive.
2. **299–302:** Convert the age to `float`; malformed strings/types become `None` for the exceptions caught here.
3. **304–306:** Normalize unit text with `strip().casefold()`, look up the factor, and reject unsupported units or non-finite numeric values.
4. **308–309:** Convert to years and return the result only if it falls inside the inclusive interval 0–125; otherwise return `None`.

| Source unit | Factor | Example |
|---|---:|---|
| `year(s)` | 1 | 40 years → 40.0 |
| `month(s)` | 1/12 | 6 months → 0.5 |
| `week(s)` | 7/365.25 | 52 weeks → approximately 0.9966 |
| `day(s)` | 1/365.25 | 365 days → approximately 0.9993 |
| `decade(s)` | 10 | 3 decades → 30.0 |

The bound is applied **after** conversion. A raw age of 365 days is plausible, while 68 decades means 680 years and is rejected. Do not silently “correct” 68 decades to 68 years: that would invent a replacement value unsupported by the source.

Zero is valid, including newborn reports. Fractional values remain fractional for averages and the histogram. Months and years vary in length, so the sub-year conversions are approximate conventions, not exact birth-date calculations.

Returning `None` excludes the age from age calculations, **not the report from other statistics**. The notes document that 125 was chosen to retain an observed 122.75-year value and exclude the observed 680-year error. It is a transparent project rule that would deserve a reviewed data-quality policy in a larger system.

**Review-discovered edge case:** `float(10**400)` raises `OverflowError`, which the `except (TypeError, ValueError)` block does not catch. A focused execution check of this exact function, extracted unchanged from the source's syntax tree, confirmed that failure before the finite-value check. A sufficiently huge integer in an age field can therefore escape the graceful invalid-age path and reach an unhandled CLI exception. No such age occurs in the committed snapshot. This is a candidate small hardening fix; reproducing it independently does not constitute a fresh run of the full Python test suite.

#### `getGender`, lines 312–317

[View part2.py at line 312](<C:/Users/abdul/OneDrive/Documents/GitHub/FDA-Food-Safety-Data-Pipeline/part2.py:312>)

Read the optional gender field. Nonstring values return `None`; strings are trimmed and casefolded. Only `female` and `male` map to the output labels `Female` and `Male`. Everything else maps to `None`.

The nested conditional expression returns one value; it does not run two separate calculations. Unknown gender can still have a valid age, which later contributes to the overall mean but neither named group. This is normalization of the source field for the requested grouped calculation, not an inference about the consumer's identity.

### Normalization and aliases: lines 320–340

[View part2.py at line 320](<C:/Users/abdul/OneDrive/Documents/GitHub/FDA-Food-Safety-Data-Pipeline/part2.py:320>)

#### `normalizeTerm`, lines 320–334

[View part2.py at line 320](<C:/Users/abdul/OneDrive/Documents/GitHub/FDA-Food-Safety-Data-Pipeline/part2.py:320>)

Order is essential:

1. **321:** Apply Unicode NFKC normalization, then uppercase. NFKC converts compatible presentation forms, such as full-width Latin characters, to a common representation; uppercase handles case differences. It does not perform semantic translation or necessarily remove accents.
2. **322–323:** For products only, replace raw hyphenated Vitamin D2/D3 spellings before punctuation removal destroys the evidence of the hyphen.
3. **324:** Turn ampersands into `AND` and plus signs into `PLUS`, with spaces.
4. **325–326:** Remove several straight/curly apostrophes, a backtick, and the observed `U+0092` apostrophe character. `WOMEN’S` becomes `WOMENS`, rather than `WOMEN S`.
5. **327:** Replace underscores with spaces, then replace sequences outside Unicode word characters and `%` with a space. Percent signs survive to distinguish concentrations.
6. **328:** Collapse repeated whitespace and trim.
7. **330–333:** For products only, apply the ordered alias table, then collapse whitespace again.
8. **334:** Return the normalized string.

The aliases are whole-word-bounded patterns:

| Pattern family | Output / limitation |
|---|---|
| `Vitamin D2`, `Vitamin D3`, `Vit D2`, `Vit D3`, plus recognized source-hyphen forms | `VITAMIN D`; surrounding brand/dosage words remain |
| `Vit D` | `VITAMIN D` |
| `NatureMade` | `NATURE MADE` |
| `Softgel`, `Softgels`, `Soft Gel`, `Soft Gels` | `SOFT GEL` |

Examples:

```text
"  Café_Women’s 50+ & A/B  " → "CAFÉ WOMENS 50 PLUS AND A B"
"2% milk"                  → "2% MILK"
"Vitamin-D-3"              → "VITAMIN D"
"Vitamin D 3 MCG"          → "VITAMIN D 3 MCG"
"Vitamin D 3000 IU"        → "VITAMIN D 3000 IU"
"D3 SPORTS"                → "D3 SPORTS"
"NatureMade D3 Softgels"    → "NATURE MADE D3 SOFT GEL"
```

`D3` alone is not treated as a vitamin. A separate number after D is not automatically consumed as a vitamin version, which protects `Vitamin D 3 MCG`. Product aliases do not apply to reaction or outcome fields. `ABDOMINAL PAIN` and `ABDOMINAL PAIN UPPER` remain different, as do different cancer stages and different product formulations.

**Rationale:** the notes document Alex's acceptance of consistent cleanup plus a small inspected mapping. Explainable mappings avoid the unsupported merges that edit-distance or a language model might introduce. Vitamin D2 and D3 are grouped as an **assignment reporting family**, not declared chemically identical.

**Limitations to acknowledge:** deterministic does not mean semantically perfect. Generic punctuation cleanup can merge distinct strings: for example `2.5` and `2-5` both become `2 5`. The code does not remove all numeric content, but it also does not promise to preserve every dosage distinction. Broader use should audit collisions and introduce field-specific numeric-token preservation or a versioned mapping review process. Do not defend the current heuristic as universal clinical entity resolution.

#### `normalizeTerms`, lines 337–340

[View part2.py at line 337](<C:/Users/abdul/OneDrive/Documents/GitHub/FDA-Food-Safety-Data-Pipeline/part2.py:337>)

- Normalize all values into a set.
- Because deduplication occurs **after** normalization, `Rash`, `RASH`, and `rash!` become one `RASH` in that report.
- Remove empty normalized strings; a raw nonempty string of punctuation can normalize to nothing.
- Sort remaining terms for deterministic lists.

Deduplication before normalization alone would leave different source spellings that later collapse to the same term, producing duplicate report contributions when flattened.

`EXEMPTION 4` is retained. The notes explicitly chose to keep this supplied placeholder because removing the most frequent suspect name without an exclusion rule would change the assignment's counts. Its presence does not make it an identifiable product.

### The report table and age calculations: lines 343–381

[View part2.py at line 343](<C:/Users/abdul/OneDrive/Documents/GitHub/FDA-Food-Safety-Data-Pipeline/part2.py:343>)

#### `makeDataFrame`, lines 343–357

[View part2.py at line 343](<C:/Users/abdul/OneDrive/Documents/GitHub/FDA-Food-Safety-Data-Pipeline/part2.py:343>)

- **344–345:** Define the seven columns explicitly and create a rows list.
- **346–349:** Iterate over selected report wrappers, retaining the raw report reference.
- **350–352:** Normalize/deduplicate eligible suspect names, outcomes, and reactions into three separate list-valued cells.
- **353–355:** Derive year, converted age, and normalized gender once per report.
- **357:** Build the pandas DataFrame with the specified columns.

Supplying columns explicitly is important for an empty selection: later operations can still access `ageYears`, `year`, and term columns instead of raising missing-column errors. Missing ages generally appear as pandas missing values, and the later helper excludes them.

The lists inside DataFrame cells are intentional. Exploding the whole table early would multiply ages; exploding multiple columns together may also demand matching list lengths, while sequential explosions can create a Cartesian product. This code avoids both by keeping the row grain at report level and exploding one term series on demand.

#### `getValidAges`, lines 360–364

[View part2.py at line 360](<C:/Users/abdul/OneDrive/Documents/GitHub/FDA-Food-Safety-Data-Pipeline/part2.py:360>)

Select all `ageYears`, or rows whose normalized gender matches the requested label. Drop pandas missing values, convert to a float NumPy array, then retain only finite numbers. Both averages and the histogram use this exact helper, so they share the same population.

The finite check here is defensive duplication of the earlier age conversion check. It protects the aggregation helper if it receives a separately built DataFrame containing `NaN` or infinity.

#### `getAgeAverage`, lines 367–369

[View part2.py at line 367](<C:/Users/abdul/OneDrive/Documents/GitHub/FDA-Food-Safety-Data-Pipeline/part2.py:367>)

Get the valid-age array. If it is nonempty, return `float(np.mean(ages))`; otherwise return `None`. The condition checks array size before calling the mean, avoiding empty-array warnings and a misleading numeric result.

#### `getAgeAverages`, lines 372–377

[View part2.py at line 372](<C:/Users/abdul/OneDrive/Documents/GitHub/FDA-Food-Safety-Data-Pipeline/part2.py:372>)

Return a dictionary of overall, Female, and Male means. The overall mean is calculated independently from **all** valid ages, including unknown-gender reports. It is not the unweighted average of Female and Male means.

For example, ages 20/Female, 40/Male, and 90/unknown produce an overall mean of 50; Female = 20 and Male = 40. Averaging the two named subgroup means would incorrectly give 30 and exclude a valid report.

#### `formatAge`, lines 380–381

[View part2.py at line 380](<C:/Users/abdul/OneDrive/Documents/GitHub/FDA-Food-Safety-Data-Pipeline/part2.py:380>)

Display `N/A` for no valid values, otherwise format the mean to two decimals followed by `years`. Rounding affects display only; values remain unrounded during calculations. Zero age is displayed as `0.00 years`, not `N/A`.

### Ranking and stdout: lines 384–414

[View part2.py at line 384](<C:/Users/abdul/OneDrive/Documents/GitHub/FDA-Food-Safety-Data-Pipeline/part2.py:384>)

#### `getTopTerms`, lines 384–389

[View part2.py at line 384](<C:/Users/abdul/OneDrive/Documents/GitHub/FDA-Food-Safety-Data-Pipeline/part2.py:384>)

1. **385:** Take one list-valued Series, `explode` its lists into individual entries, and remove missing values introduced by empty lists.
2. **386–387:** Return an empty list if there are no terms.
3. **388:** Use `value_counts` and build `(term, int(count))` pairs.
4. **389:** Sort by `(-count, term)`, then take up to the requested limit, default 25.

Negative count means descending frequency; the second tuple element breaks ties alphabetically by normalized string. All distinct terms are ordered before slicing, so ties at position 25 resolve consistently instead of depending on file or input order. The actual ordering is Unicode string order, not locale-specific dictionary collation.

Because each report's list was deduplicated, each term's count equals the number of selected reports mentioning that normalized term. A report can mention multiple different terms, so totals across the ranking can exceed total reports. The output is not a probability distribution.

#### `printTopTerms`, lines 392–398

[View part2.py at line 392](<C:/Users/abdul/OneDrive/Documents/GitHub/FDA-Food-Safety-Data-Pipeline/part2.py:392>)

Print the heading, a no-values message if empty, or one-based numbered entries with comma-formatted counts. The heading is fixed as `Top 25` because the main program uses the default limit. Fewer than 25 distinct terms correctly yields fewer than 25 lines.

#### `printSummary`, lines 401–414

[View part2.py at line 401](<C:/Users/abdul/OneDrive/Documents/GitHub/FDA-Food-Safety-Data-Pipeline/part2.py:401>)

Compute the age means; print total DataFrame rows; then outcomes, reactions, suspect products, and age means, with blank lines between groups. Counts use thousands separators. This is the assignment's required output order.

Age averages are computed before the first printed line, but rankings are computed as their print calls occur. There is no cached summary object: the summary helpers derive results from the same already-built table.

### Annual counts and charts: lines 417–482

[View part2.py at line 417](<C:/Users/abdul/OneDrive/Documents/GitHub/FDA-Food-Safety-Data-Pipeline/part2.py:417>)

#### `getYearCounts`, lines 417–419

[View part2.py at line 417](<C:/Users/abdul/OneDrive/Documents/GitHub/FDA-Food-Safety-Data-Pipeline/part2.py:417>)

Build `range(startYear, endYear + 1)`. The `+1` makes Python's exclusive range endpoint include the selected final year. Count table rows by year, reindex across the full requested range with zeros, and sort ascending by year.

An empty 2024–2026 selection produces `{2024: 0, 2025: 0, 2026: 0}`. Omitting absent years would make the x-axis conceal gaps. These are raw counts by the source `date_started` year, not rates adjusted for population, reporting propensity, or number of products used.

#### `buildChart`, lines 422–463

[View part2.py at line 422](<C:/Users/abdul/OneDrive/Documents/GitHub/FDA-Food-Safety-Data-Pipeline/part2.py:422>)

| Lines | Behavior and purpose |
|---|---|
| 423–425 | Get annual counts and valid ages; create one 12×10-inch figure containing two vertically stacked axes. |
| 427–435 | Plot blue annual bars; label title and axes; display all years with rotated labels; use integer y-axis ticks; place horizontal grid lines behind bars. |
| 436–437 | For all-zero counts, force a usable y-axis of 0–1. |
| 439–441 | Draw a histogram with integer edges from 0 through 126 and narrow white separators. |
| 442–449 | Label the age histogram and axes; set the visible range; use selected age ticks and integer count ticks; add restrained grid lines. |
| 450–453 | If no valid ages exist, use a visible empty scale and show `No valid ages` in axes-relative coordinates. |
| 455–457 | Build the selected-year scope and append the January 1, 2026 coverage note whenever the range reaches 2026. |
| 458–459 | Add the user product filter to the title when present, collapsing whitespace for display only. |
| 460–462 | Add a figure-level title, disable math interpretation of filter text, and lay out axes leaving room for the title. |
| 463 | Return the figure for saving and structural testing. |

Histogram edge arithmetic is a useful interview detail:

```text
np.arange(0, maxAge + 2)
= np.arange(0, 127)
= edges 0, 1, 2, ..., 125, 126
= 127 edges defining 126 bins
```

Most bins have the usual left-inclusive/right-exclusive form `[k, k+1)`; NumPy's final bin includes its right edge. The earlier validator has already excluded ages above 125, so the accepted boundary age 125 lies in the last 125–126 bin. A six-month-old report is age 0.5 and belongs to the first 0–1 bin. No rounding to the nearest birthday occurs.

The histogram's y-axis explicitly says `Reports with Valid Age`. The annual plot retains the assignment's `Total Cases by Year` / `Cases` labels, but the underlying calculation still counts reports, not independently verified unique cases. If asked, use “report counts” when describing the statistical meaning.

#### `saveChart`, lines 466–482

[View part2.py at line 466](<C:/Users/abdul/OneDrive/Documents/GitHub/FDA-Food-Safety-Data-Pipeline/part2.py:466>)

1. **467–469:** Choose a supplied execution timestamp or the current local time; create a filename `YYYYMMDD-HHMMSS-microseconds.png` under the output root. The name is Windows-safe.
2. **470–473:** Create parent directories as necessary; convert filesystem failure into `DataError`.
3. **475:** Build the figure.
4. **476–479:** Save a PNG at 150 DPI with a tight bounding box and white background; turn write `OSError` into `DataError`.
5. **480–482:** Always close the successfully built figure after the save attempt, then return the path on success.

The `finally` block prevents saved or failed-save figures from accumulating in Matplotlib's global state. The function's injectable path and timestamp allow deterministic tests in a temporary directory. It does not use exclusive output creation or a content-addressed filename: reusing an identical timestamp/path can overwrite an existing image. Microseconds make ordinary accidental collisions unlikely, not mathematically impossible.

The `try/finally` covers saving after `buildChart` returns. It is not a universal guarantee that a figure created inside a failing `buildChart` is closed, or that arbitrary plotting/dependency exceptions become friendly data errors.

### Entrypoint and exit codes: lines 485–512

[View part2.py at line 485](<C:/Users/abdul/OneDrive/Documents/GitHub/FDA-Food-Safety-Data-Pipeline/part2.py:485>)

#### `main`, lines 485–495

[View part2.py at line 485](<C:/Users/abdul/OneDrive/Documents/GitHub/FDA-Food-Safety-Data-Pipeline/part2.py:485>)

- **486:** Capture the execution timestamp at the start, unless one was supplied by a test.
- **487:** Parse supplied argument values, or real process arguments excluding the script name.
- **488:** Load and validate all listed reports.
- **489:** Select the report population.
- **490:** Build the normalized report-level table.
- **491:** Save the required chart.
- **492–494:** Print summary and chart location.
- **495:** Return the DataFrame for programmatic use and testing.

Defaults such as `root=dataDir` are bound when the function is defined; changing the global later does not retroactively change that default. Tests correctly inject a root instead. The pipeline stages are separated enough that each can be examined with a small fixture without running the entire CLI.

#### `runCli`, lines 498–508, and main guard, lines 511–512

[View part2.py at line 498](<C:/Users/abdul/OneDrive/Documents/GitHub/FDA-Food-Safety-Data-Pipeline/part2.py:498>)

| Path | Output | Exit code |
|---|---|---:|
| `main` succeeds, including zero matches | Required summary and chart path on stdout | 0 |
| `UsageError` | Error plus usage on stderr | 2 |
| `DataError` | Error on stderr | 1 |
| Unexpected exception | Normal Python traceback; not transformed by these handlers | Nonzero |

When the file is run directly, `__name__ == "__main__"`; Python calls `runCli` and passes its return value to `sys.exit`. When imported by tests, functions/constants are defined and imports execute, including backend configuration, but the command is not automatically run. Missing Python dependencies fail during import before `runCli` is reached.

### Worked example: filtering, deduplication, flattening, and age denominators

This is a **hypothetical fixture**, not a claim about an individual FDA report. Assume four structurally valid reports within a valid test dataset:

| Report | Date | Products and roles | Reactions | Age / gender |
|---|---|---|---|---|
| A | 2024-06-01 | `SUSPECT Organic Baby Carrots`; `SUSPECT ORGANIC BABY CARROTS!`; `SUSPECT Vitamin D3`; `CONCOMITANT Carrots Snack` | `Nausea`, `NAUSEA!`, `Rash` | 40 years / Female |
| B | 2025-02-01 | `SUSPECT Frozen Peas & Carrots` | `nausea` | 24 months / unknown |
| C | 2025-04-01 | `SUSPECT Vitamin D`; `CONCOMITANT Carrots` | `Rash` | 60 years / Male |
| D | 2023-08-01 | `SUSPECT Organic Baby Carrots` | `Rash` | 30 years / Female |

Run `python part2.py 2024 2026 CARROTS`.

1. **Parse:** years 2024–2026, raw product filter `CARROTS`.
2. **Validate:** all four reports are checked before selection, including D outside the requested year interval.
3. **Year filter:** exclude D because 2023 is outside 2024–2026.
4. **Role and name filter:** A and B match. C does not: its carrot name is `CONCOMITANT`, not `SUSPECT`.
5. **Keep one row each:** total selected reports = 2. A has two matching raw products but still creates one selected row.
6. **Restrict eligible product names:** A's `Vitamin D3` and concomitant product do not enter the filtered ranking. A's two carrot spellings do.
7. **Normalize then deduplicate:** A's eligible names become `["ORGANIC BABY CARROTS"]`; B's becomes `["FROZEN PEAS AND CARROTS"]`. A's reactions become `["NAUSEA", "RASH"]`; B's `["NAUSEA"]`.
8. **Explode reactions alone:** the temporary Series contains `NAUSEA`, `RASH`, `NAUSEA`. Counts are NAUSEA = 2 reports; RASH = 1 report. Sum = 3, which can exceed the 2 selected reports because terms are not mutually exclusive.
9. **Explode products alone:** both product labels have count 1. Alphabetical tie-breaking puts `FROZEN PEAS AND CARROTS` before `ORGANIC BABY CARROTS`.
10. **Ages:** A → 40; B → 2 years. Overall mean = `(40 + 2) / 2 = 21.00`. Female mean = 40.00; Male = `N/A`. B's unknown gender does not erase its valid age from the overall calculation.
11. **Annual bars:** 2024 = 1, 2025 = 1, 2026 = 0, with the snapshot-end note visible.
12. **Histogram:** one age in the 2–3 bin, one in the 40–41 bin. There are two age observations, not three product-derived observations.

Now change A's age to 68 decades. A remains selected, NAUSEA remains count 2, both product counts remain 1, and the report total remains 2. A's converted age of 680 is invalid, so the overall mean becomes 2.00; Female and Male means are both `N/A`; the histogram contains only B's age.

One more trap: `VIT D3` and `Vitamin D3` normalize to the same reporting family, but a raw filter `Vitamin D` will match only the latter spelling. Search and grouping deliberately have different jobs. If asked for alias-aware searching later, it should be a documented interface change with tests, not an accidental side effect of moving normalization earlier.

### Complexity: explain the work, not just a label

Let **B** be total input bytes; **R** be report count; **T** be the number of term entries processed across nested lists; **C** be their total text length; **U** be distinct normalized terms in a ranking; **Y** be selected years, at most 25 here.

| Stage | Practical work |
|---|---|
| Load and structural validation | Approximately O(B + R + T), plus date parsing and path operations. ID and path sets have expected constant-time membership checks. Every listed page is read even for a narrow filter. |
| Selection | One pass over reports and eligible product names; substring searching additionally depends on source-name and filter lengths. Avoid promising literal O(R) independent of string length. |
| Normalization | Work broadly proportional to input text length for this fixed set of expressions; per-report set construction plus sorting each report's unique terms. |
| Ranking | Flatten/count terms, then sort all U distinct terms: approximately O(T + U log U), with string comparisons adding their own costs. It is **not** O(25) simply because 25 results are returned. |
| Age means | Several linear scans of the selected report rows; bounded age values and no sorting. |
| Annual counts / histogram | One pass over selected rows/valid ages plus the fixed small year/bin ranges; image rendering has additional fixed and plotting overhead. |

The program retains the full raw report list, ID set during loading, selected wrappers, DataFrame rows, and derived term lists. Some structures hold references to existing dictionaries rather than copies, but strings/lists and pandas object storage still add memory overhead. Peak memory is O(input + derived terms), with an extra temporary flattened Series per ranking.

For much larger data, reasonable next steps are page-wise validation plus streaming counters and age sums/counts, or an explicitly modeled columnar/relational store. A bounded heap can reduce top-k sorting from O(U log U) toward O(U log 25), but preserving deterministic ties and measuring the actual bottleneck matter. For this fixed snapshot, readability and observed runtime supported the simpler full sort. Treat historical timing as historical until the current review remeasures it.

### Decision history: what can be said with evidence

| Decision | Documented source | Grounded explanation |
|---|---|---|
| Fixed January 1, 2026 endpoint | `REVIEW_NOTES.md:275–278`, `642–643` | The task's “present” was clarified to mean the completed snapshot. |
| Matching-only suspect ranking | `REVIEW_NOTES.md:285–308` | Alex expressed this preference; it replaced an earlier all-suspects interpretation. |
| Small deterministic alias mapping | `REVIEW_NOTES.md:279–282`, `300–305`, `772–788` | Required consolidation was met with inspected transformations while protecting meaningful distinctions. |
| One row per report | `REVIEW_NOTES.md:649–651`, `714–717`, `729–733` | Keep totals/ages at report grain and prevent nested lists from multiplying observations. |
| Manifest inventory and full validation | `REVIEW_NOTES.md:652–667` | Refuse incomplete/corrupt inputs before presenting an analysis. |
| Age conversion and ceiling | `REVIEW_NOTES.md:706–717`, `739–743` | All observed units were supported; transparent plausibility rule handles the observed extreme age. |
| Stable top-25 ties | `REVIEW_NOTES.md:789–802` | Produce repeatable ranking output independent of input ordering. |
| One-year histogram and partial-year note | `REVIEW_NOTES.md:853–871` | Represent fractional ages accurately and avoid implying 2026 is a full year. |
| Save before printing success | `REVIEW_NOTES.md:882–889` | Required chart failure makes the command fail coherently. |
| Exact contiguous coverage checks | `REVIEW_NOTES.md:923–929` | Final audit closed a path where a superficially valid partial manifest could pass. |

The beginning of `REVIEW_NOTES.md` still calls the first-page slice “current.” It is an accumulated history, and that opening paragraph is obsolete. The later completed slices and final audit describe the finished code. Historical “14/20/27/30 tests pass” and runtime figures are checkpoints, not contradictory final results. The final notes record 31 Part 2 tests; the present review should report its own actual verification separately.

Do not claim an undocumented thought process as memory. A safe phrasing is: “The review notes record this decision as … The technical reason it makes sense is …” Once comfortable with the rationale, use direct first-person explanations for the design without pretending to remember a conversation you do not actually recall.

### Honest limitations to volunteer when relevant

- This measures reports and associations. It does not establish product causality, incidence rates, or unique people.
- A completion manifest and duplicate-ID checks protect structural completeness; they do not create an immutable API snapshot or authenticate later content edits.
- Literal product selection differs from normalized grouping; punctuation, internal whitespace, and aliases can produce surprising search misses.
- The age average is an available-age mean. Missing-age reports do not enter its denominator, so it is not automatically representative of all consumers.
- The 125-year bound and Vitamin D reporting family are explicit analytic choices, not universal domain truths.
- The normalization policy is narrow and can still collide on punctuation-sensitive names; it is not complete entity resolution.
- The positional CLI cannot unambiguously represent a standalone four-digit product name; it has no dedicated help option.
- The implementation reads the full dataset into memory and validates all data for each analysis. It is appropriate for this snapshot, not an unlimited streaming service.
- Dependencies are ranged, chart names are timestamped, and images are not published atomically. Stronger environment locking and artifact provenance would be reasonable for repeated production use.
- A huge integer age has a freshly reproduced uncaught `OverflowError` path. The narrow fix is to include that conversion failure in the existing guard; no application code was changed during this review.

### Fast Part 2 recall prompts

1. **What is one row?** One selected report.
2. **What is being counted in a ranking?** Reports mentioning a normalized term, at most once per report per term.
3. **Why can counts sum beyond total records?** A report can mention multiple distinct terms.
4. **When does normalization happen?** After raw suspect-product filtering, before within-report term deduplication.
5. **What does `explode` do?** Turn each list element in one Series into a separate temporary row for counting.
6. **Why not explode everything first?** It can duplicate report-level ages and create unwanted cross-products of nested fields.
7. **What is the age denominator?** Selected reports with a finite converted age between 0 and 125, further restricted by gender for group means.
8. **Why `N/A`?** No valid observations, not an average of zero.
9. **Why 2026 looks small?** The fixed snapshot includes only January 1, 2026.
10. **Why all pages even for one year?** Validate the complete snapshot before answering a filtered query.
11. **How are ties resolved?** Count descending, normalized term ascending, then take up to 25.
12. **What does success require?** Valid snapshot, completed analysis, and successfully saved chart; an empty selection is still valid success.


## 1.9 Current review findings and what to check before a demo

These findings distinguish limitations of the current design from failures observed in the delivered data. No application changes were made in this review.

### The saved output is internally consistent

The current ingestion suite passes **98 tests**. The separately enabled, offline full-download validator passes and verifies **987 page files**, **97,652 reports**, **97,652 unique IDs**, dates, per-page totals, and manifest reconciliation. An independent standard-library scan also reproduced the main analysis numbers. It did not run the pandas/Matplotlib pipeline.

The original chart was visually reviewed again: both plots, labels, yearly ticks, and the January 1, 2026 cutoff are readable. A tiny age tail at the far right is expected to be difficult to see next to much larger counts; the histogram still spans the full configured age domain. The zero-to-one bin contains actual valid infant-age observations, not substituted missing ages.

### The current Python environment needs setup before a live run

The source declares its dependencies in `requirements.txt`, but no ready project virtual environment was found. The system Python lacks NumPy, and the bundled environment has NumPy and pandas but lacks Matplotlib. Consequently, the Python test suite could not run past imports during this review. This is a setup gap, not a demonstrated application regression.

The historical record of 31 passing Python tests and roughly 11.9 seconds for the full CLI is useful evidence, but it is not a current-machine benchmark. Do not discover missing dependencies for the first time while sharing your screen. That particular form of audience participation can be avoided.

README setup, from the repository root in PowerShell:

```powershell
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe -m pip check
.\.venv\Scripts\python.exe -m unittest discover -s tests -p test_part2.py -v
```

Those commands are preparation instructions, not claims they were executed successfully in this review. The local ignored tests will not be available in a fresh clone. A virtual environment should remain untracked; the test suite should ordinarily be shared in a team repository. The declared compatible dependency ranges are not an exact lock of the original environment, and the README's minimum runtime versions were not separately tested today. Fresh Node verification used v24.13.0.

### A concrete filename mismatch needs attention before staging

`.gitignore` protects `/.openfda-key`, but this checkout contains an untracked file called `openfda-key`. The difference is the leading dot. Its contents were not opened. This establishes that a credential-like filename misses the intended ignore rule; it does not establish that a secret was committed or exposed.

Before staging changes, correct the filename/ignore policy if this is the credential file. The CLI reads only the environment variable. There is no automatic key-file reader in `part1.js`. Do not display the file in a screen share or use broad staging until its status is resolved.

### Normalization can collapse numeric notation

The exact current normalization function maps the synthetic names `Example 1.5 MG`, `Example 1/5 MG`, and `Example 1-5 MG` to the same label, `EXAMPLE 1 5 MG`. This is a demonstrated policy limitation. It is not proof those exact source names exist in the snapshot.

Generic punctuation cleanup removes distinctions that may matter in dosage or concentration notation. Keeping digits does not guarantee preserving numerical meaning. A future change should preserve meaningful numeric punctuation, inspect raw-to-normalized collisions, and test both desired merges and required separations.

The narrow Vitamin D mapping also groups D2 and D3 intentionally as a reporting family. Alex accepted a small documented equivalence mapping; that is not a blanket clinical endorsement of every alias rule. Keep that distinction clear.

### A huge integer age can bypass graceful rejection

`ageInYears` catches TypeError and ValueError from `float(age)`, but not OverflowError. Calling the exact function with an integer age of `10**400` raises OverflowError before the finite-value check. No such value occurs in the saved data. The intended repair is a narrow conversion-guard change with one regression case, not a broad exception that hides unrelated bugs.

### The manifest is strong evidence, with specific limits

The producer exhausts cursor chains and reconciles counts/IDs. The consumer independently verifies its manifest and reports. But there are no file hashes or upstream snapshot tokens. Count-preserving content edits or upstream replacements can escape detection. The analyzer does not repeat every page-metadata check performed by ingestion or the disk validator.

The temporary-file rename protects publication of the final manifest. It does not make all page writes atomic, provide a multi-file transaction, or guarantee power-loss durability. A failure before the initial incomplete marker is successfully written can leave a fresh directory without a manifest; the analyzer rejects that too.

### Demo route: show the saved pipeline without redownloading

1. Show the README's scope and the manifest's counts. Do not start with all 977 lines.
2. Explain `downloadAll`, then `downloadWindow`, then the shared requester. That follows orchestration before detail.
3. Show the fresh offline ingestion test result and saved-data validator result. They make no FDA requests.
4. Once Python dependencies are installed, run the overall analysis and `2024 2026 CARROTS`. Expected totals are 97,652 and 149. A full-range CARROTS filter selects 241.
5. Explain one report's raw suspect names, normalized per-report set, and age conversion. Then show the chart.
6. Explain one honest limitation and the first concrete improvement appropriate to the question.

Every successful CLI analysis writes a new timestamped chart. If retaining the single committed chart matters during practice, call the testable entry point with a temporary chart root:

```powershell
.\.venv\Scripts\python.exe -c "import tempfile; from pathlib import Path; import part2; out = Path(tempfile.mkdtemp(prefix='fda-review-')); part2.main(['2024', '2026', 'CARROTS'], chartRoot=out)"
```

To rerun the current offline downloader tests:

```powershell
node --test tests/part1.test.js
$env:VERIFY_FDA_DOWNLOAD = '1'
node --test tests/part1.download.test.js
Remove-Item Env:VERIFY_FDA_DOWNLOAD
```

`node part1.js` deliberately refuses the already-present `data` directory. It is not the right opening demo command for a repository that already includes the delivered snapshot. A fresh ingestion is a separate operation requiring a fresh destination and API quota.

