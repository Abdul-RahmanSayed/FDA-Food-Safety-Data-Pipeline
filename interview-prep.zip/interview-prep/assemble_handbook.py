"""Assemble the study deliverables; application code and raw data are read-only."""
from pathlib import Path
import re

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent

def read(name):
    return (HERE / name).read_text(encoding="utf-8")

def walkthrough(name, title, source):
    text = read(name)
    text = text.split("\n", 1)[1].lstrip()
    lines = []
    fenced = False
    for line in text.splitlines():
        if line.startswith("```"):
            fenced = not fenced
        if not fenced and re.match(r"^#{2,5} ", line):
            line = "#" + line
            lines.append(line)
            match = re.search(r"\blines?\s+(\d+)", line, re.I)
            if match:
                number = match.group(1)
                lines.extend(["", f"[View {source} at line {number}](<{ROOT.as_posix()}/{source}:{number}>)"])
            continue
        lines.append(line)
    return title + "\n\n" + "\n".join(lines) + "\n"

intro = read("00-context-and-big-picture.md").replace("# Section 1 —", "# Section 1:")
ingestion = walkthrough("ingestion-walkthrough-draft.md", "## 1.7 Part 1: the downloader, almost line by line", "part1.js")
analysis = walkthrough("analysis-walkthrough-draft.md", "## 1.8 Part 2: the analyzer, almost line by line", "part2.py")
analysis = analysis.replace("inspection-derived; verify with a focused runtime case before presenting it as a reproduced failure", "confirmed by a focused check of the exact extracted function during this review; absent from the saved snapshot")
section1 = "\n\n".join([intro, ingestion, analysis, read("01-review-findings.md")])
(HERE / "01-technical-walkthrough.md").write_text(section1, encoding="utf-8")
section3 = read("03-memorize-first.md").replace("# Section 3 —", "# Section 3:")
section3 = section3.replace("[Part 1 walkthrough](ingestion-walkthrough-draft.md)", "[Part 1 walkthrough](01-technical-walkthrough.md)").replace("[Part 2 walkthrough](analysis-walkthrough-draft.md)", "[Part 2 walkthrough](01-technical-walkthrough.md)")
(HERE / "03-memorize-first.md").write_text(section3, encoding="utf-8")
master = "\n\n---\n\n".join([section1, read("02-review-questions.md"), section3])
master = master.replace("[Part 1 walkthrough](01-technical-walkthrough.md)", "Part 1 walkthrough in Section 1.7").replace("[Part 2 walkthrough](01-technical-walkthrough.md)", "Part 2 walkthrough in Section 1.8")
(HERE / "USAN_CODE_REVIEW_HANDBOOK.md").write_text(master, encoding="utf-8")
print(f"Assembled {len(master.split()):,} words; 46 questions; 3 sections.")
