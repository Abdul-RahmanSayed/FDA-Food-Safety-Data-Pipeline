# Independent verification and reviewer concerns

Prepared September 6, 2026 against the current local checkout. This is source material for the interview guide, not a claim that the original author consciously considered every improvement below. No ingestion requests were made. Application source and saved data were not modified. The local credential file was not opened.

## What was freshly checked

| Check | Actual result | What this establishes |
|---|---|---|
| `node --test --test-reporter=spec tests/part1.test.js` | 98 tests passed, zero failed or skipped; approximately 1.74 seconds reported by the runner | Current downloader behavior passes its existing synthetic tests, including real temporary filesystem writes. |
| `$env:VERIFY_FDA_DOWNLOAD = '1'; node --test --test-reporter=spec tests/part1.download.test.js` | One test passed; 987 page files and 97,652 unique reports verified; approximately 2.57 seconds | The current saved dataset agrees with the manifest, date windows, page size, per-page totals, file inventory, and unique identifiers. This test does not contact FDA. |
| Node version | v24.13.0 | Runtime used for these fresh Node checks. Historical notes reference another development runtime. |
| System Python dependency check | Python 3.14.2 cannot import NumPy | This machine's default interpreter is not currently ready to run Part 2. |
| Existing Python 3.13 installations | Both checked installations lack NumPy | No ready project environment was found there. |
| Bundled Codex Python dependency check and `-m unittest discover -s tests -p test_part2.py -v` | Test discovery fails because Matplotlib is missing | The Python suite was **not freshly passed**. This is an environment setup failure before application tests run, not evidence of an application regression. No dependencies were downloaded for this review. |
| Independent standard-library scan of all saved pages | Counts, filters, term rankings, and age figures below reproduced | Current stored data supports the figures in the implementation notes. This does not validate Matplotlib rendering or time the complete Part 2 CLI. |
| Current chart file | `charts/20260904-161132-070140.png` exists and is tracked; 108,078 bytes | The README image target exists. This check did not generate or visually re-review a new chart. |

The historical final audit in `REVIEW_NOTES.md:938-947` records 98 passing Node tests, 31 passing Python tests, and a complete Part 2 run around 11.9 seconds. Keep that historical evidence separate from what passed again today. Before a live demo, create the documented virtual environment, install `requirements.txt`, and rerun the 31 Python tests plus a complete analysis. Do not say the current machine has a freshly verified 11.9-second Part 2 runtime.

The additional JSON file `verification-facts.json` contains the complete independently recomputed facts, annual counts, and top-ten rankings.

## Dataset facts worth having available

| Fact | Verified value |
|---|---:|
| Inclusive requested date range | 2002-01-01 through 2026-01-01 |
| Independent windows | 24 |
| Page files | 987 |
| Reports / distinct report numbers | 97,652 / 97,652 |
| Manifest download start | 2026-09-04 18:24:34.942 UTC |
| Manifest completion | 2026-09-04 18:29:41.824 UTC |
| Recorded elapsed download time | 306.882 seconds, about 5 minutes 7 seconds |
| Reports dated January 1, 2026 | 24 |
| Reports in calendar 2025 | 3,718 |
| Valid ages | 73,819 |
| Valid female / male / unknown-gender ages | 54,500 / 17,853 / 1,466 |
| Overall / female / male mean age | 48.29 / 50.58 / 42.47 years |
| Missing ages | 23,832 |
| Other rejected nonmissing ages | One: 68 decades, which converts to 680 years |
| Oldest retained age | 122.75 years |
| Distinct normalized outcomes / reactions / suspect products | 13 / 4,621 / 50,282 |
| Full-range `CARROTS` selection | 241 reports |
| 2024–2026 `CARROTS` selection | 149 reports |
| 2024–2026 `CARROTS` overall / female / male mean ages | 42.95 / 45.44 / 40.53 years |

The 2026 bar is only one day. A small 2026 count is not evidence that adverse events suddenly declined. The final download window combines 2025 with January 1, 2026, but the analyzer groups the individual records by their actual event year, so it still draws separate 2025 and 2026 bars.

Some memorable ranking facts:

- Most common normalized outcome: `OTHER SERIOUS OR IMPORTANT MEDICAL EVENT`, 53,454 reports.
- Most common normalized reaction: `DIARRHOEA`, 15,780 reports.
- Most common supplied suspect-product label: `EXEMPTION 4`, 26,791 reports. This is not a usable commercial product identity. The implementation deliberately retains the source placeholder.
- There are 13 outcome categories. “Top 25” therefore correctly prints 13.
- The outcome `DEATH` counts 12,194 reports; the reaction `DEATH` counts 12,192. These are different source fields, so the program does not assume equal counts.

These are counts of reports, not proof of causation, rates per exposure, or counts of unique people. One report can mention multiple products and multiple reactions. A product ranking can be influenced by usage, reporting practices, source placeholders, and missing information. It cannot rank product safety from these counts alone.

## Existing tests: useful examples to explain

The Node tests inject fetch responses and a clock. They exercise the actual pacing/retry code without contacting FDA or waiting real minutes; temporary directories exercise real file behavior. That establishes deterministic behavior under specified conditions, not the real network's future reliability or production load performance.

The most valuable Node scenarios are:

1. A short page already contains the window's final date, but has a next cursor. The downloader keeps going. Date position and short-page length are not termination rules.
2. Exactly 200 reports arrive as two full pages followed by the explicit FDA no-match 404. The terminal response succeeds only when the final report count reconciles.
3. A cursor chain returns 26,001 simulated reports. It progresses through supplied cursors without constructing offsets or stopping at the ordinary offset depth.
4. The total changes, an ID repeats, a cursor repeats, or pagination ends early. The run fails instead of publishing completeness.
5. A later page times out. The same cursor is retried, while already saved preceding pages are not saved again.
6. A 429 extends shared cooldown while a different worker is already waiting. Waiting workers recheck the latest cooldown rather than releasing a burst.
7. A worker fails. New windows stop being assigned; existing workers finish their windows; the caller receives failure after they settle.
8. Writing the final manifest fails. The old incomplete marker remains; successful page downloads alone do not publish success.

The seven-report Python fixture in `tests/test_part2.py:39-56` is a good small example to walk through verbally:

- R1: 2023, suspect Vitamin D3.
- R2: 2024, suspect Organic Baby Carrots and Spinach.
- R3: 2024, CARROTS supplement is CONCOMITANT; Oats is SUSPECT.
- R4: 2024, suspect Yes To Carrots Hydrating Gel.
- R5: 2025, suspect CARROT sticks, singular.
- R6: 2025, duplicate suspect Frozen peas & CARROTS entries plus Celery.
- R7: 2026-01-01, suspect A+B Nutrition.

With the literal `CARROTS` filter, R2, R4, and R6 match. R3 does not match because the matching product is not suspect. R5 does not match because `CARROTS` is not a substring of singular `CARROT`. The hydrating gel does match: this filter is text matching, not a semantic “vegetable” classifier. In the filtered product ranking, Spinach and Celery do not appear. R6's duplicate matching names contribute once to that product term, and R6's consumer contributes one age. These fixture expectations follow the source and are covered by the existing tests; the Python suite itself could not be rerun today because the required environment is missing.

## Prioritized reviewer concerns and defensible answers

### 1. Immediate repository hygiene: credential filename does not match ignore rule

Evidence: `.gitignore:13` ignores `/.openfda-key`, but current `git status --short` lists an untracked file named `openfda-key` without the leading dot. Its contents were not read. The historical statement that the credential file is ignored must not be repeated as a verified current fact.

This is not proof a secret has been committed or exposed. It means the current filename is not protected by the intended Git ignore rule. Confirm the file's purpose and correct the rule or filename before staging changes. Avoid `git add .` until that mismatch is handled. Do not print the contents in the guide or a terminal demo.

Suggested answer: “The request key is injected through the environment and omitted from the manifest and request logs. I also need repository hygiene to match that design. This checkout has a credential-like filename that does not match its ignore rule, which I would correct before committing.”

### 2. Reproducibility: tests are local, and the Python environment is absent

Evidence: `.gitignore:1-2` excludes `/tests/`; `.gitignore:7` excludes `/.venv/`; `requirements.txt:1-3` specifies compatible ranges, not exact dependency pins. All 31 Python test functions exist locally, but a fresh clone does not receive the ignored test directory. Excluding a virtual environment is appropriate; excluding the only test suite weakens a shared review/CI workflow.

Suggested answer: “I built a substantial local regression suite while working in small slices. For a shared production repository, I would commit the tests and run them in CI. I would retain the human-readable dependency ranges if useful, and add a resolved lock or constraints file so the tested environment is reproducible.”

Follow-up, “Are the tests passing right now?”: “The current Node suite passes all 98 tests, and the separate saved-data scan passes. The notes record 31 passing Python tests at completion. This machine needs the Python dependencies installed before I can honestly claim a fresh Python pass.”

### 3. Completion checking is strong, but it is not an immutable source snapshot

Evidence: `part1.js:320-327`, `part1.js:352-356`, and `part1.js:421-446` reconcile totals and identifiers and then publish the manifest. `part2.py:235-264` rereads pages and checks IDs and counts. The source can still change in ways that preserve counts. There are no recorded page checksums or upstream snapshot/version token.

Suggested answer: “The manifest is a completion contract for this download. I reconcile page counts, report counts, unique IDs, and date coverage. That catches many incomplete or mixed runs, but it does not turn a changing API into an immutable database snapshot. For stronger reproducibility I would capture source version information if available and hash the saved pages.”

Follow-up, “Is the manifest atomic?”: “The final manifest is written to a temporary file and renamed into place. That protects publication from a partially written final manifest. The page files themselves use exclusive writes and can be partial after an interrupted write; the run remains incomplete. This is not a database transaction or a guarantee of durability after sudden power loss.”

### 4. Product cleanup is an explainable policy with semantic tradeoffs

Evidence: `part2.py:34-42` and `part2.py:320-340`. The D2/D3 grouping is an explicitly approved reporting-family aggregation in `REVIEW_NOTES.md:779-785`; it does not mean the compounds are chemically identical. Generic punctuation cleanup also removes decimal points and slash/hyphen distinctions.

A focused check ran the exact AST-extracted normalization function unchanged, with its original constants. These three synthetic names all normalize to `EXAMPLE 1 5 MG`:

- `Example 1.5 MG`
- `Example 1/5 MG`
- `Example 1-5 MG`

This demonstrates a policy limitation, not evidence that these exact names or an incorrect merge occur in the saved dataset. A bounded scan of existing suspect-product groups found one family with numerical punctuation variation: `NIACIN 500 - 100 TABLETS`, `NIACIN 500 100 TABLETS`, and `NIACIN 500-100 TABLETS`. Its semantic equivalence was not independently adjudicated.

Suggested answer: “I used deterministic normalization so every merge is explainable and testable, and I avoided fuzzy matching. It still has policy choices. D2/D3 grouping is intentional for the requested reporting family, and generic punctuation cleanup can erase meaningful notation. Before using these groups for more consequential analysis, I would preserve numeric punctuation, inspect collisions, and version the normalization policy.”

Do not say normalization preserves every dosage or every semantic distinction. It preserves most wording and numbers while applying the documented cleanup rules; those rules can still collapse distinctions.

### 5. Error handling has a small numeric overflow gap

Evidence: `part2.py:299-302` catches `TypeError` and `ValueError` around `float(age)`, but not `OverflowError`. A focused check of the exact extracted function with an age value of `10**400` raises `OverflowError: int too large to convert to float`; the CLI's handlers at `part2.py:498-508` do not catch this type either. A numeric string of very large magnitude usually becomes infinity and is rejected later, which is different from a huge Python integer.

No such age appears in the saved snapshot. This is a narrow robustness gap in the claim that every malformed/unusable age is excluded cleanly. Catching `OverflowError` alongside the existing conversion failures would preserve the intended behavior. This observation was not fixed as part of interview preparation.

Suggested answer if asked about an unexpected numeric edge: “I validate finite converted ages and reject implausible values, but Python conversion itself can overflow for a huge integer. I would include `OverflowError` in that conversion guard and add a focused regression case.”

### 6. Operational limits are deliberate scope boundaries

- **No resume:** `part1.js:291-294`, `part1.js:367-368` claim fresh directories. The design protects earlier output and avoids mixed runs. A production resume feature would need durable checkpoints, a clear cursor-expiry strategy, and revalidation; it is not simply skipping existing filenames.
- **Failure can take time to return:** `part1.js:391-418` allows other in-progress windows to finish. One complete window, not merely one HTTP request, is the unit of existing work that continues. Cancellation would be a separate enhancement.
- **Bounded attempts do not mean a short maximum wall time:** `part1.js:195-198`, `part1.js:227-241` honor potentially long `Retry-After` values. There are at most four attempts for a request, but no run-wide deadline or cap on server-directed waiting.
- **Memory grows with data:** `part1.js:296-297`, `part1.js:386` retain ID/cursor sets; `part2.py:235-264`, `part2.py:343-357` load all reports and construct a full DataFrame. Adequate for this roughly 98,000-report assignment, but not a streaming implementation.
- **Filtering follows validation:** `part2.py:485-490` validates the whole dataset before filtering. That costs work for a narrow query, but ensures a selected subset is never presented as if an incomplete snapshot were complete.
- **CLI ambiguity:** `part2.py:58-81` interprets exact four-digit arguments as years. A product actually named with four digits cannot be unambiguously passed alone. Explicit `--from`, `--to`, and `--product` options would fix that if the interface were expanded.
- **Raw matching precedes normalization:** `part2.py:267-287` compares casefolded source product names to the raw substring. Alias grouping affects rankings after selection; it does not add synonym-aware search. Searching `VITAMIN D` need not find a raw `VIT D` abbreviation.

## Compact review response structure

For questions about a limitation, use: **what it does now → why that was reasonable here → what it does not guarantee → the next concrete improvement.**

Example: “Right now the analysis validates and loads the whole saved snapshot before filtering. That kept the completion guarantees simple and was fast enough for this dataset. It does use memory proportional to the dataset. If the volume grew substantially, I would retain the same validation contract but stream records into incremental counts and age statistics, or store validated records in a queryable local database.”

For questions about verification, use: **unit behavior → real filesystem behavior → saved-data reconciliation → live-source limitation.** That is a much stronger answer than “the tests passed,” while staying honest about what each check proves.
