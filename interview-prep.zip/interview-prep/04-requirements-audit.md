# USAN assignment versus delivered output

Reviewed September 8, 2026 against application commit `dc44199`, the saved dataset, README, chronological review notes, and the assignment/Alex replies previously retrieved from the [shared project conversation](https://chatgpt.com/s/cx_6a9b429a2c508191a790f06634f40b71).

**Assessment:** The main pipeline and deliverables match the assignment. The strongest concrete gaps are incomplete consolidation of obvious product-name variants and a positional CLI that cannot express some numeric product filters. Parallel-request wording and the meaning of “Present” need careful qualification. I found no demonstrated missing-record, date-boundary, page-limit, chart-deliverable, or output-order failure in the saved submission.

No application code, data, chart, dependency, or ignore-rule changes were made. The fixes below are proposals. Spoken answers are suggested explanations, not claims that every limitation was anticipated during development.

## 1. Requirement-by-requirement assessment

| Requirement | Current implementation/output | Assessment |
|---|---|---|
| Node.js ingestion in `part1.js` | Built-in fetch and Node modules; standalone entry point | Meets |
| All records with `date_started` from January 1, 2002 through January 1, 2026, inclusive | 24 disjoint windows, cursor exhaustion, 97,652 unique saved reports; both endpoints present | Saved output passes internal completeness and boundary checks; not a new live FDA snapshot comparison |
| Request `limit=100` | Initial URLs set 100; next-page links must preserve it; retries reuse the URL | Meets. A response can legitimately contain fewer than 100 records |
| Configurable concurrency, default 3 | Three worker slots by default; one outstanding request per worker; shared start pacing | Configuration meets; literal “actively process 3 network requests in parallel” requires qualification |
| Robustness to rate limits, pagination depth, failures | Cursor pagination, timeout/retry policy, shared 429 cooldown, incomplete manifest, contextual errors/nonzero exit | Meets the specified intent; resume and immediate cancellation are additional features, not stated requirements |
| JSON in `./data`, committed solution | Git tracks 987 page files, manifest, both scripts, requirements, README, one chart | Local tracked deliverables present; this review did not independently verify the remote repository state |
| Part 2 reads Part 1 JSON | Loads manifest-listed pages and validates the completed input | Meets the pipeline contract; arbitrary FDA JSON without this manifest is not accepted |
| Zero/one/two years and arguments in any order | Required examples work; reversed year order is sorted | Meets examples; four-digit product text exposes an interface gap |
| Case-insensitive substring on a suspect product in the same report | Matches original suspect-product names before normalization | Meets; aliases are not used to expand literal search |
| Filtered product ranking | Includes only matching suspect names from selected reports | Matches Alex's preference |
| Count each normalized term once per report | Normalize, then make a per-report set, then aggregate | Matches Alex's clarification |
| Consolidate slight variations in products and reactions | General cleanup plus a small product alias list | Meets the clarified minimum approach; actual obvious product variants remain split |
| pandas, NumPy, Matplotlib; no heavy NLP | All three are used; no heavy NLP dependency | Meets |
| Careful age averages | Converts supported units, excludes invalid ages, distinguishes overall and gender denominators | Meets for saved data; one extreme-input exception gap exists |
| Required console order | Total, outcomes, reactions, suspect products, overall/female/male ages | Meets by source inspection and prior full execution; a chart-path line follows |
| Top 25 outcomes | Prints 13 because only 13 normalized outcome labels exist | Correct; inventing or padding 12 additional outcomes would be wrong |
| Under one minute regardless of valid arguments | Historical full CLI about 11.9 seconds; all data validated before filtering | Supported by prior measurement, not freshly benchmarked in a complete Python environment today |
| One timestamped overall PNG, two subplots | One tracked PNG; cases by year and valid ages in one-year bins | Meets; chart visually rechecked today |

The “15–20 minutes exploring JSON” instruction concerns development process. The review notes contain exploration and implementation slices. Source code alone cannot prove an exact amount of time spent exploring, so do not invent a stopwatch claim.

## 2. Highest-priority finding: obvious product variants remain separate

The assignment explicitly asks for consolidated Top 25 lists. Alex accepted consistent normalization plus a small documented equivalence mapping as the minimum. That supports the chosen approach, but does not establish that every important variation was caught.

The current alias list at `part2.py:38` and normalization at `part2.py:320` do not repair several split/joined words. A fresh scan applied the exact current normalization functions to every manifest-listed page and recomputed distinct-report unions:

| Current labels | Current counts | Count after the proposed narrow consolidation |
|---|---:|---:|
| JIF CREAMY PEANUT BUTTER / JIF CREAMY PEANUTBUTTER | 648 / 1 | 649 |
| PRESERVISION AREDS 2 / PRESERVISION AREDS2 | 380 / 4 | 384 |
| CENTRUM SILVER WOMENS50 PLUS MULTIMINERALS MULTIVITAMINS TABLET / variants with MUL TIMINERALS or MULTIVITAMINSTABLET | 247 / 3 / 1 | 251 |

These counts use report-ID unions, not an assumption that counts can always be added. The proposed aliases have not been applied to the application or delivered output.

Representative source evidence:

- `data/20220101-20221231/page-000035.json:2416` — JIF CREAMY PEANUTBUTTER.
- `data/20160101-20161231/page-000011.json:1856` — PRESERVISION AREDS2.
- `data/20120101-20121231/page-000043.json:612` — Centrum MUL TIMINERALS.
- `data/20120101-20121231/page-000044.json:269` — Centrum MULTIVITAMINSTABLET.

**Suggested change:** Add narrow aliases backed by inspected examples; test intended merges and required separations; deduplicate after aliases; regenerate and compare the overall and filtered rankings. A broad fuzzy-matching rewrite is unnecessary for these examples.

**Alex might ask:** “You were asked to consolidate terms. Why are these still separate?”

**Answer:** “I used deterministic cleanup and a small equivalence map, which matched the minimum approach we discussed. Reviewing the actual output revealed a few obvious spacing variants the map missed, including AREDS2 versus AREDS 2. That is a remaining data-quality gap. I would add those specific aliases and verify distinct-report counts after merging. I would not describe this as exhaustive entity resolution.”

**Follow-up:** “Why not use fuzzy matching?”

**Answer:** “A close string match can still have a different dose, formulation, or clinical qualifier. For these obvious spacing mistakes, a small reviewed rule is easier to explain and test. A larger matching system would need explicit precision and recall evaluation.”

Reactions do receive normalization. For example, case variants of DIARRHOEA consolidate to 15,780 reports. A small remaining candidate is ANAEMIA HAEMOLYTIC AUTOIMMUNE versus AUTOIMMUNE HAEMOLYTIC ANAEMIA, totaling three reports. It does not affect the current Top 25 and needs a reviewed equivalence rule rather than automatic word sorting. Abdominal pain versus upper abdominal pain is not automatically a missed consolidation.

## 3. Concrete CLI gap: some numeric product text is unrepresentable

At `part2.py:62`, every exact four-digit argument becomes a year before product text is constructed.

- `python part2.py VITAMIN D 1000 IU` fails because 1000 is classified as an out-of-range year.
- `python part2.py "VITAMIN D 1000 IU"` works as a product phrase because the entire argument is not four digits.
- `python part2.py 1000` fails. Quoting just `"1000"` does not help; shells remove the quotes before Python receives the argument.
- `python part2.py 2002` necessarily means a year, so it cannot also mean the literal product substring 2002.

A fresh saved-data scan found **377 reports with a suspect-product name containing `1000`**. This is a real subset the current CLI cannot request as a standalone product substring. The required CARROTS examples still work.

**Suggested change:** Preserve existing positional syntax but add an explicit `--product` option or other unambiguous product-text escape. Test standalone numeric text, quoted dose phrases, mixed argument ordering, and the existing examples.

**Alex might ask:** “What happens if the product name contains a number?”

**Answer:** “A quoted phrase with a dose works, but the current parser interprets a standalone four-digit token as a year. That makes a literal 1000 filter impossible through this interface. The ambiguity is documented, but it is still a limitation. An explicit product option would remove it while keeping the required positional examples.”

**Follow-up:** “Could you just recognize years from 2002 to 2026?”

**Answer:** “That would help with 1000, but a product substring such as 2024 would still be ambiguous. An explicit product option resolves the underlying ambiguity.”

## 4. Concurrency wording is stricter than a capacity limit

The assignment says to actively process three network requests in parallel. The implementation defaults to three workers (`part1.js:359`), but its shared gate spaces all starts by 300 milliseconds (`part1.js:200`).

A fresh offline observation used the unchanged production requester, three simultaneous callers, real pacing, and injected responses:

| Simulated response duration | Approximate starts | Peak active requests |
|---|---|---:|
| 50 ms | 17, 329, 636 ms | 1 |
| 700 ms | 1, 304, 611 ms | 3 |

There is real overlap capability. Fetches are not accidentally serialized behind the admission queue. However, fast responses can finish before the next request starts, and the manifest's configured limit does not prove actual overlap during the historical live run.

**Assessment:** A defensible paced worker pool, with an acceptance risk if Alex expects an immediate batch of three or persistent utilization whenever work remains. Do not call it a proven violation of concurrency in general, or promise three requests continuously active.

**Suggested change:** Clarify the README to say “up to three in-flight requests, with shared 300 ms start pacing.” If immediate overlapping starts are specifically required, revise scheduling to permit a controlled burst while respecting the API quota, then verify both concurrency and rate behavior. That is a scheduling change to validate, not a cosmetic last-minute tweak.

**Alex might ask:** “Are there actually three requests happening at the same time?”

**Answer:** “There can be, and I tested that overlap. The shared pacing means requests start 300 milliseconds apart, so fast responses can result in fewer than three active requests. The implementation provides three worker slots with a paced concurrency cap. If the intended requirement was to launch three immediately whenever work is available, I would revise the admission policy.”

## 5. “Present” means the fixed input snapshot in this submission

Part 1 explicitly ends on January 1, 2026. Part 2 uses that snapshot endpoint rather than downloading through the day of execution. There are **24 records on January 1, 2026**; the 2026 chart bar does not represent a full year.

This is a reasonable reconciliation of the assignment's fixed ingestion scope and its “Present” wording. It was Abdul's documented interpretation, not an explicit Alex approval. The README explains it and the chart displays the cutoff.

**Suggested change:** Prefer “end of the supplied snapshot” wherever explaining the current default. If Alex wants genuinely current data, the ingestion range and its manifest/analysis validation contract must change together. Extending only the chart or default year would not fetch the missing records.

**Alex might ask:** “Why doesn't this include the rest of 2026?”

**Answer:** “Part 1 specified an inclusive January 1, 2026 cutoff, and Part 2 reads that output. I interpreted Present as the latest date in the required snapshot and labeled the cutoff. If you intended current-date coverage, that is a different ingestion scope, so I would update the bounds and validation together.”

## 6. Important output interpretation: EXEMPTION 4 is not one product

The leading normalized suspect label is **EXEMPTION 4: 26,791 reports**. The FDA's CAERS documentation explains that product-name redactions use Exemption 4. It is therefore a redacted-name bucket, not a single identified commercial product. [FDA CAERS extract readme, page 3](https://www.fda.gov/files/food/published/Read-Me-File-For-CFSAN-Adverse-Event-Reporting-System-Quarterly-Data-Extract.pdf).

Counting that source label once per report is consistent with the implemented counting rule. The problem would be interpreting it as the most frequently reported actual product. It also occupies one of the 25 ranking slots.

**Suggested change:** Annotate it as redacted product names. If an identified-product ranking is desired, report redacted counts separately and explicitly define that ranking. Keep these reports in overall totals and age/year analyses. Do not silently delete them or pretend their identities can be recovered by normalization.

**Alex might ask:** “What is Exemption 4, and should it be in your product list?”

**Answer:** “It is the source's redacted-name category. The count is a report count for that label, not one product. I retained it so the raw category did not silently disappear, but I should label that limitation. For an identified-product ranking, I would show the redacted bucket separately and state the exclusion policy.”

These results describe reports, not proven causation, patient-level incidence, or comparative product risk. That is also stated in the [openFDA results documentation](https://open.fda.gov/apis/food/event/understanding-the-api-results/).

## 7. Smaller issues and evidence limits

**Numeric punctuation can be over-normalized.** The current function maps the synthetic labels `Example 1.5 MG`, `Example 1/5 MG`, and `Example 1-5 MG` to `EXAMPLE 1 5 MG`. This is a demonstrated rule limitation, not a confirmed corruption of a real Top 25 result. Preserve meaningful decimal/fraction notation before generic punctuation cleanup, and inspect raw-to-normalized collisions. Do not claim that retaining digits guarantees retaining dosage meaning.

Suggested answer: “The cleanup is too broad for some numeric notation. I would preserve meaningful numeric punctuation and add separation tests. I have not established that this changed the delivered leading results.”

**One extreme malformed age can escape graceful handling.** `ageInYears` catches TypeError and ValueError from float conversion, but not OverflowError (`part2.py:299`). An integer such as `10**400` raises before the finite-value check. No such age was found in the saved snapshot. A narrow additional exception guard is appropriate; this is not evidence the reported averages are wrong.

**The one-minute target has historical evidence, not a fresh full CLI benchmark today.** The final development notes record 31 passing Python tests and approximately 11.9 seconds for the complete CLI. Today's system Python lacks the required libraries, and the bundled environment lacks Matplotlib. Standalone scans and exact extracted functions do not substitute for a fresh pandas/Matplotlib execution. Install the declared requirements in the intended demo environment and benchmark the overall, one-year, range, product, and no-match cases before screen sharing. The environment problem is not a demonstrated runtime failure or timeout in a correctly configured application.

**Fresh ingestion refuses the included dataset directory.** `node part1.js` fails before fetching when `data` already exists. That is the documented overwrite-protection policy, not evidence that the saved pipeline is broken. Demonstrate Part 2 on the included snapshot first. For a new ingestion, use a fresh destination and preserve the submitted data.

**Credential filename and ignore rule differ.** Git currently shows untracked `openfda-key`, but `.gitignore` protects `/.openfda-key`. The content was not read. Correct the exact ignore policy before broad staging. This is a concrete housekeeping issue, not an assignment scoring requirement or evidence of a committed secret.

**The review notes are a chronological development log.** Early slices correctly describe incomplete earlier implementations. They are not the current execution contract. The log's stated live-run UTC times differ by four hours from the saved manifest, although both indicate about 307 seconds elapsed. Use the manifest's `2026-09-04T18:24:34.942Z` to `18:29:41.824Z` when describing that artifact. The “Confirmed scope” heading also should not be read as proof that Alex personally approved every assumption beneath it.

## 8. What I would do before the review

1. Verify that the exact Python demo environment can run the overall and representative filtered cases within the required time. Keep the submitted chart intact by directing practice runs to a temporary chart directory when using the testable entry point.
2. Memorize the concrete AREDS/JIF consolidation examples and the numeric-filter ambiguity. These are better answers than defending the output as perfect.
3. Explain concurrency as paced capacity and explain the January 1 cutoff explicitly.
4. If there is time for a small reviewed follow-up, prioritize the numeric product escape and narrowly evidenced aliases. Regenerate and compare outputs after normalization changes; do not quietly present changed numbers as the original submission.
5. Avoid a last-minute architecture rewrite. Databases, fuzzy NLP, resumable downloads, and a new scheduler are not needed to explain the current submission clearly.

**A useful overall answer to Alex:** “The ingestion and delivered snapshot pass the boundary, cursor, count, and uniqueness checks. The analysis follows the required filtering and report-level counting rules. The main remaining gaps I found are a few obvious product aliases that were missed and an ambiguity between numeric product text and positional years. I can show their exact effects and the small changes I would make. I would also qualify the pacing, snapshot cutoff, and redacted-product category when explaining the output.”

## 9. Verification performed for this audit

- Fresh offline Node suite: **98 passed, 0 failed**.
- Fresh full-download validator: **987 page files, 97,652 unique reports; passed**.
- Fresh independent scans using unchanged normalization/selection logic: real alias candidates, report-union counts, redacted-label count, numeric product subset.
- Fresh exact parser exercises: numeric-token failures, quoted multiword success, reversed CARROTS/year argument order.
- Fresh controlled requester observations: both non-overlap with fast responses and three-request overlap with slower responses.
- Fresh Git deliverable inventory and chart visual inspection.
- No new FDA data download, dependency installation, or full Python CLI benchmark. The previously recorded 31 Python tests and 11.9-second runtime remain historical evidence.
