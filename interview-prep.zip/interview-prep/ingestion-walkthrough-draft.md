# Part 1: ingestion, execution order, and design decisions

Prepared from the current `part1.js` (465 lines), `README.md`, `REVIEW_NOTES.md`, `data/manifest.json`, the commit history at `dc44199`, and the [shared project conversation](https://chatgpt.com/s/cx_6a9b429a2c508191a790f06634f40b71). Application code was not changed. References to notes describe recorded decisions or historical verification, not a new test run. Where checkpoint notes conflict with the exact assignment or current artifacts, the assignment and current artifacts take precedence.

## The explanation to give before opening the code

> “I split the project into an ingestion stage and an analysis stage. The Node script downloads the fixed FDA date range and saves the original response data. The Python script then analyzes that local snapshot, so changing an analysis filter does not require another API download. For ingestion, I process independent date windows concurrently, but I follow the cursor within each window sequentially. Every page is validated before saving, and I only publish a completed manifest after the page counts, reported totals, and unique report IDs reconcile.”

The fixed search is `date_started` from January 1, 2002 through January 1, 2026 **inclusive**. The final date is one day of 2026, not the entire year and not today's date. The downloader searches by the report's `date_started` field; do not describe it as a download-date or report-received-date filter.

The raw API responses are the handoff between languages. Keeping ingestion and analysis separate makes the analysis reproducible against a committed snapshot and avoids consuming API requests every time someone runs a different report. The current code writes parsed JSON back with two-space indentation, so it preserves the JSON values and response envelope, not the original bytes or whitespace of the HTTP body.

## How execution actually starts

The source is organized as helpers followed by orchestration. The runtime does **not** execute every function body from top to bottom when the file loads.

1. Lines 1–16 import built-in modules and initialize configuration and retry sets.
2. Function declarations make their functions available. Their bodies wait to be called.
3. Lines 458–463 detect a direct CLI invocation and call `runDownload()`.
4. `runDownload()` validates the environment configuration, then calls `downloadAll()`.
5. `downloadAll()` creates one shared requester, claims the output directory, writes an incomplete manifest, and starts the worker pool.
6. Each worker claims one window and calls `downloadWindow()`.
7. Each window repeats: obtain request admission → fetch/read a page, with retries when eligible → validate the next link and report data → reserve identifiers → write the page → follow the next cursor.
8. Each window reconciles its final counts before returning success.
9. The pool waits for all active workers. On overall success, it reconciles the run, writes the complete manifest to a temporary file, and replaces the incomplete manifest.
10. `runDownload()` prints the successful summary. On failure, the CLI catch prints a contextual error and sets exit code 1.

When a test uses `require('./part1.js')`, the `require.main === module` condition is false. Tests can use the exported helpers without initiating a download. The exported public helpers are listed at line 465; internal helpers are exercised indirectly through them.

```text
CLI/environment
      |
      v
runDownload -> downloadAll -> incomplete manifest
                    |
                    +--> worker A -> one window -> sequential cursor pages
                    +--> worker B -> one window -> sequential cursor pages
                    +--> worker C -> one window -> sequential cursor pages
                              |          |
                              +----------+--> shared requester/pacing/cooldown
                    |
                    v
       reconcile all windows and unique IDs
                    |
                    v
       write temporary completed manifest -> rename
                    |
                    v
              Python analysis
```

## A map of every function

| Function / code | Current lines | Responsibility |
|---|---:|---|
| Imports and constants | 1–16 | Built-in I/O, date bounds, request/retry policy |
| `checkDate` | 18–29 | Validate one real `YYYYMMDD` calendar date |
| `checkDates` | 31–38 | Validate both bounds and their order |
| `getWindows` | 40–52 | Build the 24 fixed assignment windows |
| `getConcurrency` | 54–60 | Parse and validate a positive safe integer |
| `getPageName` | 62–64 | Keep saved names and manifest names consistent |
| `getPageUrl` | 66–76 | Build the initial FDA query |
| `checkPage` | 78–109 | Validate one response's envelope and report identities/dates |
| `getNextUrl` | 111–168 | Extract and validate the server-provided cursor URL |
| `getRetryDelay` | 170–178 | Interpret a usable `Retry-After` delay |
| `isNetworkError` | 180–186 | Recognize known transport errors, including nested errors |
| `createRequester` | 188–243 | Create one shared pacing/retry closure |
| `waitUntil` (nested) | 193–198 | Wait until a deadline with timer-size protection |
| `waitForStart` (nested) | 200–210 | Serialize request admission, not HTTP fetching |
| `requestPage` (returned closure) | 212–242 | Retry one page under shared request policy |
| `fetchPage` | 245–280 | Perform and decode one HTTP attempt |
| `downloadWindow` | 282–357 | Exhaust one cursor chain and save validated pages |
| `downloadAll` | 359–448 | Run the pool and publish the completed manifest |
| `worker` (nested) | 391–412 | Claim windows, store results, and record the first failure |
| `runDownload` | 450–456 | Connect environment configuration to the downloader |
| CLI guard and exports | 458–465 | Keep imports safe and CLI failures visible |

## Walkthrough: configuration and small validation helpers

### Lines 1–16: what is configured and why

- **Line 1:** destructures promise-based `mkdir`, `writeFile`, and `rename` from Node's filesystem API. They can be awaited, so asynchronous filesystem I/O fits the same control flow as HTTP requests.
- **Line 2:** aliases the promise version of `setTimeout` to `sleep`. Unlike callback-style `setTimeout`, `sleep(milliseconds)` returns a promise suitable for `await`.
- **Line 3:** imports `path` so default filesystem paths work across operating systems.
- **Line 5:** fixes the food adverse-event endpoint. Pagination links must return to this same origin and pathname.
- **Lines 6–7:** hold the assignment bounds as fixed-width strings. These dates are a scope choice documented in the notes, not a “current year” calculation.
- **Line 8:** sets the requested page limit to 100. The request parameter is always 100; an actual page can contain fewer than 100 reports. Saying “every response contains exactly 100 records” would be incorrect.
- **Line 9:** makes each network attempt subject to a 30,000 ms timeout. This does not cap the entire download or include time waiting for admission/backoff.
- **Line 10:** requires at least 300 ms between request admissions in this process.
- **Line 11:** permits three retries after the original attempt: four attempts total.
- **Line 12:** lists HTTP statuses treated as temporary: 408, 429, 500, 502, 503, 504. The `Set` provides direct membership checks and communicates that status order is irrelevant.
- **Lines 13–16:** enumerate recognized DNS, connection, socket, and Undici transport codes. Node's built-in fetch can wrap a useful error code inside another error; `isNetworkError` handles that later.

**Decision basis:** the exact assignment in the shared conversation requires **Node.js**, **`limit=100`**, and a configurable **`CONCURRENCY_LIMIT` defaulting to 3**. The yearly partitioning, standard-library-only implementation, 300 ms pacing, and retry defaults are implementation choices. UTC validation, preserving JSON values, optional environment key, and no key-containing URL logging are recorded in `REVIEW_NOTES.md:77–100`; pacing/retry reasons appear at `315–334`. HTTP 408 was added in the final audit and is present in the current code (`REVIEW_NOTES.md:923–925`; commit `dc44199`).

### `checkDate`, lines 18–29

1. **Lines 19–21:** require a string of exactly eight digits. This rejects numbers, separators, trailing text, and malformed widths before date parsing.
2. **Lines 23–24:** turn `20240229` into `2024-02-29T00:00:00Z`. The `Z` specifies UTC, keeping local timezones out of validation.
3. **Lines 25–27:** check for an invalid date and compare the parsed date back to the original calendar text. Some impossible inputs normalize into a later day. Merely obtaining a `Date` object would therefore be insufficient. February 30 must fail rather than silently becoming a March date.
4. Successful validation returns implicitly with `undefined`; this is a guard function, not a conversion function. The caller continues to use the original string.

**What to say:** “I check syntax first, then real calendar validity. Once a date is a valid, fixed-width `YYYYMMDD` string, lexicographic comparisons have chronological meaning.”

### `checkDates`, lines 31–38

- **Lines 32–33:** validate the start and end individually.
- **Lines 34–37:** reject a start later than the end. Equality is allowed, so a one-day window is valid.
- A range such as `20240230` through `20240301` cannot slip through merely because its strings are in order: `checkDate` rejects the first bound before comparison.

### `getWindows`, lines 40–52

- **Line 41:** starts the array.
- **Line 42:** reads 2002 from `defaultStart`.
- **Line 43:** reads 2026 from `defaultEnd`, then subtracts one to make 2025 the last loop year.
- **Lines 44–49:** create one entry per year from 2002 through 2025, inclusive. Ordinary entries run January 1 through December 31. The last entry runs `20250101` through `20260101`, retaining the exact inclusive upper bound.
- **Line 51:** returns 24 windows: 23 ordinary full calendar years for 2002–2024, plus the final extended 2025 window.

Adjacent windows do not overlap. The 2024 window ends `20241231`; the next starts `20250101`. January 1, 2026 occurs only in the final window. The documented date-coverage test counted 8,767 included days (`REVIEW_NOTES.md:247–250`).

**Why yearly windows?** Each window starts an independent cursor chain. That supplies useful parallel work without trying to guess the next cursor inside one chain. Yearly boundaries are also easy to inspect. They are not equally sized by report count, so this is simple partitioning rather than optimal load balancing.

**The workload-imbalance discussion actually happened:** in the shared project conversation, Abdul asked whether more or fewer date windows would be more efficient. The discussion identified the possibility of one worker remaining busy with a large window after the others finish. The shared next-window index improves utilization compared with permanently assigning each worker a static set of years: whichever worker finishes first claims the next unstarted window. However, it cannot split a window that is already being processed, so the last large window can still become a straggler. Monthly partitions and targeted splitting were considered, and Abdul chose to “put a pin on that for now.” This is a documented deferred optimization. The assigned default of three workers and the chosen year-based task granularity are separate decisions.

**A grounded answer to Alex:** “I noticed the possible last-window bottleneck. A shared queue avoids leaving a worker idle while unstarted windows remain, but it does not eliminate an unusually large final window. I kept the yearly partitioning for this version and deferred finer splitting. I would first measure whether the bottleneck is uneven window work, API latency, or the shared pacing limit; splitting further would not remove the 300 ms request-start limit.”

**Precise limitation:** this helper is tailored to the hardcoded bounds. It is not a general date-partitioning utility. Changing only the constants to arbitrary midyear dates would require redesigning and testing this function; its initial start always uses January 1 and its last loop year assumes the current upper-bound arrangement.

### `getConcurrency`, lines 54–60

- **Line 54:** the default parameter supplies `3` only when the argument is `undefined` or absent. `null` does not trigger a JavaScript default parameter.
- **Line 55:** converts a string only if its trimmed form contains digits exclusively. `" 3 "` and `"003"` become 3. `"3abc"`, `"3.5"`, `"+3"`, and `"1e3"` are rejected rather than partially parsed.
- **Lines 56–58:** require a safe integer greater than zero. `0`, negative numbers, fractions, `NaN`, and extremely large unsafe integers fail.
- **Line 59:** returns the validated number. Later, actual workers are capped at the number of windows. Setting 30 does not create 30 workers for 24 windows.

**Why not `parseInt`?** `parseInt('3abc', 10)` accepts an invalid configuration as 3. Configuration errors should be obvious before filesystem or network activity begins.

### `getPageName`, lines 62–64

`String(pageNumber).padStart(6, '0')` produces names such as `page-000001.json`. Padding keeps ordinary filename sorting in page order for this dataset. The same helper builds actual page filenames and final manifest entries, preventing two separate naming rules from drifting. Six digits are a minimum width, not a maximum number of pages.

### `getPageUrl`, lines 66–76

- **Line 67:** validates bounds before constructing a query.
- **Line 68:** creates a `URL` object for the fixed endpoint.
- **Line 69:** uses an inclusive FDA range query: `date_started:[20020101 TO 20021231]`, for example.
- **Line 70:** sets `limit=100`.
- **Line 71:** requests ascending `date_started` order.
- **Lines 72–74:** include an API key only if a truthy value was supplied.
- **Line 75:** returns a URL object. `URLSearchParams` handles encoding of spaces, brackets, and other special characters; string concatenation would make encoding and validation easier to get wrong.

The code does not invent a tie-breaking cursor from dates. Multiple reports may share the same date, so jumping to a later date risks losing reports. The server supplies continuation state through its cursor.

## Walkthrough: validating the API contract

### `checkPage`, lines 78–109

This function validates the minimum ingestion contract. It does not validate every clinical or analytical field.

1. **Line 79:** validate the requested bounds again so this exported validator is safe to call directly.
2. **Lines 80–82:** require a non-null response with a `results` array. Successful HTTP status alone does not make the response usable.
3. **Lines 83–85:** reject an oversized page. An empty array is structurally allowed here.
4. **Lines 87–90:** extract `meta.results.total` with optional chaining and require a safe integer at least as large as the current page length. Since page length is nonnegative, this also rejects negative totals.
5. **Lines 92–93:** create a temporary set for identities on this page.
6. **Lines 94–99:** iterate over reports and require each `report_number` to be a nonempty string. The whitespace check establishes nonemptiness; IDs are still stored and compared in their original string form.
7. **Line 100:** validate the report's actual calendar date.
8. **Lines 101–103:** reject reports outside either inclusive window boundary.
9. **Lines 104–107:** reject repeated report numbers within the same page, then record each accepted ID.

**What it intentionally leaves for other layers:** cross-page/run duplicates, stable window totals, and completeness belong to `downloadWindow`/`downloadAll`. Consumer age, outcomes, reactions, and products belong to the analysis validation/hygiene layer. Downloading raw data should not silently throw away a report because its age is missing.

**Do not overclaim:** this validator does not verify that results are actually sorted ascending, nor does it validate every metadata field. It requests the sort and checks the dates, identifiers, page size, and total it needs for ingestion.

### `getNextUrl`, lines 111–168

The key idea: a server-provided URL is input that still needs validation. The code follows the FDA's opaque cursor while checking that the continuation remains part of the original query.

- **Lines 112–114:** no Link header means no continuation URL.
- **Lines 116–120:** split the header into entries at comma boundaries before `<`, extract each `<URL>` and its parameters, and find its `rel` parameter. The regular expression accepts quoted or unquoted relations and case-insensitive `rel` spelling.
- **Lines 121–123:** malformed entries fail explicitly, even if the malformed entry is not the next relation. This is intentionally strict parsing, not a universal Link-header library.
- **Line 124:** lowercase relation tokens and split their whitespace. A relation field may contain multiple tokens.
- **Lines 125–127:** skip valid entries that do not have the `next` relation.
- **Lines 128–130:** reject two different `next` entries rather than arbitrarily choose one.
- **Lines 131–135:** require a parseable absolute URL, reporting a clear next-page error otherwise.
- **Lines 137–139:** a valid header with only non-next relations means pagination has ended.
- **Line 141:** reconstruct the expected initial query for comparison.
- **Lines 142–145:** require the same origin and pathname, with no username, password, or fragment. This stops continuation from changing the endpoint or introducing URL credentials.
- **Lines 146–151:** require exactly one `search`, one `limit`, and one `sort`, each equal to the original decoded value. Checking `getAll(...).length` rejects repeated/ambiguous parameters. Query-parameter order may change without failing because comparisons use parsed parameters.
- **Lines 152–155:** require exactly one nonempty `search_after` value. Its internal format is not interpreted.
- **Lines 156–160:** accept an optional single `skip=0` because the FDA's cursor links can contain it. Reject nonzero skip and repeated skip values. The code is not using offset pagination.
- **Lines 161–163:** reject a `count` parameter because aggregate counts are not report pages.
- **Lines 164–166:** overwrite the key parameter with the configured key when present, preserving authentication across pages.
- **Line 167:** return the validated URL.

**Boundary of protection:** this checks required parameters and certain prohibited ones; it is not a blanket allowlist rejecting every possible extra query parameter. The same-endpoint check and `redirect: 'error'` in `fetchPage` work together: validation cannot be bypassed by automatically following an HTTP redirect to another destination.

**What to say:** “I let the server define the continuation cursor, but I verify that its URL still represents the exact search and page size I started. I track previously used cursor values to detect loops. I don't assume a short page or the last date means the chain is finished.”

## Walkthrough: request scheduling, timeouts, and retries

### `getRetryDelay`, lines 170–178

- **Line 171:** trim the header or use an empty string when it is absent.
- **Lines 172–174:** handle date-form values as GMT, including older HTTP-date forms without an explicit timezone suffix.
- **Lines 175–176:** all-digit values become whole seconds converted to milliseconds. A value beginning like an HTTP date is parsed and converted into a delay relative to the supplied `now`. Other input yields zero.
- **Line 177:** return only a positive safe-integer delay. Invalid, past, zero, fractional numeric, non-finite, or out-of-range values fall back to zero. The requester will still use its local exponential backoff.

Examples: `Retry-After: 5` supplies 5,000 ms; `Retry-After: 0.5` supplies no usable server delay under this parser. A future HTTP date supplies the remaining time until that date. This uses the machine's clock, so production-grade clock handling and a total job deadline would be possible improvements.

### `isNetworkError`, lines 180–186

- **Lines 181–183:** a missing error is not a network error.
- **Lines 184–185:** accept a recognized `error.code`, recursively inspect its `cause`, or inspect the members of an `AggregateError`.
- JavaScript's `||` short-circuits from left to right: once any branch proves a recognized network error, later branches need not execute.

**Why inspect causes?** A top-level fetch `TypeError` may wrap a meaningful transport error. Retrying every `TypeError` would also hide programming mistakes. The explicit code set makes the retry policy narrower and explainable.

### `createRequester`, lines 188–243: the closure

**Line 188** accepts injectable dependencies with real defaults:

| Dependency | Default | Why injection helps |
|---|---|---|
| `fetchData` | `globalThis.fetch` | Supply deterministic offline responses/errors |
| `now` | `Date.now` | Advance a fake clock without waiting minutes |
| `wait` | Promise-based `sleep` | Record/simulate waits |
| `random` | `Math.random` | Make jitter deterministic in tests |
| `log` | `console.warn` | Assert messages or avoid noisy tests |

**Lines 189–191** create the shared state captured by the returned function:

- `queue` starts as a resolved promise. It chains admission turns in order.
- `nextStart` is the earliest time the next request may start under ordinary pacing.
- `cooldown` is the earliest time any subsequent request may start after a 429.

Calling `createRequester()` once returns a function that continues to reference those same variables. Calling it separately for every worker would create separate gates and lose global pacing. `downloadAll` passes **one shared instance** into all windows.

### Nested `waitUntil`, lines 193–198

The loop keeps waiting until the clock reaches the deadline. A single wait is capped at 2,147,483,647 ms because Node's timer representation cannot safely accept arbitrary huge intervals. Long valid server waits are split into chunks instead of overflowing into an immediate timer. Rechecking the clock also handles early timer wakes.

There is no configured overall job deadline. Four attempts are bounded; total elapsed time is not strictly bounded when a valid server delay can be very long.

### Nested `waitForStart`, lines 200–210

1. **Line 201:** append an async admission turn to the previous queue promise.
2. **Lines 203–205:** wait until both ordinary spacing and shared cooldown permit a start. `Math.max(nextStart, cooldown)` chooses the stricter deadline.
3. The outer `while` matters: another worker can extend `cooldown` while this turn sleeps. Waking for the old deadline does not automatically grant admission.
4. **Line 206:** after admission, set the next start to `now() + 300`, based on the actual current time. A delayed event-loop wake does not release several missed slots as a burst.
5. **Line 208:** store a caught version of the turn as the next queue anchor, so one rejected admission does not permanently poison all later queue turns.
6. **Line 209:** return the original turn to this caller so its own admission error is still visible.

**Most important detail:** the queue contains the waiting/admission work, **not the fetch**. Once admitted, the worker fetches outside the queue while another admission turn can wait for its next slot. Wrapping the entire fetch inside the chained turn would accidentally serialize network requests.

At 300 ms spacing, the theoretical sustained admission ceiling is about 3.33 starts/second, or 200/minute, before HTTP latency and worker availability make it slower. This is a process-local pacing policy; it neither tracks a daily budget nor accounts for other processes or other users sharing a key/IP.

### Returned `requestPage`, lines 212–242

1. **Line 213:** use attempts 0, 1, 2, 3. The `<= maxRetries` condition means four attempts, not three.
2. **Line 214:** each attempt, including retries, must pass the shared gate.
3. **Lines 215–216:** only after admission, create a fresh timeout signal for this attempt. Time spent queued is not deducted from its 30-second request budget.
4. **Lines 217–218:** await `fetchPage`. A successful return immediately exits the retry loop with decoded data and Link information. The response body is read within this operation; the signal is not discarded as soon as response headers arrive.
5. **Line 220:** recognize `TimeoutError`, or an `AbortError` when this attempt's signal has aborted.
6. **Line 221:** if an HTTP status is available, classify it using the status allowlist. Otherwise use timeout/transport classification. A known permanent status does not become retryable just because its signal later expires during cleanup.
7. **Lines 222–225:** cancel an unused error-response body if present, swallow cleanup rejection, then rethrow permanent failures.
8. **Line 226:** choose the larger of local exponential backoff plus jitter and a valid server `Retry-After` delay. With default randomness, backoff begins at 1,000–1,249 ms, then 2,000–2,249 ms, then 4,000–4,249 ms.
9. **Line 227:** record an absolute retry deadline.
10. **Lines 228–230:** for 429 specifically, extend the shared cooldown immediately. Other temporary failures back off only their own worker.
11. **Line 232:** cancel the unused HTTP error body after publishing that cooldown. Body cleanup can be asynchronous, so publishing first prevents queued workers from ignoring a known rate-limit signal while cancellation waits.
12. **Line 233:** select a safe description for logging: status, timeout, or network failure. The URL and API key are not logged.
13. **Lines 234–236:** on attempt 3, throw a contextual exhaustion error with the original error as its `cause`. There is no fifth request and no fourth retry. The delay/cooldown was still calculated first so an exhausted 429 can protect the other workers that are draining.
14. **Line 237:** log the upcoming retry number and minimum wait.
15. **Line 239:** wait outside the admission queue. After this wait, the loop returns to line 214, so the retry must also satisfy current global pacing/cooldown.

**Why retries don't duplicate disk pages:** this loop encloses one network response operation only. Validation and writing happen in `downloadWindow` after the requester returns successfully. A failed attempt does not increment the page number or write a partial API response as a successful page.

**Why safe to retry GET?** Reading the same cursor URL is an idempotent retrieval operation with respect to intentional server-side mutations. This does not mean the live dataset is immutable or that every response is guaranteed byte-for-byte identical.

### `fetchPage`, lines 245–280

- **Lines 246–250:** call the injected fetch with `Accept: application/json`, the timeout signal, and automatic redirects disabled. This makes exactly one HTTP attempt.
- **Lines 251–257:** most unsuccessful HTTP statuses become an error carrying status, `Retry-After`, and the original response. The requester uses those properties for classification and cleanup. 404 is handled separately because the FDA uses a specific 404 payload for no matches.
- **Lines 259–270:** parse the body as JSON. An actual `SyntaxError` gets an explicit invalid-JSON message. A body timeout or network interruption is rethrown with its own type, so it remains eligible for the right retry policy. Malformed JSON is not treated as a temporary transport error.
- **Line 272:** extract the Link header after reading the body.
- **Lines 273–277:** for the remaining unsuccessful response (404), require exactly `error.code === 'NOT_FOUND'` and `error.message === 'No matches found!'`. Only that recognized payload becomes `noMatches: true`. An arbitrary 404, invalid JSON 404, or unrelated error is not accepted as an empty window.
- **Line 279:** ordinary successful responses return `noMatches: false`, even if their JSON is `null`. A null successful payload later fails `checkPage`; it cannot masquerade as an empty result.

The separation is deliberate: `fetchPage` handles one HTTP/JSON attempt; `requestPage` handles timing and retry policy; `downloadWindow` handles report validity, pagination, and persistence.

## Walkthrough: one complete window

### `downloadWindow`, setup, lines 282–300

- **Lines 282–290:** accept an options object. The defaults use the fixed bounds, a matching folder beside the script, the built-in fetch, a requester around that fetch, and a private ID set when no shared set is supplied.
- With `downloadAll`, the caller supplies the date window, output folder, **shared** requester, and **shared** run-wide IDs, so the standalone requester/set defaults are not used.
- **Line 291:** validate/build the first URL before creating directories or making a request.
- **Line 293:** ensure the parent folder exists. Recursive creation is appropriate for parents that may legitimately exist.
- **Line 294:** create the actual window folder without recursive mode. If it already exists, fail immediately. This claims fresh output before network access rather than mixing this run with old pages.
- **Lines 296–300:** initialize the set of successfully saved window IDs, the set of already used cursors, unknown total (`null`), saved-report count, and successful-page count.

`null` for unknown total is different from zero reports. Zero is a valid established total for an empty window.

### `downloadWindow`, iteration, lines 302–350

1. **Line 302:** continue while a URL remains. Continuation is controlled by validated cursor links, not page length or the last record's date.
2. **Line 303:** remember the current decoded `search_after` parameter. The first URL has no cursor, so the set initially contains `null`.
3. **Line 304:** request this page, with a label based on the window and the next successful page number. Retries happen inside this await and retain the same URL/page label.
4. **Line 305:** validate/parse the next Link before saving anything from this response.
5. **Lines 306–308:** if the returned next cursor has already been used, fail rather than loop forever. Comparing parsed parameter values makes URL parameter reordering or equivalent encoding irrelevant to the cursor check.
6. **Lines 310–318:** handle the explicit no-match response. A next link would contradict no matches and is rejected. If no total was ever established, set it to 0. Otherwise retain the previous expected total. End the chain and continue to final reconciliation without writing this error payload as a report page.
7. **Line 320:** validate the successful page's basic contract.
8. **Lines 321–325:** establish the window total on the first page and require it to remain unchanged on later pages. Detectable changes mean this run cannot be confidently reconciled.
9. **Lines 326–328:** reject a page that would push the saved count beyond that total.
10. **Lines 329–331:** reject an empty successful page that claims a continuation. A nonempty short page can still have a next link and must be followed.
11. **Lines 332–339:** check every report against the successfully saved window set and the run-wide reserved set. A repeated ID is an error to investigate, not silently discarded. The local check provides a more specific cross-page error before the global check.
12. **Lines 340–341:** reserve all this page's IDs in the shared set **before awaiting a write**. There is no await between checking and reserving, so another JavaScript worker cannot interleave a conflicting acceptance.
13. **Line 343:** choose the next sequential filename.
14. **Lines 344–345:** stringify the entire response envelope and exclusively create the file using `flag: 'wx'`. The `w` writes; the `x` requires that the file not already exist. This catches a surprise collision even after the fresh-folder check.
15. **Lines 346–348:** only after the write succeeds, mark the IDs as saved within this window and increment report/page counts. Reserved and saved are intentionally distinct states.
16. **Line 350:** move to the validated next URL, including when the page is short or already contains reports at the ending date.

**If a write fails:** global reservations remain, but local saved counts do not advance. The whole run is failing and does not support resume, so removing reservations would add complexity without restoring a valid run. A filesystem error can leave a partial file; the completion marker prevents that output from being analyzed as a successful snapshot.

### `downloadWindow`, completion, lines 353–357

Require both the number saved and the local unique-ID count to equal the established API total. Then return `{ outputDir, savedCount, total, pageCount, complete: true }`.

These are two complementary kinds of evidence: the cursor chain is exhausted, and observed identities/counts reconcile. Neither substitutes for the other. A missing next link can leave 100 saved out of 250 expected; a full count can still be followed by a contradictory or looping cursor.

A standalone call to `downloadWindow()` returns a completed **window** summary and does not publish a whole-run manifest. `downloadAll()` owns that responsibility.

## Walkthrough: the worker pool and completed manifest

### `downloadAll`, setup, lines 359–389

- **Lines 359–365:** the default output root is `data` beside `part1.js`; concurrency defaults to three. The requester default is evaluated once for this call and shared with all workers.
- **Line 366:** validate the worker limit before writes.
- **Line 367:** construct the fixed windows.
- **Lines 368–369:** create the parent path if needed, then exclusively claim a fresh root directory. Even an existing empty `data` directory is refused.
- **Lines 371–382:** build the initial manifest: schema version, incomplete status, date bounds, start time, requested page size, configured concurrency, count of windows, and planned windows.
- **Lines 383–384:** write that incomplete manifest before starting workers. Ordinary failure/interruption afterward leaves a clear `complete: false` marker. If even this initial write fails, a missing/malformed manifest still cannot authorize analysis.
- **Line 386:** create the run-wide ID reservation set.
- **Line 387:** allocate one result slot per original window.
- **Line 388:** initialize the shared next-window index.
- **Line 389:** initialize the first-failure marker.

The manifest is a small inventory/contract between stages. It does not embed the report IDs, raw reports, credentials, or absolute local paths. Successful final paths are portable relative filenames.

### Nested `worker`, lines 391–412

1. **Line 392:** continue only while no failure has been observed and unclaimed windows remain.
2. **Lines 394–395:** claim the current index and increment it synchronously, before the first await. In one JavaScript event loop, another worker cannot interrupt halfway through this synchronous claim.
3. **Line 396:** find the assigned window.
4. **Lines 398–404:** await its entire download and save its summary at the original index. Object spread copies its date fields; subsequent properties provide its output folder, key, shared requester, and shared IDs.
5. **Lines 405–409:** on failure, retain the first failing window/error and stop this worker. Other failures do not overwrite the initial diagnostic.
6. After a successful window, the loop checks `failure` again before claiming another. Already active windows are allowed to finish all their pages; they do not check this flag inside `downloadWindow`.

**This is asynchronous concurrency, not three JavaScript threads.** Network and filesystem waits overlap. Synchronous JavaScript steps such as claiming an index and reserving IDs run without another worker's JavaScript interleaving until an await/yield.

**Why catch inside workers?** The chosen behavior is to let active windows drain and then fail. Worker promises therefore settle normally after recording errors, allowing `Promise.all` to wait for all of them. If those rejections escaped immediately, `Promise.all` would reject on the first one without automatically cancelling the other operations.

### Pool startup and failure, lines 414–420

- **Line 415:** create `min(limit, windows.length)` worker promises. Calling `worker()` starts each worker immediately up to its first await; constructing the array does not make them run one after another to completion.
- **Line 416:** wait for all workers to finish/drain.
- **Lines 417–420:** if any failed, throw an error that names the failing date window and preserves the original error as a cause. The final success path is skipped, leaving the manifest incomplete.

The statement “stop assigning new windows after failure” means after the shared flag is set/observed. A window already claimed before that moment is active work and can finish. This is not immediate cancellation, and a slow active window or long `Retry-After` can delay the final error report.

### Final reconciliation and manifest publication, lines 422–448

1. **Lines 422–424:** sum the saved records, expected API totals, and saved page counts from all successful windows. Three separate `reduce` passes are clear and inexpensive over just 24 entries.
2. **Lines 425–427:** require summed saved reports and run-wide unique IDs to equal the expected total.
3. **Line 428:** build the successful run summary.
4. **Lines 429–441:** construct the completed manifest. Later object-spread fields overwrite earlier values, so the summary's `complete: true` replaces the initial `false`. Add completion time, unique count, and per-window counts plus exact page paths generated from each successful page count.
5. **Lines 443–445:** exclusively write `manifest.json.tmp`. An unexpected existing temp file is preserved and causes failure rather than being overwritten.
6. **Line 446:** rename the fully written temporary file over the incomplete manifest. A reader observes the published manifest file rather than an in-place, half-written completed manifest under normal filesystem behavior.
7. **Line 447:** return success only after publication succeeds.

**Precise meaning of completion:** all observed cursor chains ended, every saved page passed the implemented validation, saved totals/IDs reconciled, and the final inventory was published. It does not establish an immutable upstream snapshot, cryptographic file integrity, or full power-loss durability. There are no page checksums, explicit disk flushes, or transaction spanning every page file. The notes explicitly distinguish these limitations (`REVIEW_NOTES.md:477–484`, `615–619`).

If the process stops after writing the temp manifest but before rename, the real `manifest.json` remains incomplete; the temp file alone must not authorize analysis. If publication itself fails, all pages may exist but the run still fails. That is intentional: success includes a reliable handoff to the next stage.

## Walkthrough: the CLI boundary, lines 450–465

- **Line 451:** parse `CONCURRENCY_LIMIT` from the environment. An absent variable arrives as `undefined` and uses the helper's default of three.
- **Line 452:** announce the fixed range and configured maximum requests. If the configured limit exceeds 24, actual worker count is still capped at 24; “up to” does not guarantee exactly the requested number of active requests.
- **Line 453:** call the full downloader with the optional environment API key. The script does not read a credential file itself.
- **Lines 454–455:** print counts and the saved directory only after successful completion/publication.
- **Lines 458–462:** run only when invoked directly, print a clear incomplete-output warning on failure, and set `process.exitCode = 1`. Setting the code allows the event loop to drain naturally rather than immediately killing the process with `process.exit(1)`.
- **Line 465:** export the intended testable helpers and orchestration functions. No `package.json` is required for this CommonJS script because it depends only on Node built-ins and directly runs with Node.

## Concrete traces worth practicing aloud

### Trace A: ordinary two-page window

Assume the API reports total 150.

1. First request has no cursor and `limit=100`. The script remembers `null` as its initial cursor marker.
2. Page 1 contains IDs 1–100 and a validated cursor `A`. Its total is 150.
3. Validate the page, reserve its IDs globally, save `page-000001.json`, then set saved count to 100.
4. Request cursor `A`. Page 2 contains IDs 101–150, still reports total 150, and has no next link.
5. Save page 2, set saved count to 150, and set `url = null`.
6. The loop ends. Saved count 150 and local unique count 150 both equal total 150, so the window succeeds.

### Trace B: a full final page followed by the FDA no-match response

Assume total 200 and a server-supplied cursor after page 2.

1. Save two full pages: saved count 200, unique count 200.
2. Follow the supplied next cursor even though the expected total has been reached.
3. Receive the exact FDA no-match 404 without a next link.
4. Preserve total 200, end the chain, and reconcile successfully. Only two report-page files are saved; the error payload is not a third page file.

If the same terminal response appeared after only 100 of 200 expected reports, it would end the chain but **fail** final reconciliation. If it were the first response of a genuinely empty window, the established total becomes zero and the window succeeds with zero page files.

### Trace C: short page at the upper date

Assume a page contains 40 records dated on the final day and has a valid next cursor. The code saves those 40 and follows the cursor. It does not jump dates, stop because the page is short, or assume there cannot be more reports on the same day. If the next page repeats an ID or the cursor loops, explicit checks fail the window.

### Trace D: three workers with normal request pacing

Assume each HTTP request takes 800 ms and all three workers are ready.

| Approximate time | What happens |
|---:|---|
| 0 ms | A passes admission and starts fetching |
| 300 ms | B passes admission while A remains in flight |
| 600 ms | C passes admission while A and B remain in flight |
| 800 ms | A receives its page, validates it, and begins saving |
| At least 900 ms | A can begin its next request if saving is complete and no cooldown applies |

This shows why there are two controls. The worker count limits overlap; spacing limits how rapidly requests start. If every response took 10 ms, three workers alone could send requests much faster than this API should receive. If responses are slower, overlapping waits helps use the allowed request rate.

### Trace E: temporary failure and the same cursor retry

Worker B's first request for cursor `Q` gets HTTP 503. With jitter mocked to zero and no useful `Retry-After`, it waits at least 1,000 ms. A and C can continue through the gate. B then re-enters admission and retries **cursor Q**, with a fresh timeout. If its second attempt succeeds, the caller validates and saves that page exactly once. Attempts 3 and 4 would be preceded by at least 2,000 and 4,000 ms of local backoff respectively. A fourth failure ends B's window.

### Trace F: global 429 cooldown

At time 1,000 ms, worker A receives `429` with `Retry-After: 5`. Its exponential delay would be roughly one second, but the server's five seconds wins. A immediately publishes cooldown 6,000 ms before error-body cancellation. A worker already asleep waiting for ordinary pacing wakes, rechecks the shared deadline, and waits until at least 6,000 ms. Requests already in flight are not retroactively cancelled. New admissions resume spaced by 300 ms, not all at once.

### Trace G: why IDs are reserved before `await`

Unsafe design: A checks ID `X` → A awaits disk → B checks `X` before A records it → both write `X`.

Current design: A checks the entire page and adds `X` to shared `runIds` without yielding → A awaits disk → B checks `X`, finds it reserved, and fails. If A's disk write then fails, the run is already incomplete. The reservation is not proof of a successful disk write; the local saved set/count is.

### Trace H: failure with other windows active

A permanently fails. Its worker sets the shared failure flag. B and C are already inside their windows; they continue their cursor chains and can still retry. When they complete, their worker loops see the failure flag and claim no further windows. `Promise.all` finishes only after they drain, then `downloadAll` throws A's contextual error. No completed manifest is published.

## Complexity and performance without hand-waving

Use `N` for reports, `P` for successfully retrieved report pages, `W` for windows (24 here), `C` for active workers, and `B` for total JSON bytes processed.

- **Date validation and fixed-size settings:** effectively constant time for each fixed-width date/configuration value.
- **Per-page validation:** O(number of reports on the page), with expected constant-time `Set` membership. It is bounded by 100 reports per valid response, plus parsing/serialization proportional to page bytes.
- **Run CPU work:** expected O(N + B + P + W). Parsing and writing full records are unavoidable because every report must be retained. Claims of O(1) overall are incorrect merely because pages are small.
- **Network requests:** approximately the sum of `ceil(windowReports / 100)` across nonempty windows, plus empty/terminal no-match requests and retries. Window partitioning can add partially filled pages compared with one large query. The completed snapshot records 987 saved page files; that count alone is not proof of exactly 987 HTTP attempts.
- **Memory:** O(N) identifiers for the global set, plus saved-ID sets for currently active windows, cursor history for active windows, and approximately C page payloads/in-flight operations. The entire raw dataset is not retained in memory at once, but the global identity audit means the downloader is **not constant-memory streaming**.
- **Manifest size:** O(P + W) filenames/count metadata, rather than O(N) report contents.
- **Disk:** O(B) for retained raw JSON, plus the comparatively small manifest.
- **Elapsed time:** constrained by both HTTP latency/concurrency and shared admission spacing. Even infinitely many workers cannot defeat the 300 ms spacing. More workers eventually stop helping and can increase pressure on the source.

For roughly 987 requests with no extra attempts, spacing alone implies about `(987 - 1) × 0.3 = 295.8` seconds between the first and last request starts. The current manifest records a start of **2026-09-04T18:24:34.942Z** and completion of **2026-09-04T18:29:41.824Z**, an elapsed **306.882 seconds**, consistent with pacing being a major factor. Treat the spacing comparison as an explanatory approximation: page files are not an exact request log, and filesystem/latency work adds time. The review notes contain conflicting 22:24/22:29 UTC timestamps; use the current manifest's timestamps when describing this committed snapshot.

For the last-window case, one remaining worker has approximate steady-state throughput bounded by `1 / max(0.3 seconds, per-page network/validation/write time)` when there are no retries. With multiple active workers, overlapping I/O can raise aggregate throughput toward the shared cap of about 3.33 starts/second. A lone worker cannot overlap its own cursor requests; however, if each page finishes in less than 300 ms, the pacing cap already dominates and extra workers or smaller windows have little room to improve throughput. This distinction makes the deferred load-balancing decision measurable rather than speculative.

## What was required, chosen, and inferred

| Item | Evidence category | Defensible explanation |
|---|---|---|
| Node.js for Part 1 | Exact assignment requirement in shared conversation | Use the required runtime; built-in APIs keep the implementation dependency-free |
| Inclusive fixed range and `limit=100` | Recorded scope/requirements | Honor the supplied retrieval bounds and page-size requirement |
| Raw JSON committed under `data` | Confirmed scope in notes | Deliver a local reusable snapshot for review and analysis |
| 24 year-based partitions | Explicit implementation choice | Supply independent cursor chains and easy-to-audit boundaries |
| Configurable `CONCURRENCY_LIMIT`, default 3 | Exact assignment requirement in shared conversation | Respect the required default and expose the required configuration; the worker-pool design implements that contract |
| Shared queue, with finer splitting deferred | Documented discussion and deferral in shared conversation | Let free workers claim unstarted years while acknowledging that the last large window can still dominate |
| 300 ms start spacing | Explicit implementation choice | Control request frequency independently from concurrency |
| Three retries, 30-second per-attempt timeout | Documented implementation policy | Recover from recognized temporary failures while preventing endless attempts |
| Strict IDs/date/count validation | Documented decision | Detect contradictory or incomplete data instead of silently suppressing it |
| Retain full JSON response envelopes | Documented decision | Keep raw source values for later analysis and inspection |
| Manifest with initial incomplete marker | Documented implementation choice | Give the analysis stage an explicit completion contract |
| No resume or overwrite | Documented scope decision | Prevent mixed runs while keeping the implementation understandable |
| Standard-library-only JavaScript | Documented decision | The required HTTP, timing, filesystem, and testability capabilities already exist in Node |
| Why not a queue service/database/framework | Inference, not a recorded rejected proposal | For a one-off fixed-range local exercise, those would add deployment/state complexity beyond the demonstrated needs |

Do not claim a personal thought process that the notes never recorded. A good phrasing for the final row is: “Looking at the scope, I would defend the simpler local approach because ...” rather than “I evaluated and rejected three queue products” if that did not happen.

## How the implementation evolved, backed by commits and notes

| Step | What changed | Why this sequence is defensible |
|---|---|---|
| `93d4545` — first-page ingestion | Valid query, basic envelope/report checks, timeout, exclusive JSON save, importable functions | Establish a small end-to-end path before combining paging and concurrency |
| `5bc501b` — complete one window | Follow validated cursors, recognize terminal no-match response, detect duplicates/changed totals, reconcile completion | Prove one sequential chain before adding parallel chains |
| `ee093ce` — concurrent ingestion | 24 windows, configurable worker pool, ordered summaries, first-failure/drain behavior | Add concurrency around the already defined window operation |
| `e24ce99` — resilient ingestion and snapshot | Retry/pacing behavior, shared identity audit, completion manifest, downloaded dataset | Add failure-handling/completion evidence before expensive ingestion |
| `dc44199` — analysis/visualization and final audit | Add final analysis deliverables; Part 1 also adds HTTP 408 retry handling | Close the full pipeline and fix an identified retry-policy omission |

`REVIEW_NOTES.md` records finer-grained slices than the commit history, so a slice and a commit are not always one-to-one. Its beginning is explicitly an older first-page checkpoint. Historical phrases such as “no retries yet,” “no live request yet,” “README unchanged,” and the last audit's “working-tree changes” must not be read as current status: the final code includes those features and HEAD commits the finished implementation.

The notes also record a useful debugging story: a concurrency test asserted exactly three overlapping requests after only one event-loop yield, sometimes observing two instead. The fix was a shared promise barrier that held the first three mock requests until all arrived. That fixed an uncontrolled timing assumption in the test, not a production scheduling bug (`REVIEW_NOTES.md:400–415`).

## Material limitations to own in a review

1. **No immutable source snapshot:** totals and unique IDs detect several failure modes, but a live upstream update that preserves counts and avoids duplicates may escape detection. The committed output is a fixed local snapshot from its recorded run, not a guarantee about FDA data today.
2. **No resume:** output directories must be fresh. A failed run preserves artifacts for inspection and requires a new clean destination for another run. Adding resume requires defining how to verify prior files, recover cursors, restore ID state, and handle source changes.
3. **No post-download hashes or durable transaction:** final manifest replacement publishes completion cleanly, but later same-count edits may not be detected and there is no explicit power-loss durability guarantee.
4. **Global O(N) identifier memory:** acceptable for about 98,000 reports; a much larger dataset may justify a disk-backed uniqueness index or database constraint.
5. **Process-local request policy:** pacing does not coordinate with multiple processes or enforce daily quotas. A server rate-limit response remains possible.
6. **No global run deadline or immediate cancellation:** attempts are bounded, but server delays and drain-on-failure can make elapsed time long.
7. **Fixed partitioner and strict API assumptions:** the dates, page policy, endpoint, no-match payload, and next-link rules intentionally match the documented contract. Generalizing requires tests and explicit decisions.
8. **Validation is scoped:** ingestion checks identity/date/envelope/completeness, while Python checks analysis structure and cleans ages/terms. Neither stage proves reports are medically accurate or establishes causal relationships.

Reasonable production follow-ups would be checkpoint/resume design, persisted uniqueness constraints, file hashes, structured request/progress metrics, an overall deadline/cancellation policy, quota coordination across instances, and immutable/versioned dataset handling where the source supports it. Present these as prioritized future work, not features already implemented.

## Oral questions this walkthrough should make answerable

- “What happens from `node part1.js` to the first network call?” — Explain the CLI guard, configuration validation, fresh root, incomplete marker, worker claim, fresh window folder, and shared request gate in that order.
- “Are three workers the same as three requests per second?” — No. Concurrency limits simultaneous work; 300 ms pacing limits request-start frequency.
- “Why not fetch all pages in `Promise.all`?” — The next cursor is only known after receiving the prior response. Parallelism comes from independent date windows, not guessed continuation positions.
- “What if one worker has the largest remaining year?” — The shared queue prevents idle workers while unstarted windows remain, but it cannot split the last active cursor chain. Finer partitions were discussed and deferred; measure against the shared pacing cap before increasing complexity.
- “Why isn't the fetch inside the promise queue?” — That queue serializes admission only; including fetch would serialize HTTP work and defeat overlap.
- “What happens if a retry fails four times?” — Four attempts total, no fifth. The worker records failure, active windows drain, and the completed manifest is never published.
- “Why does a 404 sometimes mean success?” — Only the exact FDA no-match payload without a continuation can terminate a chain, and final saved/unique counts must still match the established total.
- “Could a short page have another page?” — The code allows that and follows the supplied cursor. Page length is not its termination condition.
- “Why reserve IDs before the write?” — Checking before await but recording after await lets another worker accept the same ID during disk I/O. Synchronous reservation closes that gap within this process.
- “Why keep both window and global ID sets?” — Window sets represent successful saves and support per-window reconciliation/context; the global set prevents duplicates across active windows before writes yield.
- “What does `complete: true` really prove?” — Completion of the observed chain/validation/count contract and successful publication, not immutable upstream truth, checksummed storage, or crash-proof transactions.
- “Why can every JSON page exist but the run still fail?” — Publishing the final manifest is part of the success contract. If it fails, Python must not assume the directory is ready.
- “What is the memory complexity?” — O(N) because of run-wide identifiers, even though raw report data is processed one page per active worker.
- “How would you prove concurrency in a test?” — Hold the first C mocked requests behind a barrier until all arrive; check the overlap/cap at each start; then release them under a bounded test timeout.
- “What would you change first for a recurring production pipeline?” — Start with explicit resume/checkpoint and source-version semantics, then persisted identity/hash verification and operational metrics; choose priorities from failure cost, scale, and freshness requirements.
