# USAN FDA Pipeline — Code Review Handbook

Prepared for Abdul-Rahman Sayed, September 6, 2026. Reviewed source: commit `dc44199`, with 465 lines in `part1.js` and 512 lines in `part2.py`. The application source and saved dataset were not changed for this preparation.

This handbook has three sections: **understand the code**, **practice the review**, and **memorize the essentials**. The HTML edition includes navigation and the full numbered source so you can move from an explanation to the relevant code. Use the shorter answers aloud; use the deeper explanations to recover the reasoning when Alex follows up.

You do not need to perform a dramatic recital of 977 lines of code. You do need to know what each layer promises, how the program enforces that promise, and where the promise stops.

The speaking pattern comes from your **Career Handoff and Resume Review** conversation: answer the question, provide one useful example or result, then stop. The answers below are suggested wording, not a script or a claim that Alex will ask these exact questions. A VP reviewing this project could reasonably probe requirements, reliability, data meaning, tradeoffs, testing, and ownership of AI-assisted work.

## How the evidence is used

- **Actual history:** the [shared project conversation](https://chatgpt.com/s/cx_6a9b429a2c508191a790f06634f40b71), including the original assignment, your questions, and Alex's reported replies; the local `REVIEW_NOTES.md`; and Git commits.
- **Current behavior:** direct inspection of the two scripts, README, dependency file, ignore rules, saved manifest, and local tests.
- **Fresh verification:** 98 ingestion tests passed; the separate complete-download validator passed; an independent scan reproduced the report, filtering, normalization, and age figures. No live FDA ingestion was run during this review.
- **Historical verification:** the final build notes record 31 passing Python tests and an approximately 11.9-second full analysis with plotting. Those results belong to the original development environment. This checkout currently lacks a ready Python environment with all three required libraries, so the Python suite and full plotting runtime were not freshly verified.
- **Suggested reasoning:** when the code supports a tradeoff but the conversation does not establish that it was your original motivation, treat the explanation as something you can understand and defend now. Do not invent a story about having personally discovered every issue before implementation.

The old heading “Current implementation: one-page ingestion slice” at the top of `REVIEW_NOTES.md` is historical. It is not the current program. Its final-audit statement that changes await a commit is also superseded: Git now contains the final implementation in `dc44199`. Current manifest timestamps are 2026-09-04 18:24:34.942 UTC through 18:29:41.824 UTC, about 306.9 seconds. The notes contain different clock timestamps; use the manifest if you need exact times, or simply say “about five minutes seven seconds.”

## Start here: your one-minute project explanation

“The project has two stages. The Node script downloads FDA adverse-event reports for the exact assignment date range, and the Python script analyzes the saved snapshot.

For ingestion, I use independent date windows so requests can overlap across windows, while following each window's cursor sequentially. I validate the response data and pagination, pace all requests through a shared requester, and retry selected temporary failures. The download is only published as complete after counts and unique IDs reconcile across all planned windows.

For analysis, I validate the saved dataset, select reports by year and suspect-product text, and keep one row per report. That prevents products and reactions from multiplying record counts or age observations. Then I normalize and deduplicate terms within each report, calculate rankings and valid-age averages, and save the two required plots.

The saved result contains 97,652 reports. The main design priority was being able to explain why those results are complete and what the statistics actually mean.”

Stop there. You have given Alex several useful places to go deeper.

# Section 1 — Understand the code and the decisions

## 1.1 What was required, clarified, or chosen

| Topic | Status | What to say accurately |
|---|---|---|
| Node.js ingestion, Python analysis | Explicit assignment | The language split was required. JSON is the file-based handoff. |
| `pandas`, `numpy`, `matplotlib` | Explicit assignment | All three were required; pandas and Matplotlib were not alternatives. |
| `date_started` from 2002-01-01 through 2026-01-01 inclusive | Explicit assignment | Both endpoints count. The API is not being queried by download date or `date_created`. |
| `limit=100` on every report request | Explicit assignment | Request at most 100; do not increase it to 1,000 for speed. Responses can be shorter. |
| Configurable concurrency, default 3 | Explicit assignment | Three is required as the default. Actual requests overlap when latency/work permit, up to that cap. |
| 24 yearly windows | Chosen design, refined with you | Independent cursor chains provide concurrency; only the final window extends to next January 1. |
| Fixed meaning of “Present” | Your explicit clarification | Analyze the saved Part 1 range; do not fetch through today's date. |
| Count each normalized term once per report | Alex's reply in the shared conversation | This is report frequency, not the number of repeated array entries. |
| Filtered product ranking includes matching suspects only | Alex's expressed preference, adopted | Nonmatching suspects in a selected report do not enter the product ranking. |
| Normalization plus a small documented alias map | Alex accepted the minimum approach | Generic cleanup applies to all terms; narrow product aliases address inspected spelling families. |
| Offline tests kept local | Your temporary repository choice | Alex allowed tests but said they would not be reviewed. He did not forbid committing them. |
| JSON data committed under `data/` | Required deliverable and your clarification | This is intentional for the assessment; large recurring datasets would usually live elsewhere. |
| Two-panel timestamped PNG, Top 25 lists, three age means, flexible arguments | Explicit assignment | Empty results and fewer than 25 categories still need truthful output. |
| Complete Part 2 run under one minute | Explicit assignment | Measure file reads, validation, analysis, and chart writing, not just one calculation. |
| 300 ms pacing; 30-second attempt timeout; three retries | Chosen robustness policy | These enforce predictable behavior under temporary network problems. |
| Completion manifest, fresh output root, no resume | Chosen correctness/scope policy | Detect incomplete or mixed runs without building a checkpoint/resume system. |
| Age range 0–125 after conversion | Documented project plausibility policy | Data inspection found 680 years after conversion and a retained 122.75-year value. |

The optional year and product arguments are **optional for the caller**. Implementing their support was required. There was no separate bonus-features list to complete.

## 1.2 Your actual decision story

**You began by connecting Part 2 to your earlier D3 work.** That is a useful connection: input data, representation, filtering, aggregation, and visualization. The new challenge in Part 1 was proving that a multi-request download did not silently omit anything.

**You asked for acceptance criteria before implementation.** The initial conversation explicitly asked the pair programmer to separate requirements from assumptions, identify risk, use small reviewable slices, and explain the code. You were allowed to use LLMs and stated that you owned the decisions and would have to explain them.

**You challenged the year split.** You asked whether yearly windows were an efficiency choice or a requirement. They were a design choice. You then wanted to avoid a final window consisting of only January 1, 2026. Making every window January 1 to next January 1 inclusive would overlap boundaries, so the adopted design extends only the final 2025 window. That is a concrete requirements-and-correctness discussion you can describe honestly.

**You asked about uneven workloads.** Smaller windows could improve distribution across workers, but increase empty/partial-page overhead. You explicitly deferred changing the split. Measuring those costs would inform a later decision. The current dynamic queue lets each free worker take another year; it cannot split the final large in-progress window between idle workers.

**You clarified counting with Alex before finalizing analysis.** His preference changed an earlier assumption that all suspects in selected reports would be ranked. The implemented version selects a report using matching suspects and carries only those matching names into the product ranking. Its other report fields still contribute.

**You made the generic behavior explicit.** CARROTS is an example of any product phrase; Vitamin D is an example of consolidation. The CLI does not contain a CARROTS special case. Generic text cleanup applies broadly; the alias list is deliberately finite, not an automatic solution to every synonym.

**You questioned whether 13 outcomes meant extraction had lost data.** The complete snapshot contains only 13 distinct outcome labels. The correct response was to inspect all data and preserve the real categories, not manufacture twelve extras to appease a heading.

**The age policy followed data inspection.** Raw age units include years, months, weeks, days, and decades. A value of 68 decades becomes 680 years. Excluding that value from age statistics while keeping its report avoids guessing that the source meant 68 years. Missing age never becomes zero.

**A concurrency test exposed a timing assumption.** The history records a test observing two simultaneous requests when it expected three. The fix was an explicit barrier that held requests until three had started, then released them. Production code did not change. Describe this as a test synchronization problem fixed with controlled promises, rather than claiming retries had broken production concurrency.

## 1.3 Why the build order mattered

| Checkpoint | What became trustworthy | Why the next step depended on it |
|---|---|---|
| `93d4545`: first page | Request shape, data validation, exclusive save | Needed a known-good page before traversal. |
| `5bc501b`: one full window | Cursor progression and final count reconciliation | Needed a complete sequential unit before parallelizing. |
| `ee093ce`: concurrent full-range workers | Disjoint coverage, dynamic work assignment, actual overlap | Needed bounded parallel work before shared retry/pacing. |
| Retry/pacing slice | Shared starts, backoff, cooldown, timeout classification | Needed predictable API behavior before a large live download. |
| Manifest/global IDs slice | Persisted incomplete marker and run-level uniqueness | Needed a trustworthy handoff to analysis. |
| Small live check | Two-page compatibility with deployed FDA cursor behavior | Offline fixtures alone could not verify that contract. |
| `e24ce99`: resilient ingestion and dataset | Completed raw snapshot with independent disk audit | Analysis rules could now be based on observed data. |
| Analysis slices | Loading/filtering → ages → normalized rankings → chart | Each derived result had its own verification boundary. |
| `dc44199`: final analysis/audit | HTTP 408 handling, full manifest adjacency, docs and chart | Closed remaining contract/documentation gaps. |

Not every slice corresponds to a separate commit. The development discussion and review notes contain finer checkpoints than the six-commit history.

## 1.4 The big picture and the important boundaries

```text
FDA HTTPS API
    |
    | validated pages from 24 non-overlapping date windows
    v
part1.js: 3 workers -> shared pacing/retries -> exclusive JSON saves
    |
    | exhausted cursor chains + reconciled totals and IDs
    v
data/manifest.json: complete=true + exact page inventory
    |
    | validate manifest, every listed page, every report, global IDs
    v
part2.py: select report rows -> derive normalized lists and valid ages
    |                                      |
    v                                      v
stdout: totals/rankings/means       charts/<timestamp>.png
```

**Ingestion boundary:** it checks retrieval identity, dates, total shape, and cursors; it preserves analysis fields rather than requiring age or product semantics at download time.

**Analysis boundary:** it validates the fields it will actually use. A malformed required report structure is an error; a missing or unusable age generally excludes that age only. A valid empty selection is success.

**Storage boundary:** the manifest is an inventory and completion record. The reader does not recursively analyze every JSON file it happens to find. A temporary sample file or manifest itself cannot accidentally become report data.

**Statistical boundary:** a row is a report. Several reports could concern the same person or incident. A report can list several products and reactions without assigning a particular reaction to a particular product. These frequencies cannot establish causation or exposure-adjusted risk. [FDA explains these dataset limitations](https://open.fda.gov/apis/food/event/).

## 1.5 Six numbers to recognize, not obsess over

| Number | Meaning |
|---|---|
| 97,652 | Saved reports and unique report numbers. |
| 987 | Saved response-page files, plus one separate manifest. |
| 24 | Independent date windows; also, coincidentally, reports on January 1, 2026. These are unrelated counts. |
| 73,819 | Valid age observations; the overall mean is based on these, not all 97,652 reports. |
| 13 | Available outcome categories in this snapshot. |
| 3 / 100 / 300 / 30 / 4 | Default workers / request limit / milliseconds between starts / seconds per attempt / attempts maximum. |

## 1.6 How to read the detailed walkthroughs

Read execution order first, then the code blocks. Function definitions appear before the entry point but do not execute their bodies until called. The line ranges in the next two parts cover every function and meaningful statement group; blank lines and closing braces are grouped with the behavior they belong to.
